import {emptyCheckpoint} from '../economy/journal.ts';
import {emptyCare} from '../animals/welfare.ts';
import {REST_RULES} from '../animals/resting.ts';
import {WATER_RULES} from '../animals/watering.ts';
import {FOOD_RULES} from '../animals/feeding.ts';
import {emptyMotion} from '../animals/autonomy.ts';
import { MISSION_IDS, SPECIES_ID, type Animal, type ZooSaveV1 } from './state.ts';

export function createInitialState(seed = 0x5a17c0de): ZooSaveV1 {
  if (!Number.isInteger(seed) || seed < 1 || seed > 0xffffffff) throw new RangeError('Seed must be a nonzero uint32');
  const gate = { x: 1, z: 8 };
  const animals: Animal[] = ['macaw-1', 'macaw-2'].map(id => ({ id, speciesId: SPECIES_ID, habitatId: null, position: null, target: null, targetResourceId: null, hunger: FOOD_RULES.startingHunger, thirst: WATER_RULES.startingThirst, energy: REST_RULES.startingEnergy, habitatFit: 0, enrichment: 0, welfare: 0, care:emptyCare(), currentBehavior: 'idle',motion:emptyMotion(),foodEaten:0,waterDrunk:0,restedTicks:0,enrichedTicks:0 }));
  return {
    schemaVersion: 1, randomSeed: seed, randomState: seed, tick: 0, gameTimeMs: 0, currency: 1500, economy:{maintenancePeriod:0,nextCommand:1,checkpoint:emptyCheckpoint(),recovery:{lastRationTick:null,rationBatches:0,equipmentGrants:0,habitatGrant:null}},
    world: { width: 12, height: 10, gate, tiles: Array.from({ length: 120 }, (_, index) => {
      const cell = { x: index % 12, z: Math.floor(index / 12) };
      return { cell, terrain: cell.x === 9 && cell.z > 0 && cell.z < 9 ? 'creek' : 'land', occupantId: null, path: cell.x === gate.x && cell.z === gate.z };
    }), habitats: [], resources: [] },
    animals, visitors: [], visitorFlow:{open:false,nextSerial:1,cooldownTicks:0,viewedTotal:0,feedback:{evaluated:0,scored:0,scoreSum:0,positive:0,negative:0,interrupted:0,recent:[]}}, admissions: [],
    ledger: [{ id: 'ledger-starter', operationId: 'starter-grant', kind: 'starter', amount: 1500, balanceAfter: 1500, tick: 0, relatedId: null }],
    missions: { currentId: MISSION_IDS[0], completedIds: [], rewards: [], objectives: { habitatConnected: false, birdsFedIds: [], birdsWateredIds: [], comfortableTicks: 0, viewedVisitorIds: [], admittedVisitorIds:[], viewingEvidence:null, thrivingTicks: 0, thriving:null } },
    preferences: { speed:1, locale: 'en', graphics: 'auto', muted: true, reducedMotion: false },
  };
}
