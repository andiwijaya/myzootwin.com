import{a as Dc,A as Ic,r as Nc,p as Uc,B as Kr,b as Fc,w as Oc,f as Bc,c as zc,d as Ws,e as ur,h as kc,g as Gc,v as Oa,i as Sl,M as yl,P as pt,j as bl,k as Hc,l as El,m as wl,n as Tl,o as Al,q as Ba,s as Rl,t as Cl,u as Pl,x as Ll,y as za,z as Xs,T as bi,C as tn,D as ei,E as nn,F as ds,G as Vc,H as Wc,I as Xc,J as us,K as qc,L as Yc,N as $c,O as oo,Q as ki,R as Zc,S as Kc,U as Jc,V as lo,W as fs,X as Qc,Y as jc,Z as co,_ as ed,$ as td,a0 as nd,a1 as fr,a2 as id}from"./PlayEntry.astro_astro_type_script_index_0_lang.gCykC_5G.js";/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const ka="187",rd=0,uo=1,sd=2,Hr=1,ad=2,Ki=3,ai=0,Zt=1,vn=2,Ai=0,Qi=1,fo=2,ho=3,po=4,od=5,Ei=100,ld=101,cd=102,dd=103,ud=104,fd=200,hd=201,pd=202,md=203,Dl=204,Il=205,gd=206,_d=207,vd=208,xd=209,Md=210,Sd=211,yd=212,bd=213,Ed=214,qs=0,Ys=1,$s=2,er=3,Zs=4,Ks=5,Js=6,Qs=7,Nl=0,wd=1,Td=2,Un=0,Ul=1,Fl=2,Ol=3,Bl=4,zl=5,kl=6,Gl=7,Hl=300,Ci=301,tr=302,hs=303,ps=304,js=1e3,Nn=1001,ea=1002,Ft=1003,Ad=1004,hr=1005,$t=1006,ms=1007,Xn=1008,en=1009,Vl=1010,Wl=1011,nr=1012,Ga=1013,En=1014,Mn=1015,wn=1016,Ha=1017,Va=1018,Pi=1020,Xl=35902,ql=35899,Yl=1021,$l=1022,Sn=1023,Yn=1026,qn=1027,Zl=1028,Wa=1029,oi=1030,Xa=1031,qa=1033,Vr=33776,Wr=33777,Xr=33778,qr=33779,ta=35840,na=35841,ia=35842,ra=35843,sa=36196,aa=37492,oa=37496,la=37488,ca=37489,Jr=37490,da=37491,ua=37808,fa=37809,ha=37810,pa=37811,ma=37812,ga=37813,_a=37814,va=37815,xa=37816,Ma=37817,Sa=37818,ya=37819,ba=37820,Ea=37821,wa=36492,Ta=36494,Aa=36495,Ra=36283,Ca=36284,Qr=36285,Pa=36286,Rd=3200,La=0,Cd=1,Wn="",jt="srgb",jr="srgb-linear",es="linear",st="srgb",gs=7680,Pd=519,Ld=512,Dd=513,Id=514,Kl=515,Nd=516,Ud=517,Jl=518,Ql=519,Fd=35044,mo="300 es",hn=2e3,ir=2001;function Od(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function ts(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function Bd(){const i=ts("canvas");return i.style.display="block",i}const go={};function _o(...i){const e="THREE."+i.shift();console.log(e,...i)}function jl(i){const e=i[0];if(typeof e=="string"&&e.startsWith("TSL:")){const t=i[1];t&&t.isStackTrace?i[0]+=" "+t.getLocation():i[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return i}function Fe(...i){i=jl(i);const e="THREE."+i.shift();{const t=i[0];t&&t.isStackTrace?console.warn(t.getError(e)):console.warn(e,...i)}}function nt(...i){i=jl(i);const e="THREE."+i.shift();{const t=i[0];t&&t.isStackTrace?console.error(t.getError(e)):console.error(e,...i)}}function Yr(...i){const e=i.join(" ");e in go||(go[e]=!0,Fe(...i))}function zd(i,e,t){return new Promise(function(n,r){function s(){switch(i.clientWaitSync(e,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:r();break;case i.TIMEOUT_EXPIRED:setTimeout(s,t);break;default:n()}}setTimeout(s,t)})}const kd={[qs]:qs,[$s]:Js,[Zs]:Zs,[er]:Ks,[Ys]:Ys,[Js]:$s,[Qs]:Qs,[Ks]:er};class ci{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){const n=this._listeners;return n===void 0?!1:n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){const n=this._listeners;if(n===void 0)return;const r=n[e];if(r!==void 0){const s=r.indexOf(t);s!==-1&&r.splice(s,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const n=t[e.type];if(n!==void 0){e.target=this;const r=n.slice(0);for(let s=0,a=r.length;s<a;s++)r[s].call(this,e);e.target=null}}}const kt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],$r=Math.PI/180,Da=180/Math.PI;function ar(){const i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(kt[i&255]+kt[i>>8&255]+kt[i>>16&255]+kt[i>>24&255]+"-"+kt[e&255]+kt[e>>8&255]+"-"+kt[e>>16&15|64]+kt[e>>24&255]+"-"+kt[t&63|128]+kt[t>>8&255]+"-"+kt[t>>16&255]+kt[t>>24&255]+kt[n&255]+kt[n>>8&255]+kt[n>>16&255]+kt[n>>24&255]).toLowerCase()}function Ze(i,e,t){return Math.max(e,Math.min(t,i))}function Gd(i,e){return(i%e+e)%e}function _s(i,e,t){return(1-t)*i+t*e}function Hd(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function Ya(i){switch(i.constructor){case Uint32Array:return 4294967295;case Uint16Array:return 65535;case Uint8Array:case Uint8ClampedArray:return 255;case Int32Array:return 2147483647;case Int16Array:return 32767;case Int8Array:return 127;default:return}}function Vd(i,e){if(e.constructor===Float32Array)return i;const t=Ya(e);if(t===void 0)throw new Error("THREE.MathUtils: Invalid component type.");return Math.max(i/t,-1)}function Wd(i,e){if(e.constructor===Float32Array)return i;const t=Ya(e);if(t===void 0)throw new Error("THREE.MathUtils: Invalid component type.");return Math.round(i*t)}class Be{static{this.prototype.isVector2=!0}constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("THREE.Vector2: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,n=this.y,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6],this.y=r[1]*t+r[4]*n+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Ze(this.x,e.x,t.x),this.y=Ze(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=Ze(this.x,e,t),this.y=Ze(this.y,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Ze(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(Ze(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const n=Math.cos(t),r=Math.sin(t),s=this.x-e.x,a=this.y-e.y;return this.x=s*n-a*r+e.x,this.y=s*r+a*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Zn{constructor(e=0,t=0,n=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=r}static slerpFlat(e,t,n,r,s,a,d){let l=n[r+0],o=n[r+1],f=n[r+2],h=n[r+3],u=s[a+0],p=s[a+1],m=s[a+2],x=s[a+3];if(h!==x||l!==u||o!==p||f!==m){let _=l*u+o*p+f*m+h*x;_<0&&(u=-u,p=-p,m=-m,x=-x,_=-_);let c=1-d;if(_<.9995){const g=Math.acos(_),S=Math.sin(g);c=Math.sin(c*g)/S,d=Math.sin(d*g)/S,l=l*c+u*d,o=o*c+p*d,f=f*c+m*d,h=h*c+x*d}else{l=l*c+u*d,o=o*c+p*d,f=f*c+m*d,h=h*c+x*d;const g=1/Math.sqrt(l*l+o*o+f*f+h*h);l*=g,o*=g,f*=g,h*=g}}e[t]=l,e[t+1]=o,e[t+2]=f,e[t+3]=h}static multiplyQuaternionsFlat(e,t,n,r,s,a){const d=n[r],l=n[r+1],o=n[r+2],f=n[r+3],h=s[a],u=s[a+1],p=s[a+2],m=s[a+3];return e[t]=d*m+f*h+l*p-o*u,e[t+1]=l*m+f*u+o*h-d*p,e[t+2]=o*m+f*p+d*u-l*h,e[t+3]=f*m-d*h-l*u-o*p,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,r){return this._x=e,this._y=t,this._z=n,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const n=e._x,r=e._y,s=e._z,a=e._order,d=Math.cos,l=Math.sin,o=d(n/2),f=d(r/2),h=d(s/2),u=l(n/2),p=l(r/2),m=l(s/2);switch(a){case"XYZ":this._x=u*f*h+o*p*m,this._y=o*p*h-u*f*m,this._z=o*f*m+u*p*h,this._w=o*f*h-u*p*m;break;case"YXZ":this._x=u*f*h+o*p*m,this._y=o*p*h-u*f*m,this._z=o*f*m-u*p*h,this._w=o*f*h+u*p*m;break;case"ZXY":this._x=u*f*h-o*p*m,this._y=o*p*h+u*f*m,this._z=o*f*m+u*p*h,this._w=o*f*h-u*p*m;break;case"ZYX":this._x=u*f*h-o*p*m,this._y=o*p*h+u*f*m,this._z=o*f*m-u*p*h,this._w=o*f*h+u*p*m;break;case"YZX":this._x=u*f*h+o*p*m,this._y=o*p*h+u*f*m,this._z=o*f*m-u*p*h,this._w=o*f*h-u*p*m;break;case"XZY":this._x=u*f*h-o*p*m,this._y=o*p*h-u*f*m,this._z=o*f*m+u*p*h,this._w=o*f*h+u*p*m;break;default:Fe("Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const n=t/2,r=Math.sin(n);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,n=t[0],r=t[4],s=t[8],a=t[1],d=t[5],l=t[9],o=t[2],f=t[6],h=t[10],u=n+d+h;if(u>0){const p=.5/Math.sqrt(u+1);this._w=.25/p,this._x=(f-l)*p,this._y=(s-o)*p,this._z=(a-r)*p}else if(n>d&&n>h){const p=2*Math.sqrt(1+n-d-h);this._w=(f-l)/p,this._x=.25*p,this._y=(r+a)/p,this._z=(s+o)/p}else if(d>h){const p=2*Math.sqrt(1+d-n-h);this._w=(s-o)/p,this._x=(r+a)/p,this._y=.25*p,this._z=(l+f)/p}else{const p=2*Math.sqrt(1+h-n-d);this._w=(a-r)/p,this._x=(s+o)/p,this._y=(l+f)/p,this._z=.25*p}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Ze(this.dot(e),-1,1)))}rotateTowards(e,t){const n=this.angleTo(e);if(n===0)return this;const r=Math.min(1,t/n);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const n=e._x,r=e._y,s=e._z,a=e._w,d=t._x,l=t._y,o=t._z,f=t._w;return this._x=n*f+a*d+r*o-s*l,this._y=r*f+a*l+s*d-n*o,this._z=s*f+a*o+n*l-r*d,this._w=a*f-n*d-r*l-s*o,this._onChangeCallback(),this}slerp(e,t){let n=e._x,r=e._y,s=e._z,a=e._w,d=this.dot(e);d<0&&(n=-n,r=-r,s=-s,a=-a,d=-d);let l=1-t;if(d<.9995){const o=Math.acos(d),f=Math.sin(o);l=Math.sin(l*o)/f,t=Math.sin(t*o)/f,this._x=this._x*l+n*t,this._y=this._y*l+r*t,this._z=this._z*l+s*t,this._w=this._w*l+a*t,this._onChangeCallback()}else this._x=this._x*l+n*t,this._y=this._y*l+r*t,this._z=this._z*l+s*t,this._w=this._w*l+a*t,this.normalize();return this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),r=Math.sqrt(1-n),s=Math.sqrt(n);return this.set(r*Math.sin(e),r*Math.cos(e),s*Math.sin(t),s*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class F{static{this.prototype.isVector3=!0}constructor(e=0,t=0,n=0){this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("THREE.Vector3: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(vo.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(vo.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,n=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6]*r,this.y=s[1]*t+s[4]*n+s[7]*r,this.z=s[2]*t+s[5]*n+s[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,n=this.y,r=this.z,s=e.elements,a=1/(s[3]*t+s[7]*n+s[11]*r+s[15]);return this.x=(s[0]*t+s[4]*n+s[8]*r+s[12])*a,this.y=(s[1]*t+s[5]*n+s[9]*r+s[13])*a,this.z=(s[2]*t+s[6]*n+s[10]*r+s[14])*a,this}applyQuaternion(e){const t=this.x,n=this.y,r=this.z,s=e.x,a=e.y,d=e.z,l=e.w,o=2*(a*r-d*n),f=2*(d*t-s*r),h=2*(s*n-a*t);return this.x=t+l*o+a*h-d*f,this.y=n+l*f+d*o-s*h,this.z=r+l*h+s*f-a*o,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,n=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[4]*n+s[8]*r,this.y=s[1]*t+s[5]*n+s[9]*r,this.z=s[2]*t+s[6]*n+s[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Ze(this.x,e.x,t.x),this.y=Ze(this.y,e.y,t.y),this.z=Ze(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=Ze(this.x,e,t),this.y=Ze(this.y,e,t),this.z=Ze(this.z,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Ze(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const n=e.x,r=e.y,s=e.z,a=t.x,d=t.y,l=t.z;return this.x=r*l-s*d,this.y=s*a-n*l,this.z=n*d-r*a,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return vs.copy(this).projectOnVector(e),this.sub(vs)}reflect(e){return this.sub(vs.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(Ze(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y,r=this.z-e.z;return t*t+n*n+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){const r=Math.sin(t)*e;return this.x=r*Math.sin(n),this.y=Math.cos(t)*e,this.z=r*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const vs=new F,vo=new Zn;class ke{static{this.prototype.isMatrix3=!0}constructor(e,t,n,r,s,a,d,l,o){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,r,s,a,d,l,o)}set(e,t,n,r,s,a,d,l,o){const f=this.elements;return f[0]=e,f[1]=r,f[2]=d,f[3]=t,f[4]=s,f[5]=l,f[6]=n,f[7]=a,f[8]=o,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,r=t.elements,s=this.elements,a=n[0],d=n[3],l=n[6],o=n[1],f=n[4],h=n[7],u=n[2],p=n[5],m=n[8],x=r[0],_=r[3],c=r[6],g=r[1],S=r[4],M=r[7],A=r[2],E=r[5],v=r[8];return s[0]=a*x+d*g+l*A,s[3]=a*_+d*S+l*E,s[6]=a*c+d*M+l*v,s[1]=o*x+f*g+h*A,s[4]=o*_+f*S+h*E,s[7]=o*c+f*M+h*v,s[2]=u*x+p*g+m*A,s[5]=u*_+p*S+m*E,s[8]=u*c+p*M+m*v,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[1],r=e[2],s=e[3],a=e[4],d=e[5],l=e[6],o=e[7],f=e[8];return t*a*f-t*d*o-n*s*f+n*d*l+r*s*o-r*a*l}invert(){const e=this.elements,t=e[0],n=e[1],r=e[2],s=e[3],a=e[4],d=e[5],l=e[6],o=e[7],f=e[8],h=f*a-d*o,u=d*l-f*s,p=o*s-a*l,m=t*h+n*u+r*p;if(m===0)return this.set(0,0,0,0,0,0,0,0,0);const x=1/m;return e[0]=h*x,e[1]=(r*o-f*n)*x,e[2]=(d*n-r*a)*x,e[3]=u*x,e[4]=(f*t-r*l)*x,e[5]=(r*s-d*t)*x,e[6]=p*x,e[7]=(n*l-o*t)*x,e[8]=(a*t-n*s)*x,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,r,s,a,d){const l=Math.cos(s),o=Math.sin(s);return this.set(n*l,n*o,-n*(l*a+o*d)+a+e,-r*o,r*l,-r*(-o*a+l*d)+d+t,0,0,1),this}scale(e,t){return Yr("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(xs.makeScale(e,t)),this}rotate(e){return Yr("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(xs.makeRotation(-e)),this}translate(e,t){return Yr("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(xs.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,n=e.elements;for(let r=0;r<9;r++)if(t[r]!==n[r])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const xs=new ke,xo=new ke().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Mo=new ke().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Xd(){const i={enabled:!0,workingColorSpace:jr,spaces:{},convert:function(r,s,a){return this.enabled===!1||s===a||!s||!a||(this.spaces[s].transfer===st&&(r.r=Fn(r.r),r.g=Fn(r.g),r.b=Fn(r.b)),this.spaces[s].primaries!==this.spaces[a].primaries&&(r.applyMatrix3(this.spaces[s].toXYZ),r.applyMatrix3(this.spaces[a].fromXYZ)),this.spaces[a].transfer===st&&(r.r=Ri(r.r),r.g=Ri(r.g),r.b=Ri(r.b))),r},workingToColorSpace:function(r,s){return this.convert(r,this.workingColorSpace,s)},colorSpaceToWorking:function(r,s){return this.convert(r,s,this.workingColorSpace)},getPrimaries:function(r){return this.spaces[r].primaries},getTransfer:function(r){return r===Wn?es:this.spaces[r].transfer},getToneMappingMode:function(r){return this.spaces[r].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(r,s=this.workingColorSpace){return r.fromArray(this.spaces[s].luminanceCoefficients)},define:function(r){Object.assign(this.spaces,r)},_getMatrix:function(r,s,a){return r.copy(this.spaces[a].fromXYZ).multiply(this.spaces[s].toXYZ)},_getDrawingBufferColorSpace:function(r){return this.spaces[r].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(r=this.workingColorSpace){return this.spaces[r].workingColorSpaceConfig.unpackColorSpace}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],n=[.3127,.329];return i.define({[jr]:{primaries:e,whitePoint:n,transfer:es,toXYZ:xo,fromXYZ:Mo,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:jt},outputColorSpaceConfig:{drawingBufferColorSpace:jt}},[jt]:{primaries:e,whitePoint:n,transfer:st,toXYZ:xo,fromXYZ:Mo,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:jt}}}),i}const Ke=Xd();function Fn(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function Ri(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}let ui;class qd{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{ui===void 0&&(ui=ts("canvas")),ui.width=e.width,ui.height=e.height;const r=ui.getContext("2d");e instanceof ImageData?r.putImageData(e,0,0):r.drawImage(e,0,0,e.width,e.height),n=ui}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=ts("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);const r=n.getImageData(0,0,e.width,e.height),s=r.data;for(let a=0;a<s.length;a++)s[a]=Fn(s[a]/255)*255;return n.putImageData(r,0,0),t}else if(e.data){const t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(Fn(t[n]/255)*255):t[n]=Fn(t[n]);return{data:t,width:e.width,height:e.height}}else return Fe("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let Yd=0;class $a{constructor(e=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:Yd++}),this.uuid=ar(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<"u"&&t instanceof VideoFrame?e.set(t.displayWidth,t.displayHeight,0):t!==null?e.set(t.width||0,t.height||0,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const n={uuid:this.uuid,url:""},r=this.data;if(r!==null){let s;if(Array.isArray(r)){s=[];for(let a=0,d=r.length;a<d;a++)r[a].isDataTexture?s.push(Ms(r[a].image)):s.push(Ms(r[a]))}else s=Ms(r);n.url=s}return t||(e.images[this.uuid]=n),n}}function Ms(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?qd.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(Fe("Texture: Unable to serialize Texture."),{})}let $d=0;const Ss=new F;class qt extends ci{constructor(e=qt.DEFAULT_IMAGE,t=qt.DEFAULT_MAPPING,n=Nn,r=Nn,s=$t,a=Xn,d=Sn,l=en,o=qt.DEFAULT_ANISOTROPY,f=Wn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:$d++}),this.uuid=ar(),this.name="",this.source=new $a(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=r,this.magFilter=s,this.minFilter=a,this.anisotropy=o,this.format=d,this.internalFormat=null,this.type=l,this.offset=new Be(0,0),this.repeat=new Be(1,1),this.center=new Be(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new ke,this.generateMipmaps=!0,this.mipmapsAutoUpdate=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=f,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.isPMREMTexture=!1,this.normalized=!1}get width(){return this.source.getSize(Ss).x}get height(){return this.source.getSize(Ss).y}get depth(){return this.source.getSize(Ss).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.mipmapsAutoUpdate=e.mipmapsAutoUpdate,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isPMREMTexture=e.isPMREMTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const n=e[t];if(n===void 0){Fe(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){Fe(`Texture.setValues(): property '${t}' does not exist.`);continue}r&&n&&r.isVector2&&n.isVector2||r&&n&&r.isVector3&&n.isVector3||r&&n&&r.isMatrix3&&n.isMatrix3?r.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,mipmapsAutoUpdate:this.mipmapsAutoUpdate,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==Hl)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case js:e.x=e.x-Math.floor(e.x);break;case Nn:e.x=e.x<0?0:1;break;case ea:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case js:e.y=e.y-Math.floor(e.y);break;case Nn:e.y=e.y<0?0:1;break;case ea:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}qt.DEFAULT_IMAGE=null;qt.DEFAULT_MAPPING=Hl;qt.DEFAULT_ANISOTROPY=1;class wt{static{this.prototype.isVector4=!0}constructor(e=0,t=0,n=0,r=1){this.x=e,this.y=t,this.z=n,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,r){return this.x=e,this.y=t,this.z=n,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("THREE.Vector4: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,n=this.y,r=this.z,s=this.w,a=e.elements;return this.x=a[0]*t+a[4]*n+a[8]*r+a[12]*s,this.y=a[1]*t+a[5]*n+a[9]*r+a[13]*s,this.z=a[2]*t+a[6]*n+a[10]*r+a[14]*s,this.w=a[3]*t+a[7]*n+a[11]*r+a[15]*s,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,r,s;const l=e.elements,o=l[0],f=l[4],h=l[8],u=l[1],p=l[5],m=l[9],x=l[2],_=l[6],c=l[10];if(Math.abs(f-u)<.01&&Math.abs(h-x)<.01&&Math.abs(m-_)<.01){if(Math.abs(f+u)<.1&&Math.abs(h+x)<.1&&Math.abs(m+_)<.1&&Math.abs(o+p+c-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const S=(o+1)/2,M=(p+1)/2,A=(c+1)/2,E=(f+u)/4,v=(h+x)/4,y=(m+_)/4;return S>M&&S>A?S<.01?(n=0,r=.707106781,s=.707106781):(n=Math.sqrt(S),r=E/n,s=v/n):M>A?M<.01?(n=.707106781,r=0,s=.707106781):(r=Math.sqrt(M),n=E/r,s=y/r):A<.01?(n=.707106781,r=.707106781,s=0):(s=Math.sqrt(A),n=v/s,r=y/s),this.set(n,r,s,t),this}let g=Math.sqrt((_-m)*(_-m)+(h-x)*(h-x)+(u-f)*(u-f));return Math.abs(g)<.001&&(g=1),this.x=(_-m)/g,this.y=(h-x)/g,this.z=(u-f)/g,this.w=Math.acos((o+p+c-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Ze(this.x,e.x,t.x),this.y=Ze(this.y,e.y,t.y),this.z=Ze(this.z,e.z,t.z),this.w=Ze(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=Ze(this.x,e,t),this.y=Ze(this.y,e,t),this.z=Ze(this.z,e,t),this.w=Ze(this.w,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Ze(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class Zd extends ci{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:$t,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new wt(0,0,e,t),this.scissorTest=!1,this.viewport=new wt(0,0,e,t),this.textures=[];const r=n.count;for(let s=0;s<r;s++)this.textures[s]=new qt({width:e,height:t,depth:n.depth}),this.textures[s].isRenderTargetTexture=!0,this.textures[s].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveColorBuffer=n.resolveColorBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.storeMultisampledColorBuffer=n.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=n.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=n.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview,this.useArrayDepthTexture=n.useArrayDepthTexture}_setTextureOptions(e={}){const t={minFilter:$t,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.mipmapsAutoUpdate!==void 0&&(t.mipmapsAutoUpdate=e.mipmapsAutoUpdate),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),e!==null&&e.renderTarget===null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let r=0,s=this.textures.length;r<s;r++)this.textures[r].image.width=e,this.textures[r].image.height=t,this.textures[r].image.depth=n,this.textures[r].isData3DTexture!==!0&&(this.textures[r].isArrayTexture=this.textures[r].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const r=Object.assign({},e.textures[t].image);this.textures[t].source=new $a(r)}if(this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveColorBuffer=e.resolveColorBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,this.storeMultisampledColorBuffer=e.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=e.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=e.storeMultisampledStencilBuffer,e.depthTexture!==null)if(e.depthTexture.renderTarget===e){const t=e.depthTexture.clone();t.renderTarget=null,this.depthTexture=t}else this.depthTexture=e.depthTexture;else this.depthTexture=null;return this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class yn extends Zd{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}}class ec extends qt{constructor(e=null,t=1,n=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=Ft,this.minFilter=Ft,this.wrapR=Nn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class Kd extends qt{constructor(e=null,t=1,n=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=Ft,this.minFilter=Ft,this.wrapR=Nn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}}class ft{static{this.prototype.isMatrix4=!0}constructor(e,t,n,r,s,a,d,l,o,f,h,u,p,m,x,_){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,r,s,a,d,l,o,f,h,u,p,m,x,_)}set(e,t,n,r,s,a,d,l,o,f,h,u,p,m,x,_){const c=this.elements;return c[0]=e,c[4]=t,c[8]=n,c[12]=r,c[1]=s,c[5]=a,c[9]=d,c[13]=l,c[2]=o,c[6]=f,c[10]=h,c[14]=u,c[3]=p,c[7]=m,c[11]=x,c[15]=_,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new ft().fromArray(this.elements)}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){const t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return this.determinantAffine()===0?(e.set(1,0,0),t.set(0,1,0),n.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();const t=this.elements,n=e.elements,r=1/fi.setFromMatrixColumn(e,0).length(),s=1/fi.setFromMatrixColumn(e,1).length(),a=1/fi.setFromMatrixColumn(e,2).length();return t[0]=n[0]*r,t[1]=n[1]*r,t[2]=n[2]*r,t[3]=0,t[4]=n[4]*s,t[5]=n[5]*s,t[6]=n[6]*s,t[7]=0,t[8]=n[8]*a,t[9]=n[9]*a,t[10]=n[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,n=e.x,r=e.y,s=e.z,a=Math.cos(n),d=Math.sin(n),l=Math.cos(r),o=Math.sin(r),f=Math.cos(s),h=Math.sin(s);if(e.order==="XYZ"){const u=a*f,p=a*h,m=d*f,x=d*h;t[0]=l*f,t[4]=-l*h,t[8]=o,t[1]=p+m*o,t[5]=u-x*o,t[9]=-d*l,t[2]=x-u*o,t[6]=m+p*o,t[10]=a*l}else if(e.order==="YXZ"){const u=l*f,p=l*h,m=o*f,x=o*h;t[0]=u+x*d,t[4]=m*d-p,t[8]=a*o,t[1]=a*h,t[5]=a*f,t[9]=-d,t[2]=p*d-m,t[6]=x+u*d,t[10]=a*l}else if(e.order==="ZXY"){const u=l*f,p=l*h,m=o*f,x=o*h;t[0]=u-x*d,t[4]=-a*h,t[8]=m+p*d,t[1]=p+m*d,t[5]=a*f,t[9]=x-u*d,t[2]=-a*o,t[6]=d,t[10]=a*l}else if(e.order==="ZYX"){const u=a*f,p=a*h,m=d*f,x=d*h;t[0]=l*f,t[4]=m*o-p,t[8]=u*o+x,t[1]=l*h,t[5]=x*o+u,t[9]=p*o-m,t[2]=-o,t[6]=d*l,t[10]=a*l}else if(e.order==="YZX"){const u=a*l,p=a*o,m=d*l,x=d*o;t[0]=l*f,t[4]=x-u*h,t[8]=m*h+p,t[1]=h,t[5]=a*f,t[9]=-d*f,t[2]=-o*f,t[6]=p*h+m,t[10]=u-x*h}else if(e.order==="XZY"){const u=a*l,p=a*o,m=d*l,x=d*o;t[0]=l*f,t[4]=-h,t[8]=o*f,t[1]=u*h+x,t[5]=a*f,t[9]=p*h-m,t[2]=m*h-p,t[6]=d*f,t[10]=x*h+u}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Jd,e,Qd)}lookAt(e,t,n){const r=this.elements;return Jt.subVectors(e,t),Jt.lengthSq()===0&&(Jt.z=1),Jt.normalize(),zn.crossVectors(n,Jt),zn.lengthSq()===0&&(Math.abs(n.z)===1?Jt.x+=1e-4:Jt.z+=1e-4,Jt.normalize(),zn.crossVectors(n,Jt)),zn.normalize(),pr.crossVectors(Jt,zn),r[0]=zn.x,r[4]=pr.x,r[8]=Jt.x,r[1]=zn.y,r[5]=pr.y,r[9]=Jt.y,r[2]=zn.z,r[6]=pr.z,r[10]=Jt.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,r=t.elements,s=this.elements,a=n[0],d=n[4],l=n[8],o=n[12],f=n[1],h=n[5],u=n[9],p=n[13],m=n[2],x=n[6],_=n[10],c=n[14],g=n[3],S=n[7],M=n[11],A=n[15],E=r[0],v=r[4],y=r[8],T=r[12],R=r[1],N=r[5],z=r[9],q=r[13],C=r[2],D=r[6],O=r[10],k=r[14],Q=r[3],G=r[7],K=r[11],j=r[15];return s[0]=a*E+d*R+l*C+o*Q,s[4]=a*v+d*N+l*D+o*G,s[8]=a*y+d*z+l*O+o*K,s[12]=a*T+d*q+l*k+o*j,s[1]=f*E+h*R+u*C+p*Q,s[5]=f*v+h*N+u*D+p*G,s[9]=f*y+h*z+u*O+p*K,s[13]=f*T+h*q+u*k+p*j,s[2]=m*E+x*R+_*C+c*Q,s[6]=m*v+x*N+_*D+c*G,s[10]=m*y+x*z+_*O+c*K,s[14]=m*T+x*q+_*k+c*j,s[3]=g*E+S*R+M*C+A*Q,s[7]=g*v+S*N+M*D+A*G,s[11]=g*y+S*z+M*O+A*K,s[15]=g*T+S*q+M*k+A*j,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[4],r=e[8],s=e[12],a=e[1],d=e[5],l=e[9],o=e[13],f=e[2],h=e[6],u=e[10],p=e[14],m=e[3],x=e[7],_=e[11],c=e[15],g=l*p-o*u,S=d*p-o*h,M=d*u-l*h,A=a*p-o*f,E=a*u-l*f,v=a*h-d*f;return t*(x*g-_*S+c*M)-n*(m*g-_*A+c*E)+r*(m*S-x*A+c*v)-s*(m*M-x*E+_*v)}determinantAffine(){const e=this.elements,t=e[0],n=e[4],r=e[8],s=e[1],a=e[5],d=e[9],l=e[2],o=e[6],f=e[10];return t*(a*f-d*o)-n*(s*f-d*l)+r*(s*o-a*l)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){const r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=n),this}invert(){const e=this.elements,t=e[0],n=e[1],r=e[2],s=e[3],a=e[4],d=e[5],l=e[6],o=e[7],f=e[8],h=e[9],u=e[10],p=e[11],m=e[12],x=e[13],_=e[14],c=e[15],g=t*d-n*a,S=t*l-r*a,M=t*o-s*a,A=n*l-r*d,E=n*o-s*d,v=r*o-s*l,y=f*x-h*m,T=f*_-u*m,R=f*c-p*m,N=h*_-u*x,z=h*c-p*x,q=u*c-p*_,C=g*q-S*z+M*N+A*R-E*T+v*y;if(C===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const D=1/C;return e[0]=(d*q-l*z+o*N)*D,e[1]=(r*z-n*q-s*N)*D,e[2]=(x*v-_*E+c*A)*D,e[3]=(u*E-h*v-p*A)*D,e[4]=(l*R-a*q-o*T)*D,e[5]=(t*q-r*R+s*T)*D,e[6]=(_*M-m*v-c*S)*D,e[7]=(f*v-u*M+p*S)*D,e[8]=(a*z-d*R+o*y)*D,e[9]=(n*R-t*z-s*y)*D,e[10]=(m*E-x*M+c*g)*D,e[11]=(h*M-f*E-p*g)*D,e[12]=(d*T-a*N-l*y)*D,e[13]=(t*N-n*T+r*y)*D,e[14]=(x*S-m*A-_*g)*D,e[15]=(f*A-h*S+u*g)*D,this}scale(e){const t=this.elements,n=e.x,r=e.y,s=e.z;return t[0]*=n,t[4]*=r,t[8]*=s,t[1]*=n,t[5]*=r,t[9]*=s,t[2]*=n,t[6]*=r,t[10]*=s,t[3]*=n,t[7]*=r,t[11]*=s,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,r))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const n=Math.cos(t),r=Math.sin(t),s=1-n,a=e.x,d=e.y,l=e.z,o=s*a,f=s*d;return this.set(o*a+n,o*d-r*l,o*l+r*d,0,o*d+r*l,f*d+n,f*l-r*a,0,o*l-r*d,f*l+r*a,s*l*l+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,r,s,a){return this.set(1,n,s,0,e,1,a,0,t,r,1,0,0,0,0,1),this}compose(e,t,n){const r=this.elements,s=t._x,a=t._y,d=t._z,l=t._w,o=s+s,f=a+a,h=d+d,u=s*o,p=s*f,m=s*h,x=a*f,_=a*h,c=d*h,g=l*o,S=l*f,M=l*h,A=n.x,E=n.y,v=n.z;return r[0]=(1-(x+c))*A,r[1]=(p+M)*A,r[2]=(m-S)*A,r[3]=0,r[4]=(p-M)*E,r[5]=(1-(u+c))*E,r[6]=(_+g)*E,r[7]=0,r[8]=(m+S)*v,r[9]=(_-g)*v,r[10]=(1-(u+x))*v,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,n){const r=this.elements;e.x=r[12],e.y=r[13],e.z=r[14];const s=this.determinantAffine();if(s===0)return n.set(1,1,1),t.identity(),this;let a=fi.set(r[0],r[1],r[2]).length();const d=fi.set(r[4],r[5],r[6]).length(),l=fi.set(r[8],r[9],r[10]).length();s<0&&(a=-a),dn.copy(this);const o=1/a,f=1/d,h=1/l;return dn.elements[0]*=o,dn.elements[1]*=o,dn.elements[2]*=o,dn.elements[4]*=f,dn.elements[5]*=f,dn.elements[6]*=f,dn.elements[8]*=h,dn.elements[9]*=h,dn.elements[10]*=h,t.setFromRotationMatrix(dn),n.x=a,n.y=d,n.z=l,this}makePerspective(e,t,n,r,s,a,d=hn,l=!1){const o=this.elements,f=2*s/(t-e),h=2*s/(n-r),u=(t+e)/(t-e),p=(n+r)/(n-r);let m,x;if(l)m=s/(a-s),x=a*s/(a-s);else if(d===hn)m=-(a+s)/(a-s),x=-2*a*s/(a-s);else if(d===ir)m=-a/(a-s),x=-a*s/(a-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+d);return o[0]=f,o[4]=0,o[8]=u,o[12]=0,o[1]=0,o[5]=h,o[9]=p,o[13]=0,o[2]=0,o[6]=0,o[10]=m,o[14]=x,o[3]=0,o[7]=0,o[11]=-1,o[15]=0,this}makeOrthographic(e,t,n,r,s,a,d=hn,l=!1){const o=this.elements,f=2/(t-e),h=2/(n-r),u=-(t+e)/(t-e),p=-(n+r)/(n-r);let m,x;if(l)m=1/(a-s),x=a/(a-s);else if(d===hn)m=-2/(a-s),x=-(a+s)/(a-s);else if(d===ir)m=-1/(a-s),x=-s/(a-s);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+d);return o[0]=f,o[4]=0,o[8]=0,o[12]=u,o[1]=0,o[5]=h,o[9]=0,o[13]=p,o[2]=0,o[6]=0,o[10]=m,o[14]=x,o[3]=0,o[7]=0,o[11]=0,o[15]=1,this}equals(e){const t=this.elements,n=e.elements;for(let r=0;r<16;r++)if(t[r]!==n[r])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}}const fi=new F,dn=new ft,Jd=new F(0,0,0),Qd=new F(1,1,1),zn=new F,pr=new F,Jt=new F,So=new ft,yo=new Zn;class $n{constructor(e=0,t=0,n=0,r=$n.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=r}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,r=this._order){return this._x=e,this._y=t,this._z=n,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){const r=e.elements,s=r[0],a=r[4],d=r[8],l=r[1],o=r[5],f=r[9],h=r[2],u=r[6],p=r[10];switch(t){case"XYZ":this._y=Math.asin(Ze(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(-f,p),this._z=Math.atan2(-a,s)):(this._x=Math.atan2(u,o),this._z=0);break;case"YXZ":this._x=Math.asin(-Ze(f,-1,1)),Math.abs(f)<.9999999?(this._y=Math.atan2(d,p),this._z=Math.atan2(l,o)):(this._y=Math.atan2(-h,s),this._z=0);break;case"ZXY":this._x=Math.asin(Ze(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(-h,p),this._z=Math.atan2(-a,o)):(this._y=0,this._z=Math.atan2(l,s));break;case"ZYX":this._y=Math.asin(-Ze(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(u,p),this._z=Math.atan2(l,s)):(this._x=0,this._z=Math.atan2(-a,o));break;case"YZX":this._z=Math.asin(Ze(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-f,o),this._y=Math.atan2(-h,s)):(this._x=0,this._y=Math.atan2(d,p));break;case"XZY":this._z=Math.asin(-Ze(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(u,o),this._y=Math.atan2(d,s)):(this._x=Math.atan2(-f,p),this._y=0);break;default:Fe("Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return So.makeRotationFromQuaternion(e),this.setFromRotationMatrix(So,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return yo.setFromEuler(this),this.setFromQuaternion(yo,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}$n.DEFAULT_ORDER="XYZ";class Za{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let jd=0;const bo=new F,hi=new Zn,An=new ft,mr=new F,Gi=new F,eu=new F,tu=new Zn,Eo=new F(1,0,0),wo=new F(0,1,0),To=new F(0,0,1),Ao={type:"added"},nu={type:"removed"},pi={type:"childadded",child:null},ys={type:"childremoved",child:null};class Ot extends ci{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:jd++}),this.uuid=ar(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Ot.DEFAULT_UP.clone();const e=new F,t=new $n,n=new Zn,r=new F(1,1,1);function s(){n.setFromEuler(t,!1)}function a(){t.setFromQuaternion(n,void 0,!1)}t._onChange(s),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:r},modelViewMatrix:{value:new ft},normalMatrix:{value:new ke}}),this.matrix=new ft,this.matrixWorld=new ft,this.matrixAutoUpdate=Ot.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Ot.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Za,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale),this.pivot!==null&&this.position.copy(this.pivot).applyMatrix4(this.matrix).sub(this.pivot)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return hi.setFromAxisAngle(e,t),this.quaternion.multiply(hi),this}rotateOnWorldAxis(e,t){return hi.setFromAxisAngle(e,t),this.quaternion.premultiply(hi),this}rotateX(e){return this.rotateOnAxis(Eo,e)}rotateY(e){return this.rotateOnAxis(wo,e)}rotateZ(e){return this.rotateOnAxis(To,e)}translateOnAxis(e,t){return bo.copy(e).applyQuaternion(this.quaternion),this.position.add(bo.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Eo,e)}translateY(e){return this.translateOnAxis(wo,e)}translateZ(e){return this.translateOnAxis(To,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(An.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?mr.copy(e):mr.set(e,t,n);const r=this.parent;this.updateWorldMatrix(!0,!1),Gi.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?An.lookAt(Gi,mr,this.up):An.lookAt(mr,Gi,this.up),this.quaternion.setFromRotationMatrix(An),r&&(An.extractRotation(r.matrixWorld),hi.setFromRotationMatrix(An),this.quaternion.premultiply(hi.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(nt("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Ao),pi.child=e,this.dispatchEvent(pi),pi.child=null):nt("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(nu),ys.child=e,this.dispatchEvent(ys),ys.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),An.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),An.multiply(e.parent.matrixWorld)),e.applyMatrix4(An),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Ao),pi.child=e,this.dispatchEvent(pi),pi.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,r=this.children.length;n<r;n++){const a=this.children[n].getObjectByProperty(e,t);if(a!==void 0)return a}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);const r=this.children;for(let s=0,a=r.length;s<a;s++)r[s].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Gi,e,eu),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Gi,tu,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}intersectsFrustum(){return!0}traverse(e){e(this);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const e=this.pivot;if(e!==null){const t=e.x,n=e.y,r=e.z,s=this.matrix.elements;s[12]+=t-s[0]*t-s[4]*n-s[8]*r,s[13]+=n-s[1]*t-s[5]*n-s[9]*r,s[14]+=r-s[2]*t-s[6]*n-s[10]*r}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t,n=!1){const r=this.parent;if(e===!0&&r!==null&&r.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||n)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,n=!0),t===!0){const s=this.children;for(let a=0,d=s.length;a<d;a++)s[a].updateWorldMatrix(!1,!0,n)}}toJSON(e){const t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const r={};r.uuid=this.uuid,r.type=this.type,r.name=this.name,r.castShadow=this.castShadow,r.receiveShadow=this.receiveShadow,r.visible=this.visible,r.frustumCulled=this.frustumCulled,r.renderOrder=this.renderOrder,r.static=this.static,r.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.pivot!==null&&(r.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(r.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(r.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(r.type="InstancedMesh",r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type="BatchedMesh",r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.geometryInfo=this._geometryInfo.map(d=>({...d,boundingBox:d.boundingBox?d.boundingBox.toJSON():void 0,boundingSphere:d.boundingSphere?d.boundingSphere.toJSON():void 0})),r.instanceInfo=this._instanceInfo.map(d=>({...d})),r.availableInstanceIds=this._availableInstanceIds.slice(),r.availableGeometryIds=this._availableGeometryIds.slice(),r.nextIndexStart=this._nextIndexStart,r.nextVertexStart=this._nextVertexStart,r.geometryCount=this._geometryCount,r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.matricesTexture=this._matricesTexture.toJSON(e),r.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(r.boundingBox=this.boundingBox.toJSON()));function s(d,l){return d[l.uuid]===void 0&&(d[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=s(e.geometries,this.geometry);const d=this.geometry.parameters;if(d!==void 0&&d.shapes!==void 0){const l=d.shapes;if(Array.isArray(l))for(let o=0,f=l.length;o<f;o++){const h=l[o];s(e.shapes,h)}else s(e.shapes,l)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const d=[];for(let l=0,o=this.material.length;l<o;l++)d.push(s(e.materials,this.material[l]));r.material=d}else r.material=s(e.materials,this.material);if(this.children.length>0){r.children=[];for(let d=0;d<this.children.length;d++)r.children.push(this.children[d].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let d=0;d<this.animations.length;d++){const l=this.animations[d];r.animations.push(s(e.animations,l))}}if(t){const d=a(e.geometries),l=a(e.materials),o=a(e.textures),f=a(e.images),h=a(e.shapes),u=a(e.skeletons),p=a(e.animations),m=a(e.nodes);d.length>0&&(n.geometries=d),l.length>0&&(n.materials=l),o.length>0&&(n.textures=o),f.length>0&&(n.images=f),h.length>0&&(n.shapes=h),u.length>0&&(n.skeletons=u),p.length>0&&(n.animations=p),m.length>0&&(n.nodes=m)}return n.object=r,n;function a(d){const l=[];for(const o in d){const f=d[o];delete f.metadata,l.push(f)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){const r=e.children[n];this.add(r.clone())}return this}dispose(){this.dispatchEvent({type:"dispose"})}}Ot.DEFAULT_UP=new F(0,1,0);Ot.DEFAULT_MATRIX_AUTO_UPDATE=!0;Ot.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class rt extends Ot{constructor(){super(),this.isGroup=!0,this.type="Group"}}const iu={type:"move"};class bs{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new rt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new rt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new F,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new F),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new rt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new F,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new F,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let r=null,s=null,a=null;const d=this._targetRay,l=this._grip,o=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(o&&e.hand){a=!0;for(const x of e.hand.values()){const _=t.getJointPose(x,n),c=this._getHandJoint(o,x);_!==null&&(c.matrix.fromArray(_.transform.matrix),c.matrix.decompose(c.position,c.quaternion,c.scale),c.matrixWorldNeedsUpdate=!0,c.jointRadius=_.radius),c.visible=_!==null}const f=o.joints["index-finger-tip"],h=o.joints["thumb-tip"],u=f.position.distanceTo(h.position),p=.02,m=.005;o.inputState.pinching&&u>p+m?(o.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!o.inputState.pinching&&u<=p-m&&(o.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,n),s!==null&&(l.matrix.fromArray(s.transform.matrix),l.matrix.decompose(l.position,l.quaternion,l.scale),l.matrixWorldNeedsUpdate=!0,s.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(s.linearVelocity)):l.hasLinearVelocity=!1,s.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(s.angularVelocity)):l.hasAngularVelocity=!1,l.eventsEnabled&&l.dispatchEvent({type:"gripUpdated",data:e,target:this})));d!==null&&(r=t.getPose(e.targetRaySpace,n),r===null&&s!==null&&(r=s),r!==null&&(d.matrix.fromArray(r.transform.matrix),d.matrix.decompose(d.position,d.quaternion,d.scale),d.matrixWorldNeedsUpdate=!0,r.linearVelocity?(d.hasLinearVelocity=!0,d.linearVelocity.copy(r.linearVelocity)):d.hasLinearVelocity=!1,r.angularVelocity?(d.hasAngularVelocity=!0,d.angularVelocity.copy(r.angularVelocity)):d.hasAngularVelocity=!1,this.dispatchEvent(iu)))}return d!==null&&(d.visible=r!==null),l!==null&&(l.visible=s!==null),o!==null&&(o.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const n=new rt;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}const tc={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},kn={h:0,s:0,l:0},gr={h:0,s:0,l:0};function Es(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}class We{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){const r=e;r&&r.isColor?this.copy(r):typeof r=="number"?this.setHex(r):typeof r=="string"&&this.setStyle(r)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=jt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Ke.colorSpaceToWorking(this,t),this}setRGB(e,t,n,r=Ke.workingColorSpace){return this.r=e,this.g=t,this.b=n,Ke.colorSpaceToWorking(this,r),this}setHSL(e,t,n,r=Ke.workingColorSpace){if(e=Gd(e,1),t=Ze(t,0,1),n=Ze(n,0,1),t===0)this.r=this.g=this.b=n;else{const s=n<=.5?n*(1+t):n+t-n*t,a=2*n-s;this.r=Es(a,s,e+1/3),this.g=Es(a,s,e),this.b=Es(a,s,e-1/3)}return Ke.colorSpaceToWorking(this,r),this}setStyle(e,t=jt){function n(s){s!==void 0&&parseFloat(s)<1&&Fe("Color: Alpha component of "+e+" will be ignored.")}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let s;const a=r[1],d=r[2];switch(a){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(d))return n(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(d))return n(s[4]),this.setRGB(Math.min(100,parseFloat(s[1]))/100,Math.min(100,parseFloat(s[2]))/100,Math.min(100,parseFloat(s[3]))/100,t);break;case"hsl":case"hsla":if(s=/^\s*([+-]?(?:\d+(?:\.\d+)?|\.\d+))\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(d))return n(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:Fe("Color: Unknown color model "+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){const s=r[1],a=s.length;if(a===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(a===6)return this.setHex(parseInt(s,16),t);Fe("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=jt){const n=tc[e.toLowerCase()];return n!==void 0?this.setHex(n,t):Fe("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Fn(e.r),this.g=Fn(e.g),this.b=Fn(e.b),this}copyLinearToSRGB(e){return this.r=Ri(e.r),this.g=Ri(e.g),this.b=Ri(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=jt){return Ke.workingToColorSpace(Gt.copy(this),e),Math.round(Ze(Gt.r*255,0,255))*65536+Math.round(Ze(Gt.g*255,0,255))*256+Math.round(Ze(Gt.b*255,0,255))}getHexString(e=jt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=Ke.workingColorSpace){Ke.workingToColorSpace(Gt.copy(this),t);const n=Gt.r,r=Gt.g,s=Gt.b,a=Math.max(n,r,s),d=Math.min(n,r,s);let l,o;const f=(d+a)/2;if(d===a)l=0,o=0;else{const h=a-d;switch(o=f<=.5?h/(a+d):h/(2-a-d),a){case n:l=(r-s)/h+(r<s?6:0);break;case r:l=(s-n)/h+2;break;case s:l=(n-r)/h+4;break}l/=6}return e.h=l,e.s=o,e.l=f,e}getRGB(e,t=Ke.workingColorSpace){return Ke.workingToColorSpace(Gt.copy(this),t),e.r=Gt.r,e.g=Gt.g,e.b=Gt.b,e}getStyle(e=jt){Ke.workingToColorSpace(Gt.copy(this),e);const t=Gt.r,n=Gt.g,r=Gt.b;return e!==jt?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${r.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(r*255)})`}offsetHSL(e,t,n){return this.getHSL(kn),this.setHSL(kn.h+e,kn.s+t,kn.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(kn),e.getHSL(gr);const n=_s(kn.h,gr.h,t),r=_s(kn.s,gr.s,t),s=_s(kn.l,gr.l,t);return this.setHSL(n,r,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,n=this.g,r=this.b,s=e.elements;return this.r=s[0]*t+s[3]*n+s[6]*r,this.g=s[1]*t+s[4]*n+s[7]*r,this.b=s[2]*t+s[5]*n+s[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Gt=new We;We.NAMES=tc;class ru extends Ot{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new $n,this.environmentIntensity=1,this.environmentRotation=new $n,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),this.background=e.background!==null?e.background.clone():null,this.environment=e.environment!==null?e.environment.clone():null,this.fog=e.fog!==null?e.fog.clone():null,this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),this.overrideMaterial=e.overrideMaterial!==null?e.overrideMaterial.clone():null,this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),t.object.backgroundBlurriness=this.backgroundBlurriness,t.object.backgroundIntensity=this.backgroundIntensity,t.object.backgroundRotation=this.backgroundRotation.toArray(),t.object.environmentIntensity=this.environmentIntensity,t.object.environmentRotation=this.environmentRotation.toArray(),t}}const un=new F,Rn=new F,ws=new F,Cn=new F,mi=new F,gi=new F,Ro=new F,Ts=new F,As=new F,Rs=new F,Cs=new wt,Ps=new wt,Ls=new wt;class sn{constructor(e=new F,t=new F,n=new F){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,r){r.subVectors(n,t),un.subVectors(e,t),r.cross(un);const s=r.lengthSq();return s>0?r.multiplyScalar(1/Math.sqrt(s)):r.set(0,0,0)}static getBarycoord(e,t,n,r,s){un.subVectors(r,t),Rn.subVectors(n,t),ws.subVectors(e,t);const a=un.dot(un),d=un.dot(Rn),l=un.dot(ws),o=Rn.dot(Rn),f=Rn.dot(ws),h=a*o-d*d;if(h===0)return s.set(0,0,0),null;const u=1/h,p=(o*l-d*f)*u,m=(a*f-d*l)*u;return s.set(1-p-m,m,p)}static containsPoint(e,t,n,r){return this.getBarycoord(e,t,n,r,Cn)===null?!1:Cn.x>=0&&Cn.y>=0&&Cn.x+Cn.y<=1}static getInterpolation(e,t,n,r,s,a,d,l){return this.getBarycoord(e,t,n,r,Cn)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(s,Cn.x),l.addScaledVector(a,Cn.y),l.addScaledVector(d,Cn.z),l)}static getInterpolatedAttribute(e,t,n,r,s,a){return Cs.setScalar(0),Ps.setScalar(0),Ls.setScalar(0),Cs.fromBufferAttribute(e,t),Ps.fromBufferAttribute(e,n),Ls.fromBufferAttribute(e,r),a.setScalar(0),a.addScaledVector(Cs,s.x),a.addScaledVector(Ps,s.y),a.addScaledVector(Ls,s.z),a}static isFrontFacing(e,t,n,r){return un.subVectors(n,t),Rn.subVectors(e,t),un.cross(Rn).dot(r)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,r){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,n,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return un.subVectors(this.c,this.b),Rn.subVectors(this.a,this.b),un.cross(Rn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return sn.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return sn.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,r,s){return sn.getInterpolation(e,this.a,this.b,this.c,t,n,r,s)}containsPoint(e){return sn.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return sn.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const n=this.a,r=this.b,s=this.c;let a,d;mi.subVectors(r,n),gi.subVectors(s,n),Ts.subVectors(e,n);const l=mi.dot(Ts),o=gi.dot(Ts);if(l<=0&&o<=0)return t.copy(n);As.subVectors(e,r);const f=mi.dot(As),h=gi.dot(As);if(f>=0&&h<=f)return t.copy(r);const u=l*h-f*o;if(u<=0&&l>=0&&f<=0&&l-f>0)return a=l/(l-f),t.copy(n).addScaledVector(mi,a);Rs.subVectors(e,s);const p=mi.dot(Rs),m=gi.dot(Rs);if(m>=0&&p<=m)return t.copy(s);const x=p*o-l*m;if(x<=0&&o>=0&&m<=0)return d=o/(o-m),t.copy(n).addScaledVector(gi,d);const _=f*m-p*h;if(_<=0&&h-f>=0&&p-m>=0)return Ro.subVectors(s,r),d=(h-f)/(h-f+(p-m)),t.copy(r).addScaledVector(Ro,d);const c=1/(_+x+u);return a=x*c,d=u*c,t.copy(n).addScaledVector(mi,a).addScaledVector(gi,d)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class bn{constructor(e=new F(1/0,1/0,1/0),t=new F(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(fn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(fn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=fn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const n=e.geometry;if(n!==void 0){const s=n.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0&&e.isBatchedMesh!==!0)for(let a=0,d=s.count;a<d;a++)e.isMesh===!0?e.getVertexPosition(a,fn):fn.fromBufferAttribute(s,a),fn.applyMatrix4(e.matrixWorld),this.expandByPoint(fn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),_r.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),_r.copy(n.boundingBox)),_r.applyMatrix4(e.matrixWorld),this.union(_r)}const r=e.children;for(let s=0,a=r.length;s<a;s++)this.expandByObject(r[s],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,fn),fn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Hi),vr.subVectors(this.max,Hi),_i.subVectors(e.a,Hi),vi.subVectors(e.b,Hi),xi.subVectors(e.c,Hi),Gn.subVectors(vi,_i),Hn.subVectors(xi,vi),ti.subVectors(_i,xi);let t=[0,-Gn.z,Gn.y,0,-Hn.z,Hn.y,0,-ti.z,ti.y,Gn.z,0,-Gn.x,Hn.z,0,-Hn.x,ti.z,0,-ti.x,-Gn.y,Gn.x,0,-Hn.y,Hn.x,0,-ti.y,ti.x,0];return!Ds(t,_i,vi,xi,vr)||(t=[1,0,0,0,1,0,0,0,1],!Ds(t,_i,vi,xi,vr))?!1:(xr.crossVectors(Gn,Hn),t=[xr.x,xr.y,xr.z],Ds(t,_i,vi,xi,vr))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,fn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(fn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Pn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Pn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Pn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Pn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Pn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Pn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Pn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Pn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Pn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const Pn=[new F,new F,new F,new F,new F,new F,new F,new F],fn=new F,_r=new bn,_i=new F,vi=new F,xi=new F,Gn=new F,Hn=new F,ti=new F,Hi=new F,vr=new F,xr=new F,ni=new F;function Ds(i,e,t,n,r){for(let s=0,a=i.length-3;s<=a;s+=3){ni.fromArray(i,s);const d=r.x*Math.abs(ni.x)+r.y*Math.abs(ni.y)+r.z*Math.abs(ni.z),l=e.dot(ni),o=t.dot(ni),f=n.dot(ni);if(Math.max(-Math.max(l,o,f),Math.min(l,o,f))>d)return!1}return!0}const Ct=new F,Mr=new Be;let su=0;class On extends ci{constructor(e,t,n=!1){if(super(),Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:su++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=Fd,this.updateRanges=[],this.gpuType=Mn,this.version=0,this._normalizationScale=e!==void 0?Ya(e):void 0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this._normalizationScale=e._normalizationScale,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let r=0,s=this.itemSize;r<s;r++)this.array[e+r]=t.array[n+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)Mr.fromBufferAttribute(this,t),Mr.applyMatrix3(e),this.setXY(t,Mr.x,Mr.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)Ct.fromBufferAttribute(this,t),Ct.applyMatrix3(e),this.setXYZ(t,Ct.x,Ct.y,Ct.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)Ct.fromBufferAttribute(this,t),Ct.applyMatrix4(e),this.setXYZ(t,Ct.x,Ct.y,Ct.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Ct.fromBufferAttribute(this,t),Ct.applyNormalMatrix(e),this.setXYZ(t,Ct.x,Ct.y,Ct.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Ct.fromBufferAttribute(this,t),Ct.transformDirection(e),this.setXYZ(t,Ct.x,Ct.y,Ct.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=this._denormalize(n)),n}setComponent(e,t,n){return this.normalized&&(n=this._normalize(n)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=this._denormalize(t)),t}setX(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=this._denormalize(t)),t}setY(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=this._denormalize(t)),t}setZ(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=this._denormalize(t)),t}setW(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=this._normalize(t),n=this._normalize(n)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,r){return e*=this.itemSize,this.normalized&&(t=this._normalize(t),n=this._normalize(n),r=this._normalize(r)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this}setXYZW(e,t,n,r,s){return e*=this.itemSize,this.normalized&&(t=this._normalize(t),n=this._normalize(n),r=this._normalize(r),s=this._normalize(s)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return e.name=this.name,e.usage=this.usage,e.gpuType=this.gpuType,e}dispose(){this.dispatchEvent({type:"dispose"})}_denormalize(e){const t=this._normalizationScale;return t!==void 0?Math.max(e/t,-1):Vd(e,this.array)}_normalize(e){const t=this._normalizationScale;return t!==void 0?Math.round(e*t):Wd(e,this.array)}}class nc extends On{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class ic extends On{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class qe extends On{constructor(e,t,n){super(new Float32Array(e),t,n)}}const au=new bn,Vi=new F,Is=new F;class as{constructor(e=new F,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const n=this.center;t!==void 0?n.copy(t):au.setFromPoints(e).getCenter(n);let r=0;for(let s=0,a=e.length;s<a;s++)r=Math.max(r,n.distanceToSquared(e[s]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Vi.subVectors(e,this.center);const t=Vi.lengthSq();if(t>this.radius*this.radius){const n=Math.sqrt(t),r=(n-this.radius)*.5;this.center.addScaledVector(Vi,r/n),this.radius+=r}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Is.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Vi.copy(e.center).add(Is)),this.expandByPoint(Vi.copy(e.center).sub(Is))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}let ou=0;const rn=new ft,Ns=new Ot,Mi=new F,Qt=new bn,Wi=new bn,Nt=new F;class Mt extends ci{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:ou++}),this.uuid=ar(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Od(e)?ic:nc)(e,1):this.index=e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const s=new ke().getNormalMatrix(e);n.applyNormalMatrix(s),n.needsUpdate=!0}const r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return rn.makeRotationFromQuaternion(e),this.applyMatrix4(rn),this}rotateX(e){return rn.makeRotationX(e),this.applyMatrix4(rn),this}rotateY(e){return rn.makeRotationY(e),this.applyMatrix4(rn),this}rotateZ(e){return rn.makeRotationZ(e),this.applyMatrix4(rn),this}translate(e,t,n){return rn.makeTranslation(e,t,n),this.applyMatrix4(rn),this}scale(e,t,n){return rn.makeScale(e,t,n),this.applyMatrix4(rn),this}lookAt(e){return Ns.lookAt(e),Ns.updateMatrix(),this.applyMatrix4(Ns.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Mi).negate(),this.translate(Mi.x,Mi.y,Mi.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const n=[];for(let r=0,s=e.length;r<s;r++){const a=e[r];n.push(a.x,a.y,a.z||0)}this.setAttribute("position",new qe(n,3))}else{const n=Math.min(e.length,t.count);for(let r=0;r<n;r++){const s=e[r];t.setXYZ(r,s.x,s.y,s.z||0)}e.length>t.count&&Fe("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new bn);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){nt("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new F(-1/0,-1/0,-1/0),new F(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,r=t.length;n<r;n++){const s=t[n];Qt.setFromBufferAttribute(s),this.morphTargetsRelative?(Nt.addVectors(this.boundingBox.min,Qt.min),this.boundingBox.expandByPoint(Nt),Nt.addVectors(this.boundingBox.max,Qt.max),this.boundingBox.expandByPoint(Nt)):(this.boundingBox.expandByPoint(Qt.min),this.boundingBox.expandByPoint(Qt.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&nt('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new as);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){nt("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new F,1/0);return}if(e){const n=this.boundingSphere.center;if(Qt.setFromBufferAttribute(e),t)for(let s=0,a=t.length;s<a;s++){const d=t[s];Wi.setFromBufferAttribute(d),this.morphTargetsRelative?(Nt.addVectors(Qt.min,Wi.min),Qt.expandByPoint(Nt),Nt.addVectors(Qt.max,Wi.max),Qt.expandByPoint(Nt)):(Qt.expandByPoint(Wi.min),Qt.expandByPoint(Wi.max))}Qt.getCenter(n);let r=0;for(let s=0,a=e.count;s<a;s++)Nt.fromBufferAttribute(e,s),r=Math.max(r,n.distanceToSquared(Nt));if(t)for(let s=0,a=t.length;s<a;s++){const d=t[s],l=this.morphTargetsRelative;for(let o=0,f=d.count;o<f;o++)Nt.fromBufferAttribute(d,o),l&&(Mi.fromBufferAttribute(e,o),Nt.add(Mi)),r=Math.max(r,n.distanceToSquared(Nt))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&nt('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){nt("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.position,r=t.normal,s=t.uv;let a=this.getAttribute("tangent");(a===void 0||a.count!==n.count)&&(a=new On(new Float32Array(4*n.count),4),this.setAttribute("tangent",a));const d=[],l=[],o=new Uint8Array(n.count);for(let T=0;T<n.count;T++)d[T]=new F,l[T]=new F;const f=new F,h=new F,u=new F,p=new Be,m=new Be,x=new Be,_=new F,c=new F;function g(T,R,N){o[T]=o[R]=o[N]=1,f.fromBufferAttribute(n,T),h.fromBufferAttribute(n,R),u.fromBufferAttribute(n,N),p.fromBufferAttribute(s,T),m.fromBufferAttribute(s,R),x.fromBufferAttribute(s,N),h.sub(f),u.sub(f),m.sub(p),x.sub(p);const z=1/(m.x*x.y-x.x*m.y);isFinite(z)&&(_.copy(h).multiplyScalar(x.y).addScaledVector(u,-m.y).multiplyScalar(z),c.copy(u).multiplyScalar(m.x).addScaledVector(h,-x.x).multiplyScalar(z),d[T].add(_),d[R].add(_),d[N].add(_),l[T].add(c),l[R].add(c),l[N].add(c))}let S=this.groups;S.length===0&&(S=[{start:0,count:e.count}]);for(let T=0,R=S.length;T<R;++T){const N=S[T],z=N.start,q=N.count;for(let C=z,D=z+q;C<D;C+=3)g(e.getX(C+0),e.getX(C+1),e.getX(C+2))}const M=new F,A=new F,E=new F,v=new F;function y(T){E.fromBufferAttribute(r,T),v.copy(E);const R=d[T];M.copy(R),M.sub(E.multiplyScalar(E.dot(R))).normalize(),A.crossVectors(v,R);const z=A.dot(l[T])<0?-1:1;a.setXYZW(T,M.x,M.y,M.z,z)}for(let T=0,R=n.count;T<R;++T)o[T]&&y(T);this._transformed=!0}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0||n.count!==t.count)n=new On(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let u=0,p=n.count;u<p;u++)n.setXYZ(u,0,0,0);const r=new F,s=new F,a=new F,d=new F,l=new F,o=new F,f=new F,h=new F;if(e)for(let u=0,p=e.count;u<p;u+=3){const m=e.getX(u+0),x=e.getX(u+1),_=e.getX(u+2);r.fromBufferAttribute(t,m),s.fromBufferAttribute(t,x),a.fromBufferAttribute(t,_),f.subVectors(a,s),h.subVectors(r,s),f.cross(h),d.fromBufferAttribute(n,m),l.fromBufferAttribute(n,x),o.fromBufferAttribute(n,_),d.add(f),l.add(f),o.add(f),n.setXYZ(m,d.x,d.y,d.z),n.setXYZ(x,l.x,l.y,l.z),n.setXYZ(_,o.x,o.y,o.z)}else for(let u=0,p=t.count;u<p;u+=3)r.fromBufferAttribute(t,u+0),s.fromBufferAttribute(t,u+1),a.fromBufferAttribute(t,u+2),f.subVectors(a,s),h.subVectors(r,s),f.cross(h),n.setXYZ(u+0,f.x,f.y,f.z),n.setXYZ(u+1,f.x,f.y,f.z),n.setXYZ(u+2,f.x,f.y,f.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)Nt.fromBufferAttribute(e,t),Nt.normalize(),e.setXYZ(t,Nt.x,Nt.y,Nt.z)}toNonIndexed(){function e(d,l){const o=d.array,f=d.itemSize,h=d.normalized,u=new o.constructor(l.length*f);let p=0,m=0;for(let x=0,_=l.length;x<_;x++){d.isInterleavedBufferAttribute?p=l[x]*d.data.stride+d.offset:p=l[x]*f;for(let c=0;c<f;c++)u[m++]=o[p++]}return new On(u,f,h)}if(this.index===null)return Fe("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new Mt,n=this.index.array,r=this.attributes;for(const d in r){const l=r[d],o=e(l,n);t.setAttribute(d,o)}const s=this.morphAttributes;for(const d in s){const l=[],o=s[d];for(let f=0,h=o.length;f<h;f++){const u=o[f],p=e(u,n);l.push(p)}t.morphAttributes[d]=l}t.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let d=0,l=a.length;d<l;d++){const o=a[d];t.addGroup(o.start,o.count,o.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,e.name=this.name,Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const l=this.parameters;for(const o in l)l[o]!==void 0&&(e[o]=l[o]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const n=this.attributes;for(const l in n){const o=n[l];e.data.attributes[l]=o.toJSON(e.data)}const r={};let s=!1;for(const l in this.morphAttributes){const o=this.morphAttributes[l],f=[];for(let h=0,u=o.length;h<u;h++){const p=o[h];f.push(p.toJSON(e.data))}f.length>0&&(r[l]=f,s=!0)}s&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));const d=this.boundingSphere;return d!==null&&(e.data.boundingSphere=d.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const n=e.index;n!==null&&this.setIndex(n.clone());const r=e.attributes;for(const o in r){const f=r[o];this.setAttribute(o,f.clone(t))}const s=e.morphAttributes;for(const o in s){const f=[],h=s[o];for(let u=0,p=h.length;u<p;u++)f.push(h[u].clone(t));this.morphAttributes[o]=f}this.morphTargetsRelative=e.morphTargetsRelative;const a=e.groups;for(let o=0,f=a.length;o<f;o++){const h=a[o];this.addGroup(h.start,h.count,h.materialIndex)}const d=e.boundingBox;d!==null&&(this.boundingBox=d.clone());const l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}const Us=new F,lu=new F,cu=new ke;class In{constructor(e=new F(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,r){return this.normal.set(e,t,n),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){const r=Us.subVectors(n,t).cross(lu.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,n=!0){const r=e.delta(Us),s=this.normal.dot(r);if(s===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const a=-(e.start.dot(this.normal)+this.constant)/s;return n===!0&&(a<0||a>1)?null:t.copy(e.start).addScaledVector(r,a)}intersectsLine(e){const t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const n=t||cu.getNormalMatrix(e),r=this.coplanarPoint(Us).applyMatrix4(e),s=this.normal.applyMatrix3(n).normalize();return this.constant=-r.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(e){return this.normal.fromArray(e.normal),this.constant=e.constant,this}}let du=0;class Ui extends ci{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:du++}),this.uuid=ar(),this.name="",this.type="Material",this.blending=Qi,this.side=ai,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Dl,this.blendDst=Il,this.blendEquation=Ei,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new We(0,0,0),this.blendAlpha=0,this.depthFunc=er,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Pd,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=gs,this.stencilZFail=gs,this.stencilZPass=gs,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const n=e[t];if(n===void 0){Fe(`Material: parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){Fe(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(n):r&&r.isVector2&&n&&n.isVector2||r&&r.isEuler&&n&&n.isEuler||r&&r.isVector3&&n&&n.isVector3?r.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,n.blending=this.blending,n.side=this.side,n.shadowSide=this.shadowSide,n.vertexColors=this.vertexColors,n.opacity=this.opacity,n.transparent=this.transparent,n.blendSrc=this.blendSrc,n.blendDst=this.blendDst,n.blendEquation=this.blendEquation,n.blendSrcAlpha=this.blendSrcAlpha,n.blendDstAlpha=this.blendDstAlpha,n.blendEquationAlpha=this.blendEquationAlpha,n.blendColor=this.blendColor.getHex(),n.blendAlpha=this.blendAlpha,n.depthFunc=this.depthFunc,n.depthTest=this.depthTest,n.depthWrite=this.depthWrite,n.colorWrite=this.colorWrite,n.clipIntersection=this.clipIntersection,n.clipShadows=this.clipShadows,n.stencilWriteMask=this.stencilWriteMask,n.stencilFunc=this.stencilFunc,n.stencilRef=this.stencilRef,n.stencilFuncMask=this.stencilFuncMask,n.stencilFail=this.stencilFail,n.stencilZFail=this.stencilZFail,n.stencilZPass=this.stencilZPass,n.stencilWrite=this.stencilWrite,n.polygonOffset=this.polygonOffset,n.polygonOffsetFactor=this.polygonOffsetFactor,n.polygonOffsetUnits=this.polygonOffsetUnits,n.dithering=this.dithering,n.alphaTest=this.alphaTest,n.alphaHash=this.alphaHash,n.alphaToCoverage=this.alphaToCoverage,n.premultipliedAlpha=this.premultipliedAlpha,n.forceSinglePass=this.forceSinglePass,n.allowOverride=this.allowOverride,n.visible=this.visible,n.toneMapped=this.toneMapped,n.name=this.name,this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.diffuseRoughness!==void 0&&(n.diffuseRoughness=this.diffuseRoughness),this.diffuseRoughnessMap&&this.diffuseRoughnessMap.isTexture&&(n.diffuseRoughnessMap=this.diffuseRoughnessMap.toJSON(e).uuid),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(n.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessMinimum!==void 0&&(n.iridescenceThicknessMinimum=this.iridescenceThicknessMinimum),this.iridescenceThicknessMaximum!==void 0&&(n.iridescenceThicknessMaximum=this.iridescenceThicknessMaximum),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(n.clippingPlanes=this.clippingPlanes.map(s=>s.toJSON())),this.rotation!==void 0&&(n.rotation=this.rotation),this.depthPacking!==void 0&&(n.depthPacking=this.depthPacking),this.linewidth!==void 0&&(n.linewidth=this.linewidth),this.linecap!==void 0&&(n.linecap=this.linecap),this.linejoin!==void 0&&(n.linejoin=this.linejoin),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.wireframe!==void 0&&(n.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(n.flatShading=this.flatShading),this.fog!==void 0&&(n.fog=this.fog),Object.keys(this.userData).length>0&&(n.userData=this.userData);function r(s){const a=[];for(const d in s){const l=s[d];delete l.metadata,a.push(l)}return a}if(t){const s=r(e.textures),a=r(e.images);s.length>0&&(n.textures=s),a.length>0&&(n.images=a)}return n}fromJSON(e,t){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new We().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.diffuseRoughness!==void 0&&(this.diffuseRoughness=e.diffuseRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.retroreflectivity!==void 0&&(this.retroreflectivity=e.retroreflectivity),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessMinimum!==void 0&&(this.iridescenceThicknessMinimum=e.iridescenceThicknessMinimum),e.iridescenceThicknessMaximum!==void 0&&(this.iridescenceThicknessMaximum=e.iridescenceThicknessMaximum),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessMinimum=e.iridescenceThicknessRange[0],this.iridescenceThicknessMaximum=e.iridescenceThicknessRange[1]),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.clippingPlanes!==void 0&&(this.clippingPlanes=e.clippingPlanes.map(n=>new In().fromJSON(n))),e.clipIntersection!==void 0&&(this.clipIntersection=e.clipIntersection),e.clipShadows!==void 0&&(this.clipShadows=e.clipShadows),e.depthPacking!==void 0&&(this.depthPacking=e.depthPacking),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.linecap!==void 0&&(this.linecap=e.linecap),e.linejoin!==void 0&&(this.linejoin=e.linejoin),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(typeof e.vertexColors=="number"?this.vertexColors=e.vertexColors>0:this.vertexColors=e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=t[e.map]||null),e.matcap!==void 0&&(this.matcap=t[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=t[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=t[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=t[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let n=e.normalScale;Array.isArray(n)===!1&&(n=[n,n]),this.normalScale=new Be().fromArray(n)}return e.displacementMap!==void 0&&(this.displacementMap=t[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=t[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=t[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=t[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=t[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=t[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=t[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=t[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=t[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=t[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=t[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=t[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new Be().fromArray(e.clearcoatNormalScale)),e.diffuseRoughnessMap!==void 0&&(this.diffuseRoughnessMap=t[e.diffuseRoughnessMap]||null),e.iridescenceMap!==void 0&&(this.iridescenceMap=t[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=t[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=t[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=t[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=t[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let n=null;if(t!==null){const r=t.length;n=new Array(r);for(let s=0;s!==r;++s)n[s]=t[s].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}const Ln=new F,Fs=new F,Sr=new F,yr=new F;class Ka{constructor(e=new F,t=new F(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Ln)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=Ln.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Ln.copy(this.origin).addScaledVector(this.direction,t),Ln.distanceToSquared(e))}distanceSqToSegment(e,t,n,r){Fs.copy(e).add(t).multiplyScalar(.5),Sr.copy(t).sub(e).normalize(),yr.copy(this.origin).sub(Fs);const s=e.distanceTo(t)*.5,a=-this.direction.dot(Sr),d=yr.dot(this.direction),l=-yr.dot(Sr),o=yr.lengthSq(),f=Math.abs(1-a*a);let h,u,p,m;if(f>0)if(h=a*l-d,u=a*d-l,m=s*f,h>=0)if(u>=-m)if(u<=m){const x=1/f;h*=x,u*=x,p=h*(h+a*u+2*d)+u*(a*h+u+2*l)+o}else u=s,h=Math.max(0,-(a*u+d)),p=-h*h+u*(u+2*l)+o;else u=-s,h=Math.max(0,-(a*u+d)),p=-h*h+u*(u+2*l)+o;else u<=-m?(h=Math.max(0,-(-a*s+d)),u=h>0?-s:Math.min(Math.max(-s,-l),s),p=-h*h+u*(u+2*l)+o):u<=m?(h=0,u=Math.min(Math.max(-s,-l),s),p=u*(u+2*l)+o):(h=Math.max(0,-(a*s+d)),u=h>0?s:Math.min(Math.max(-s,-l),s),p=-h*h+u*(u+2*l)+o);else u=a>0?-s:s,h=Math.max(0,-(a*u+d)),p=-h*h+u*(u+2*l)+o;return n&&n.copy(this.origin).addScaledVector(this.direction,h),r&&r.copy(Fs).addScaledVector(Sr,u),p}intersectSphere(e,t){if(e.radius<0)return null;Ln.subVectors(e.center,this.origin);const n=Ln.dot(this.direction),r=Ln.dot(Ln)-n*n,s=e.radius*e.radius;if(r>s)return null;const a=Math.sqrt(s-r),d=n-a,l=n+a;return l<0?null:d<0?this.at(l,t):this.at(d,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){const n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,r,s,a,d,l;const o=1/this.direction.x,f=1/this.direction.y,h=1/this.direction.z,u=this.origin;return o>=0?(n=(e.min.x-u.x)*o,r=(e.max.x-u.x)*o):(n=(e.max.x-u.x)*o,r=(e.min.x-u.x)*o),f>=0?(s=(e.min.y-u.y)*f,a=(e.max.y-u.y)*f):(s=(e.max.y-u.y)*f,a=(e.min.y-u.y)*f),n>a||s>r||((s>n||isNaN(n))&&(n=s),(a<r||isNaN(r))&&(r=a),h>=0?(d=(e.min.z-u.z)*h,l=(e.max.z-u.z)*h):(d=(e.max.z-u.z)*h,l=(e.min.z-u.z)*h),n>l||d>r)||((d>n||n!==n)&&(n=d),(l<r||r!==r)&&(r=l),r<0)?null:this.at(n>=0?n:r,t)}intersectsBox(e){return this.intersectBox(e,Ln)!==null}intersectTriangle(e,t,n,r,s){const a=this.origin,d=this.direction,l=d.x,o=d.y,f=d.z,h=e.x-a.x,u=e.y-a.y,p=e.z-a.z,m=t.x-a.x,x=t.y-a.y,_=t.z-a.z,c=n.x-a.x,g=n.y-a.y,S=n.z-a.z,M=Math.abs(l),A=Math.abs(o),E=Math.abs(f);let v,y,T,R,N,z,q,C,D,O,k,Q;if(M>=A&&M>=E?(T=l,z=h,D=m,Q=c,l>=0?(v=o,y=f,R=u,N=p,q=x,C=_,O=g,k=S):(v=f,y=o,R=p,N=u,q=_,C=x,O=S,k=g)):A>=E?(T=o,z=u,D=x,Q=g,o>=0?(v=f,y=l,R=p,N=h,q=_,C=m,O=S,k=c):(v=l,y=f,R=h,N=p,q=m,C=_,O=c,k=S)):(T=f,z=p,D=_,Q=S,f>=0?(v=l,y=o,R=h,N=u,q=m,C=x,O=c,k=g):(v=o,y=l,R=u,N=h,q=x,C=m,O=g,k=c)),T===0)return null;const G=v/T,K=y/T,j=1/T,ce=R-G*z,ve=N-K*z,$=q-G*D,ie=C-K*D,_e=O-G*Q,we=k-K*Q,ae=_e*ie-we*$,Ne=ce*we-ve*_e,ot=$*ve-ie*ce;if(r){if(ae<0||Ne<0||ot<0)return null}else if((ae<0||Ne<0||ot<0)&&(ae>0||Ne>0||ot>0))return null;const ye=ae+Ne+ot;if(ye===0)return null;const He=j*(ae*z+Ne*D+ot*Q);return(ye>0?He<0:He>0)?null:this.at(He/ye,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Li extends Ui{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new We(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new $n,this.combine=Nl,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Co=new ft,ii=new Ka,br=new as,Po=new F,Er=new F,wr=new F,Tr=new F,Os=new F,Ar=new F,Lo=new F,Rr=new F;class at extends Ot{constructor(e=new Mt,t=new Li){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0?this.morphTargetInfluences=e.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,e.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const r=t[n[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=r.length;s<a;s++){const d=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[d]=s}}}}getVertexPosition(e,t){const n=this.geometry,r=n.attributes.position,s=n.morphAttributes.position,a=n.morphTargetsRelative;t.fromBufferAttribute(r,e);const d=this.morphTargetInfluences;if(s&&d){Ar.set(0,0,0);for(let l=0,o=s.length;l<o;l++){const f=d[l],h=s[l];f!==0&&(Os.fromBufferAttribute(h,e),a?Ar.addScaledVector(Os,f):Ar.addScaledVector(Os.sub(t),f))}t.add(Ar)}return t}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const n=this.geometry,r=this.material,s=this.matrixWorld;r!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),br.copy(n.boundingSphere),br.applyMatrix4(s),ii.copy(e.ray).recast(e.near),!(br.containsPoint(ii.origin)===!1&&(ii.intersectSphere(br,Po)===null||ii.origin.distanceToSquared(Po)>(e.far-e.near)**2))&&(Co.copy(s).invert(),ii.copy(e.ray).applyMatrix4(Co),!(n.boundingBox!==null&&ii.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,ii)))}_computeIntersections(e,t,n){let r;const s=this.geometry,a=this.material,d=s.index,l=s.attributes.position,o=s.attributes.uv,f=s.attributes.uv1,h=s.attributes.normal,u=s.groups,p=s.drawRange;if(d!==null)if(Array.isArray(a))for(let m=0,x=u.length;m<x;m++){const _=u[m],c=a[_.materialIndex],g=Math.max(_.start,p.start),S=Math.min(d.count,Math.min(_.start+_.count,p.start+p.count));for(let M=g,A=S;M<A;M+=3){const E=d.getX(M),v=d.getX(M+1),y=d.getX(M+2);r=Cr(this,c,e,n,o,f,h,E,v,y),r&&(r.faceIndex=Math.floor(M/3),r.face.materialIndex=_.materialIndex,t.push(r))}}else{const m=Math.max(0,p.start),x=Math.min(d.count,p.start+p.count);for(let _=m,c=x;_<c;_+=3){const g=d.getX(_),S=d.getX(_+1),M=d.getX(_+2);r=Cr(this,a,e,n,o,f,h,g,S,M),r&&(r.faceIndex=Math.floor(_/3),t.push(r))}}else if(l!==void 0)if(Array.isArray(a))for(let m=0,x=u.length;m<x;m++){const _=u[m],c=a[_.materialIndex],g=Math.max(_.start,p.start),S=Math.min(l.count,Math.min(_.start+_.count,p.start+p.count));for(let M=g,A=S;M<A;M+=3){const E=M,v=M+1,y=M+2;r=Cr(this,c,e,n,o,f,h,E,v,y),r&&(r.faceIndex=Math.floor(M/3),r.face.materialIndex=_.materialIndex,t.push(r))}}else{const m=Math.max(0,p.start),x=Math.min(l.count,p.start+p.count);for(let _=m,c=x;_<c;_+=3){const g=_,S=_+1,M=_+2;r=Cr(this,a,e,n,o,f,h,g,S,M),r&&(r.faceIndex=Math.floor(_/3),t.push(r))}}}}function uu(i,e,t,n,r,s,a,d){let l;if(e.side===Zt?l=n.intersectTriangle(a,s,r,!0,d):l=n.intersectTriangle(r,s,a,e.side===ai,d),l===null)return null;Rr.copy(d),Rr.applyMatrix4(i.matrixWorld);const o=t.ray.origin.distanceTo(Rr);return o<t.near||o>t.far?null:{distance:o,point:Rr.clone(),object:i}}function Cr(i,e,t,n,r,s,a,d,l,o){i.getVertexPosition(d,Er),i.getVertexPosition(l,wr),i.getVertexPosition(o,Tr);const f=uu(i,e,t,n,Er,wr,Tr,Lo);if(f){const h=new F;sn.getBarycoord(Lo,Er,wr,Tr,h),r&&(f.uv=sn.getInterpolatedAttribute(r,d,l,o,h,new Be)),s&&(f.uv1=sn.getInterpolatedAttribute(s,d,l,o,h,new Be)),a&&(f.normal=sn.getInterpolatedAttribute(a,d,l,o,h,new F),f.normal.dot(n.direction)>0&&f.normal.multiplyScalar(-1));const u={a:d,b:l,c:o,normal:new F,materialIndex:0};sn.getNormal(Er,wr,Tr,u.normal),f.face=u,f.barycoord=h}return f}class fu extends qt{constructor(e=null,t=1,n=1,r,s,a,d,l,o=Ft,f=Ft,h,u){super(null,a,d,l,o,f,r,s,h,u),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const ri=new as,hu=new Be(.5,.5),Pr=new F;class rr{constructor(e=new In,t=new In,n=new In,r=new In,s=new In,a=new In){this.planes=[e,t,n,r,s,a]}set(e,t,n,r,s,a){const d=this.planes;return d[0].copy(e),d[1].copy(t),d[2].copy(n),d[3].copy(r),d[4].copy(s),d[5].copy(a),this}copy(e){const t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=hn,n=!1){const r=this.planes,s=e.elements,a=s[0],d=s[1],l=s[2],o=s[3],f=s[4],h=s[5],u=s[6],p=s[7],m=s[8],x=s[9],_=s[10],c=s[11],g=s[12],S=s[13],M=s[14],A=s[15];if(r[0].setComponents(o-a,p-f,c-m,A-g).normalize(),r[1].setComponents(o+a,p+f,c+m,A+g).normalize(),r[2].setComponents(o+d,p+h,c+x,A+S).normalize(),r[3].setComponents(o-d,p-h,c-x,A-S).normalize(),n)r[4].setComponents(l,u,_,M).normalize(),r[5].setComponents(o-l,p-u,c-_,A-M).normalize();else if(r[4].setComponents(o-l,p-u,c-_,A-M).normalize(),t===hn)r[5].setComponents(o+l,p+u,c+_,A+M).normalize();else if(t===ir)r[5].setComponents(l,u,_,M).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),ri.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),ri.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(ri)}intersectsSprite(e){ri.center.set(0,0,0);const t=hu.distanceTo(e.center);return ri.radius=.7071067811865476+t,ri.applyMatrix4(e.matrixWorld),this.intersectsSphere(ri)}intersectsSphere(e){const t=this.planes,n=e.center,r=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(n)<r)return!1;return!0}intersectsBox(e){const t=this.planes;for(let n=0;n<6;n++){const r=t[n];if(Pr.x=r.normal.x>0?e.max.x:e.min.x,Pr.y=r.normal.y>0?e.max.y:e.min.y,Pr.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(Pr)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}const Do=new ft;class Ja{constructor(){this.coordinateSystem=hn,this._frustums=[],this._count=0}setFromArrayCamera(e){const t=e.cameras,n=this._frustums;for(let r=0;r<t.length;r++){const s=t[r];Do.multiplyMatrices(s.projectionMatrix,s.matrixWorldInverse),n[r]===void 0&&(n[r]=new rr),n[r].setFromProjectionMatrix(Do,s.coordinateSystem,s.reversedDepth)}return this._count=t.length,this}getFrustum(e){return this._frustums[e]}intersectsObject(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsObject(e))return!0;return!1}intersectsSprite(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsSprite(e))return!0;return!1}intersectsSphere(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsSphere(e))return!0;return!1}intersectsBox(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsBox(e))return!0;return!1}containsPoint(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].containsPoint(e))return!0;return!1}copy(e){this.coordinateSystem=e.coordinateSystem;const t=this._frustums,n=e._frustums;for(let r=0;r<e._count;r++)t[r]===void 0&&(t[r]=new rr),t[r].copy(n[r]);return this._count=e._count,this}clone(){return new Ja().copy(this)}}class sr extends Ui{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new We(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const ns=new F,is=new F,Io=new ft,Xi=new Ka,Lr=new as,Bs=new F,No=new F;class pu extends Ot{constructor(e=new Mt,t=new sr){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0?this.morphTargetInfluences=e.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,e.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[0];for(let r=1,s=t.count;r<s;r++)ns.fromBufferAttribute(t,r-1),is.fromBufferAttribute(t,r),n[r]=n[r-1],n[r]+=ns.distanceTo(is);e.setAttribute("lineDistance",new qe(n,1))}else Fe("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const n=this.geometry,r=this.matrixWorld,s=e.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Lr.copy(n.boundingSphere),Lr.applyMatrix4(r),Lr.radius+=s,e.ray.intersectsSphere(Lr)===!1)return;Io.copy(r).invert(),Xi.copy(e.ray).applyMatrix4(Io);const d=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=d*d,o=this.isLineSegments?2:1,f=n.index,u=n.attributes.position;if(f!==null){const p=Math.max(0,a.start),m=Math.min(f.count,a.start+a.count);for(let x=p,_=m-1;x<_;x+=o){const c=f.getX(x),g=f.getX(x+1),S=Dr(this,e,Xi,l,c,g,x);S&&t.push(S)}if(this.isLineLoop){const x=f.getX(m-1),_=f.getX(p),c=Dr(this,e,Xi,l,x,_,m-1);c&&t.push(c)}}else{const p=Math.max(0,a.start),m=Math.min(u.count,a.start+a.count);for(let x=p,_=m-1;x<_;x+=o){const c=Dr(this,e,Xi,l,x,x+1,x);c&&t.push(c)}if(this.isLineLoop){const x=Dr(this,e,Xi,l,m-1,p,m-1);x&&t.push(x)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const r=t[n[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=r.length;s<a;s++){const d=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[d]=s}}}}}function Dr(i,e,t,n,r,s,a){const d=i.geometry.attributes.position;if(ns.fromBufferAttribute(d,r),is.fromBufferAttribute(d,s),t.distanceSqToSegment(ns,is,Bs,No)>n)return;Bs.applyMatrix4(i.matrixWorld);const o=e.ray.origin.distanceTo(Bs);if(!(o<e.near||o>e.far))return{distance:o,point:No.clone().applyMatrix4(i.matrixWorld),index:a,face:null,faceIndex:null,barycoord:null,object:i}}const Uo=new F,Fo=new F;class rs extends pu{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[];for(let r=0,s=t.count;r<s;r+=2)Uo.fromBufferAttribute(t,r),Fo.fromBufferAttribute(t,r+1),n[r]=r===0?0:n[r-1],n[r+1]=n[r]+Uo.distanceTo(Fo);e.setAttribute("lineDistance",new qe(n,1))}else Fe("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class rc extends qt{constructor(e=[],t=Ci,n,r,s,a,d,l,o,f){super(e,t,n,r,s,a,d,l,o,f),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class Di extends qt{constructor(e,t,n=En,r,s,a,d=Ft,l=Ft,o,f=Yn,h=1){if(f!==Yn&&f!==qn)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const u={width:e,height:t,depth:h};super(u,r,s,a,d,l,f,n,o),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new $a(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return t.compareFunction=this.compareFunction,t}}class sc extends Di{constructor(e,t=En,n=Ci,r,s,a=Ft,d=Ft,l,o=Yn){const f={width:e,height:e,depth:1},h=[f,f,f,f,f,f];super(e,e,t,n,r,s,a,d,l,o),this.image=h,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class ac extends qt{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class Pt extends Mt{constructor(e=1,t=1,n=1,r=1,s=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:r,heightSegments:s,depthSegments:a};const d=this;r=Math.floor(r),s=Math.floor(s),a=Math.floor(a);const l=[],o=[],f=[],h=[];let u=0,p=0;m("z","y","x",-1,-1,n,t,e,a,s,0),m("z","y","x",1,-1,n,t,-e,a,s,1),m("x","z","y",1,1,e,n,t,r,a,2),m("x","z","y",1,-1,e,n,-t,r,a,3),m("x","y","z",1,-1,e,t,n,r,s,4),m("x","y","z",-1,-1,e,t,-n,r,s,5),this.setIndex(l),this.setAttribute("position",new qe(o,3)),this.setAttribute("normal",new qe(f,3)),this.setAttribute("uv",new qe(h,2));function m(x,_,c,g,S,M,A,E,v,y,T){const R=M/v,N=A/y,z=M/2,q=A/2,C=E/2,D=v+1,O=y+1;let k=0,Q=0;const G=new F;for(let K=0;K<O;K++){const j=K*N-q;for(let ce=0;ce<D;ce++){const ve=ce*R-z;G[x]=ve*g,G[_]=j*S,G[c]=C,o.push(G.x,G.y,G.z),G[x]=0,G[_]=0,G[c]=E>0?1:-1,f.push(G.x,G.y,G.z),h.push(ce/v),h.push(1-K/y),k+=1}}for(let K=0;K<y;K++)for(let j=0;j<v;j++){const ce=u+j+D*K,ve=u+j+D*(K+1),$=u+(j+1)+D*(K+1),ie=u+(j+1)+D*K;l.push(ce,ve,ie),l.push(ve,$,ie),Q+=6}d.addGroup(p,Q,T),p+=Q,u+=k}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Pt(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}class Ii extends Mt{constructor(e=1,t=32,n=0,r=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:n,thetaLength:r},t=Math.max(3,t);const s=[],a=[],d=[],l=[],o=new F,f=new Be;a.push(0,0,0),d.push(0,0,1),l.push(.5,.5);for(let h=0,u=3;h<=t;h++,u+=3){const p=n+h/t*r;o.x=e*Math.cos(p),o.y=e*Math.sin(p),a.push(o.x,o.y,o.z),d.push(0,0,1),f.x=(a[u]/e+1)/2,f.y=(a[u+1]/e+1)/2,l.push(f.x,f.y)}for(let h=1;h<=t;h++)s.push(h,h+1,0);this.setIndex(s),this.setAttribute("position",new qe(a,3)),this.setAttribute("normal",new qe(d,3)),this.setAttribute("uv",new qe(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ii(e.radius,e.segments,e.thetaStart,e.thetaLength)}}class gt extends Mt{constructor(e=1,t=1,n=1,r=32,s=1,a=!1,d=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:r,heightSegments:s,openEnded:a,thetaStart:d,thetaLength:l};const o=this;r=Math.floor(r),s=Math.floor(s);const f=[],h=[],u=[],p=[];let m=0;const x=[],_=n/2;let c=0;g(),a===!1&&(e>0&&S(!0),t>0&&S(!1)),this.setIndex(f),this.setAttribute("position",new qe(h,3)),this.setAttribute("normal",new qe(u,3)),this.setAttribute("uv",new qe(p,2));function g(){const M=new F,A=new F;let E=0;const v=(t-e)/n;for(let y=0;y<=s;y++){const T=[],R=y/s,N=R*(t-e)+e;for(let z=0;z<=r;z++){const q=z/r,C=q*l+d,D=Math.sin(C),O=Math.cos(C);A.x=N*D,A.y=-R*n+_,A.z=N*O,h.push(A.x,A.y,A.z),M.set(D,v,O).normalize(),u.push(M.x,M.y,M.z),p.push(q,1-R),T.push(m++)}x.push(T)}for(let y=0;y<r;y++)for(let T=0;T<s;T++){const R=x[T][y],N=x[T+1][y],z=x[T+1][y+1],q=x[T][y+1];(e>0||T!==0)&&(f.push(R,N,q),E+=3),(t>0||T!==s-1)&&(f.push(N,z,q),E+=3)}o.addGroup(c,E,0),c+=E}function S(M){const A=m,E=new Be,v=new F;let y=0;const T=M===!0?e:t,R=M===!0?1:-1;for(let z=1;z<=r;z++)h.push(0,_*R,0),u.push(0,R,0),p.push(.5,.5),m++;const N=m;for(let z=0;z<=r;z++){const C=z/r*l+d,D=Math.cos(C),O=Math.sin(C);v.x=T*O,v.y=_*R,v.z=T*D,h.push(v.x,v.y,v.z),u.push(0,R,0),E.x=D*.5+.5,E.y=O*.5*R+.5,p.push(E.x,E.y),m++}for(let z=0;z<r;z++){const q=A+z,C=N+z;M===!0?f.push(C,C+1,q):f.push(C+1,C,q),y+=3}o.addGroup(c,y,M===!0?1:2),c+=y}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new gt(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Qa extends Mt{constructor(e=[],t=[],n=1,r=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:n,detail:r};const s=[],a=[];d(r),o(n),f(),this.setAttribute("position",new qe(s,3)),this.setAttribute("normal",new qe(s.slice(),3)),this.setAttribute("uv",new qe(a,2)),r===0?this.computeVertexNormals():this.normalizeNormals();function d(g){const S=new F,M=new F,A=new F;for(let E=0;E<t.length;E+=3)p(t[E+0],S),p(t[E+1],M),p(t[E+2],A),l(S,M,A,g)}function l(g,S,M,A){const E=A+1,v=[];for(let y=0;y<=E;y++){v[y]=[];const T=g.clone().lerp(M,y/E),R=S.clone().lerp(M,y/E),N=E-y;for(let z=0;z<=N;z++)z===0&&y===E?v[y][z]=T:v[y][z]=T.clone().lerp(R,z/N)}for(let y=0;y<E;y++)for(let T=0;T<2*(E-y)-1;T++){const R=Math.floor(T/2);T%2===0?(u(v[y][R+1]),u(v[y+1][R]),u(v[y][R])):(u(v[y][R+1]),u(v[y+1][R+1]),u(v[y+1][R]))}}function o(g){const S=new F;for(let M=0;M<s.length;M+=3)S.x=s[M+0],S.y=s[M+1],S.z=s[M+2],S.normalize().multiplyScalar(g),s[M+0]=S.x,s[M+1]=S.y,s[M+2]=S.z}function f(){const g=new F;for(let S=0;S<s.length;S+=3){g.x=s[S+0],g.y=s[S+1],g.z=s[S+2];const M=_(g)/2/Math.PI+.5,A=c(g)/Math.PI+.5;a.push(M,1-A)}m(),h()}function h(){for(let g=0;g<a.length;g+=6){const S=a[g+0],M=a[g+2],A=a[g+4],E=Math.max(S,M,A),v=Math.min(S,M,A);E>.9&&v<.1&&(S<.2&&(a[g+0]+=1),M<.2&&(a[g+2]+=1),A<.2&&(a[g+4]+=1))}}function u(g){s.push(g.x,g.y,g.z)}function p(g,S){const M=g*3;S.x=e[M+0],S.y=e[M+1],S.z=e[M+2]}function m(){const g=new F,S=new F,M=new F,A=new F,E=new Be,v=new Be,y=new Be;for(let T=0,R=0;T<s.length;T+=9,R+=6){g.set(s[T+0],s[T+1],s[T+2]),S.set(s[T+3],s[T+4],s[T+5]),M.set(s[T+6],s[T+7],s[T+8]),E.set(a[R+0],a[R+1]),v.set(a[R+2],a[R+3]),y.set(a[R+4],a[R+5]),A.copy(g).add(S).add(M).divideScalar(3);const N=_(A);x(E,R+0,g,N),x(v,R+2,S,N),x(y,R+4,M,N)}}function x(g,S,M,A){A<0&&g.x===1&&(a[S]=g.x-1),M.x===0&&M.z===0&&(a[S]=A/2/Math.PI+.5)}function _(g){return Math.atan2(g.z,-g.x)}function c(g){return Math.atan2(-g.y,Math.sqrt(g.x*g.x+g.z*g.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Qa(e.vertices,e.indices,e.radius,e.detail)}}const Ir=new F,Nr=new F,zs=new F,Ur=new sn;class mu extends Mt{constructor(e=null,t=1){if(super(),this.type="EdgesGeometry",this.parameters={geometry:e,thresholdAngle:t},e!==null){const r=Math.pow(10,4),s=Math.cos($r*t),a=e.getIndex(),d=e.getAttribute("position"),l=a?a.count:d.count,o=[0,0,0],f=["a","b","c"],h=new Array(3),u=new Map,p=[];for(let m=0;m<l;m+=3){a?(o[0]=a.getX(m),o[1]=a.getX(m+1),o[2]=a.getX(m+2)):(o[0]=m,o[1]=m+1,o[2]=m+2);const{a:x,b:_,c}=Ur;if(x.fromBufferAttribute(d,o[0]),_.fromBufferAttribute(d,o[1]),c.fromBufferAttribute(d,o[2]),Ur.getNormal(zs),h[0]=`${Math.round(x.x*r)},${Math.round(x.y*r)},${Math.round(x.z*r)}`,h[1]=`${Math.round(_.x*r)},${Math.round(_.y*r)},${Math.round(_.z*r)}`,h[2]=`${Math.round(c.x*r)},${Math.round(c.y*r)},${Math.round(c.z*r)}`,!(h[0]===h[1]||h[1]===h[2]||h[2]===h[0]))for(let g=0;g<3;g++){const S=(g+1)%3,M=h[g],A=h[S],E=Ur[f[g]],v=Ur[f[S]],y=`${M}_${A}`,T=`${A}_${M}`,R=u.get(T);R?(zs.dot(R.normal)<=s&&(p.push(E.x,E.y,E.z),p.push(v.x,v.y,v.z)),u.set(T,null)):u.has(y)||u.set(y,{index0:o[g],index1:o[S],normal:zs.clone()})}}for(const m of u.values())if(m){const{index0:x,index1:_}=m;Ir.fromBufferAttribute(d,x),Nr.fromBufferAttribute(d,_),p.push(Ir.x,Ir.y,Ir.z),p.push(Nr.x,Nr.y,Nr.z)}this.setAttribute("position",new qe(p,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}}class an extends Qa{constructor(e=1,t=0){const n=(1+Math.sqrt(5))/2,r=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],s=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(r,s,e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new an(e.radius,e.detail)}}class or extends Mt{constructor(e=[new Be(0,-.5),new Be(.5,0),new Be(0,.5)],t=12,n=0,r=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:e,segments:t,phiStart:n,phiLength:r},t=Math.floor(t),r=Ze(r,0,Math.PI*2);const s=[],a=[],d=[],l=[],o=[],f=1/t,h=new F,u=new Be,p=new F,m=new F,x=new F;let _=0,c=0;for(let g=0;g<=e.length-1;g++)switch(g){case 0:_=e[g+1].x-e[g].x,c=e[g+1].y-e[g].y,p.x=c*1,p.y=-_,p.z=c*0,x.copy(p),p.normalize(),l.push(p.x,p.y,p.z);break;case e.length-1:x.normalize(),l.push(x.x,x.y,x.z);break;default:_=e[g+1].x-e[g].x,c=e[g+1].y-e[g].y,p.x=c*1,p.y=-_,p.z=c*0,m.copy(p),p.x+=x.x,p.y+=x.y,p.z+=x.z,p.normalize(),l.push(p.x,p.y,p.z),x.copy(m)}for(let g=0;g<=t;g++){const S=n+g*f*r,M=Math.sin(S),A=Math.cos(S);for(let E=0;E<=e.length-1;E++){h.x=e[E].x*M,h.y=e[E].y,h.z=e[E].x*A,a.push(h.x,h.y,h.z),u.x=g/t,u.y=E/(e.length-1),d.push(u.x,u.y);const v=l[3*E+0]*M,y=l[3*E+1],T=l[3*E+0]*A;o.push(v,y,T)}}for(let g=0;g<t;g++)for(let S=0;S<e.length-1;S++){const M=S+g*e.length,A=M,E=M+e.length,v=M+e.length+1,y=M+1;s.push(A,E,y),s.push(v,y,E)}this.setIndex(s),this.setAttribute("position",new qe(a,3)),this.setAttribute("uv",new qe(d,2)),this.setAttribute("normal",new qe(o,3))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new or(e.points,e.segments,e.phiStart,e.phiLength)}}class Fi extends Mt{constructor(e=1,t=1,n=1,r=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:r};const s=e/2,a=t/2,d=Math.floor(n),l=Math.floor(r),o=d+1,f=l+1,h=e/d,u=t/l,p=[],m=[],x=[],_=[];for(let c=0;c<f;c++){const g=c*u-a;for(let S=0;S<o;S++){const M=S*h-s;m.push(M,-g,0),x.push(0,0,1),_.push(S/d),_.push(1-c/l)}}for(let c=0;c<l;c++)for(let g=0;g<d;g++){const S=g+o*c,M=g+o*(c+1),A=g+1+o*(c+1),E=g+1+o*c;p.push(S,M,E),p.push(M,A,E)}this.setIndex(p),this.setAttribute("position",new qe(m,3)),this.setAttribute("normal",new qe(x,3)),this.setAttribute("uv",new qe(_,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Fi(e.width,e.height,e.widthSegments,e.heightSegments)}}class lr extends Mt{constructor(e=1,t=32,n=16,r=0,s=Math.PI*2,a=0,d=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:r,phiLength:s,thetaStart:a,thetaLength:d},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));const l=Math.min(a+d,Math.PI);let o=0;const f=[],h=new F,u=new F,p=[],m=[],x=[],_=[];for(let c=0;c<=n;c++){const g=[],S=c/n,M=a+S*d,A=e*Math.cos(M),E=Math.sqrt(e*e-A*A);let v=0;c===0&&a===0?v=.5/t:c===n&&l===Math.PI&&(v=-.5/t);for(let y=0;y<=t;y++){const T=y/t,R=r+T*s;h.x=-E*Math.cos(R),h.y=A,h.z=E*Math.sin(R),m.push(h.x,h.y,h.z),u.copy(h).normalize(),x.push(u.x,u.y,u.z),_.push(T+v,1-S),g.push(o++)}f.push(g)}for(let c=0;c<n;c++)for(let g=0;g<t;g++){const S=f[c][g+1],M=f[c][g],A=f[c+1][g],E=f[c+1][g+1];(c!==0||a>0)&&p.push(S,M,E),(c!==n-1||l<Math.PI)&&p.push(M,A,E)}this.setIndex(p),this.setAttribute("position",new qe(m,3)),this.setAttribute("normal",new qe(x,3)),this.setAttribute("uv",new qe(_,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new lr(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}function Ni(i){const e={};for(const t in i){e[t]={};for(const n in i[t]){const r=i[t][n];if(Oo(r))r.isRenderTargetTexture?(Fe("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=r.clone();else if(Array.isArray(r))if(Oo(r[0])){const s=[];for(let a=0,d=r.length;a<d;a++)s[a]=r[a].clone();e[t][n]=s}else e[t][n]=r.slice();else e[t][n]=r}}return e}function Xt(i){const e={};for(let t=0;t<i.length;t++){const n=Ni(i[t]);for(const r in n)e[r]=n[r]}return e}function Oo(i){return i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)}function gu(i){const e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function oc(i){const e=i.getRenderTarget();return e===null?i.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:Ke.workingColorSpace}const _u={clone:Ni,merge:Xt};var vu=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,xu=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class li extends Ui{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=vu,this.fragmentShader=xu,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Ni(e.uniforms),this.uniformsGroups=gu(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const r in this.uniforms){const a=this.uniforms[r].value;a&&a.isTexture?t.uniforms[r]={type:"t",value:a.toJSON(e).uuid}:a&&a.isColor?t.uniforms[r]={type:"c",value:a.getHex()}:a&&a.isVector2?t.uniforms[r]={type:"v2",value:a.toArray()}:a&&a.isVector3?t.uniforms[r]={type:"v3",value:a.toArray()}:a&&a.isVector4?t.uniforms[r]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?t.uniforms[r]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?t.uniforms[r]={type:"m4",value:a.toArray()}:t.uniforms[r]={value:a}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const n={};for(const r in this.extensions)this.extensions[r]===!0&&(n[r]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}fromJSON(e,t){if(super.fromJSON(e,t),e.uniforms!==void 0)for(const n in e.uniforms){const r=e.uniforms[n];switch(this.uniforms[n]={},r.type){case"t":this.uniforms[n].value=t[r.value]||null;break;case"c":this.uniforms[n].value=new We().setHex(r.value);break;case"v2":this.uniforms[n].value=new Be().fromArray(r.value);break;case"v3":this.uniforms[n].value=new F().fromArray(r.value);break;case"v4":this.uniforms[n].value=new wt().fromArray(r.value);break;case"m3":this.uniforms[n].value=new ke().fromArray(r.value);break;case"m4":this.uniforms[n].value=new ft().fromArray(r.value);break;default:this.uniforms[n].value=r.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(const n in e.extensions)this.extensions[n]=e.extensions[n];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}}class Mu extends li{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class Kt extends Ui{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new We(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new We(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=La,this.normalScale=new Be(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new $n,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Su extends Ui{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Rd,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class yu extends Ui{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}class lc extends Ot{static registerNode(e){this.prototype._lightNode=e}constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new We(e),this.intensity=t}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,t}}const ks=new ft,Bo=new F,zo=new F;class bu{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Be(512,512),this.mapType=en,this.map=null,this.mapPass=null,this.matrix=new ft,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new rr,this._frameExtents=new Be(1,1),this._viewportCount=1,this._viewports=[new wt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera;Bo.setFromMatrixPosition(e.matrixWorld),t.position.copy(Bo),zo.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(zo),t.updateMatrixWorld(),this._updateMatrix(t,this.matrix,this._frustum)}_updateMatrix(e,t,n,r){ks.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),n.setFromProjectionMatrix(ks,e.coordinateSystem,e.reversedDepth);const s=this._frameExtents,a=r?r.z/s.x:1,d=r?r.w/s.y:1,l=r?r.x/s.x:0,o=r?r.y/s.y:0;e.coordinateSystem===ir||e.reversedDepth?t.set(.5*a,0,0,.5*a+l,0,.5*d,0,.5*d+o,0,0,1,0,0,0,0,1):t.set(.5*a,0,0,.5*a+l,0,.5*d,0,.5*d+o,0,0,.5,.5,0,0,0,1),t.multiply(ks)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.mapType=e.mapType,this.biasNode=e.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return e.intensity=this.intensity,e.bias=this.bias,e.normalBias=this.normalBias,e.radius=this.radius,e.blurSamples=this.blurSamples,e.mapSize=this.mapSize.toArray(),e.mapType=this.mapType,e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}const Fr=new F,Or=new Zn,pn=new F;class cc extends Ot{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new ft,this.projectionMatrix=new ft,this.projectionMatrixInverse=new ft,this.coordinateSystem=hn,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(Fr,Or,pn),pn.x===1&&pn.y===1&&pn.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Fr,Or,pn.set(1,1,1)).invert()}updateWorldMatrix(e,t,n=!1){super.updateWorldMatrix(e,t,n),this.matrixWorld.decompose(Fr,Or,pn),pn.x===1&&pn.y===1&&pn.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Fr,Or,pn.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const Vn=new F,ko=new Be,Go=new Be;class gn extends cc{constructor(e=50,t=1,n=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=Da*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan($r*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Da*2*Math.atan(Math.tan($r*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){Vn.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Vn.x,Vn.y).multiplyScalar(-e/Vn.z),Vn.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Vn.x,Vn.y).multiplyScalar(-e/Vn.z)}getViewSize(e,t){return this.getViewBounds(e,ko,Go),t.subVectors(Go,ko)}setViewOffset(e,t,n,r,s,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan($r*.5*this.fov)/this.zoom,n=2*t,r=this.aspect*n,s=-.5*r;const a=this.view;if(this.view!==null&&this.view.enabled){const l=a.fullWidth,o=a.fullHeight;s+=a.offsetX*r/l,t-=a.offsetY*n/o,r*=a.width/l,n*=a.height/o}const d=this.filmOffset;d!==0&&(s+=e*d/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+r,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}class os extends cc{constructor(e=-1,t=1,n=1,r=-1,s=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=r,this.near=s,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,r,s,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,r=(this.top+this.bottom)/2;let s=n-e,a=n+e,d=r+t,l=r-t;if(this.view!==null&&this.view.enabled){const o=(this.right-this.left)/this.view.fullWidth/this.zoom,f=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=o*this.view.offsetX,a=s+o*this.view.width,d-=f*this.view.offsetY,l=d-f*this.view.height}this.projectionMatrix.makeOrthographic(s,a,d,l,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class Eu extends bu{constructor(){super(new os(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class wu extends lc{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Ot.DEFAULT_UP),this.updateMatrix(),this.target=new Ot,this.shadow=new Eu}dispose(){super.dispose(),this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}toJSON(e){const t=super.toJSON(e);return t.object.shadow=this.shadow.toJSON(),t.object.target=this.target.uuid,t}}class Tu extends lc{constructor(e,t){super(e,t),this.isAmbientLight=!0,this.type="AmbientLight"}}const Si=-90,yi=1;class Ia extends Ot{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const r=new gn(Si,yi,e,t);r.layers=this.layers,this.add(r);const s=new gn(Si,yi,e,t);s.layers=this.layers,this.add(s);const a=new gn(Si,yi,e,t);a.layers=this.layers,this.add(a);const d=new gn(Si,yi,e,t);d.layers=this.layers,this.add(d);const l=new gn(Si,yi,e,t);l.layers=this.layers,this.add(l);const o=new gn(Si,yi,e,t);o.layers=this.layers,this.add(o)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[n,r,s,a,d,l]=t;for(const o of t)this.remove(o);if(e===hn)n.up.set(0,1,0),n.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),d.up.set(0,1,0),d.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===ir)n.up.set(0,-1,0),n.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),d.up.set(0,-1,0),d.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const o of t)this.add(o),o.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[s,a,d,l,o,f]=this.children,h=e.getRenderTarget(),u=e.getActiveCubeFace(),p=e.getActiveMipmapLevel(),m=e.xr.enabled;e.xr.enabled=!1;const x=n.texture.mipmapsAutoUpdate;n.texture.mipmapsAutoUpdate=!1;let _=!1;e.isWebGLRenderer===!0?_=e.state.buffers.depth.getReversed():_=e.reversedDepthBuffer,e.setRenderTarget(n,0,r),_&&e.autoClear===!1&&e.clearDepth(),e.render(t,s),e.setRenderTarget(n,1,r),_&&e.autoClear===!1&&e.clearDepth(),e.render(t,a),e.setRenderTarget(n,2,r),_&&e.autoClear===!1&&e.clearDepth(),e.render(t,d),e.setRenderTarget(n,3,r),_&&e.autoClear===!1&&e.clearDepth(),e.render(t,l),e.setRenderTarget(n,4,r),_&&e.autoClear===!1&&e.clearDepth(),e.render(t,o),n.texture.mipmapsAutoUpdate=x,e.setRenderTarget(n,5,r),_&&e.autoClear===!1&&e.clearDepth(),e.render(t,f),e.setRenderTarget(h,u,p),e.xr.enabled=m,n.texture.needsPMREMUpdate=!0}}class Au extends gn{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e,this.perCameraFrustumCulled=!1}}const Ho=new ft;class ja{constructor(e,t,n=0,r=1/0){this.ray=new Ka(e,t),this.near=n,this.far=r,this.camera=null,this.layers=new Za,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,t.projectionMatrix.elements[14]).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):nt("Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return Ho.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(Ho),this}intersectObject(e,t=!0,n=[]){return Na(e,this,n,t),n.sort(Vo),n}intersectObjects(e,t=!0,n=[]){for(let r=0,s=e.length;r<s;r++)Na(e[r],this,n,t);return n.sort(Vo),n}}function Vo(i,e){return i.distance-e.distance}function Na(i,e,t,n){let r=!0;if(i.layers.test(e.layers)&&i.raycast(e,t)===!1&&(r=!1),r===!0&&n===!0){const s=i.children;for(let a=0,d=s.length;a<d;a++)Na(s[a],e,t,!0)}}class Ru extends rs{constructor(e,t=16776960){const n=new Uint16Array([0,1,1,2,2,3,3,0,4,5,5,6,6,7,7,4,0,4,1,5,2,6,3,7]),r=[1,1,1,-1,1,1,-1,-1,1,1,-1,1,1,1,-1,-1,1,-1,-1,-1,-1,1,-1,-1],s=new Mt;s.setIndex(new On(n,1)),s.setAttribute("position",new qe(r,3)),super(s,new sr({color:t,toneMapped:!1})),this.box=e,this.type="Box3Helper",this.geometry.computeBoundingSphere()}updateMatrixWorld(e){const t=this.box;t.isEmpty()||(t.getCenter(this.position),t.getSize(this.scale),this.scale.multiplyScalar(.5),super.updateMatrixWorld(e))}dispose(){super.dispose(),this.geometry.dispose(),this.material.dispose()}}function Wo(i,e,t,n){const r=Cu(n);switch(t){case Yl:return i*e;case Zl:return i*e/r.components*r.byteLength;case Wa:return i*e/r.components*r.byteLength;case oi:return i*e*2/r.components*r.byteLength;case Xa:return i*e*2/r.components*r.byteLength;case $l:return i*e*3/r.components*r.byteLength;case Sn:return i*e*4/r.components*r.byteLength;case qa:return i*e*4/r.components*r.byteLength;case Vr:case Wr:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case Xr:case qr:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case na:case ra:return Math.max(i,16)*Math.max(e,8)/4;case ta:case ia:return Math.max(i,8)*Math.max(e,8)/2;case sa:case aa:case la:case ca:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case oa:case Jr:case da:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case ua:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case fa:return Math.floor((i+4)/5)*Math.floor((e+3)/4)*16;case ha:return Math.floor((i+4)/5)*Math.floor((e+4)/5)*16;case pa:return Math.floor((i+5)/6)*Math.floor((e+4)/5)*16;case ma:return Math.floor((i+5)/6)*Math.floor((e+5)/6)*16;case ga:return Math.floor((i+7)/8)*Math.floor((e+4)/5)*16;case _a:return Math.floor((i+7)/8)*Math.floor((e+5)/6)*16;case va:return Math.floor((i+7)/8)*Math.floor((e+7)/8)*16;case xa:return Math.floor((i+9)/10)*Math.floor((e+4)/5)*16;case Ma:return Math.floor((i+9)/10)*Math.floor((e+5)/6)*16;case Sa:return Math.floor((i+9)/10)*Math.floor((e+7)/8)*16;case ya:return Math.floor((i+9)/10)*Math.floor((e+9)/10)*16;case ba:return Math.floor((i+11)/12)*Math.floor((e+9)/10)*16;case Ea:return Math.floor((i+11)/12)*Math.floor((e+11)/12)*16;case wa:case Ta:case Aa:return Math.ceil(i/4)*Math.ceil(e/4)*16;case Ra:case Ca:return Math.ceil(i/4)*Math.ceil(e/4)*8;case Qr:case Pa:return Math.ceil(i/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function Cu(i){switch(i){case en:case Vl:return{byteLength:1,components:1};case nr:case Wl:case wn:return{byteLength:2,components:1};case Ha:case Va:return{byteLength:2,components:4};case En:case Ga:case Mn:return{byteLength:4,components:1};case Xl:case ql:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${i}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:ka}}));typeof window<"u"&&(window.__THREE__?Fe("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=ka);/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function dc(){let i=null,e=!1,t=null,n=null;function r(s,a){n=i.requestAnimationFrame(r),t(s,a)}return{start:function(){e!==!0&&t!==null&&i!==null&&(n=i.requestAnimationFrame(r),e=!0)},stop:function(){i!==null&&i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){i=s}}}function Pu(i){const e=new WeakMap;function t(d,l){const o=d.array,f=d.usage,h=o.byteLength,u=i.createBuffer();i.bindBuffer(l,u),i.bufferData(l,o,f),d.onUploadCallback();let p;if(o instanceof Float32Array)p=i.FLOAT;else if(typeof Float16Array<"u"&&o instanceof Float16Array)p=i.HALF_FLOAT;else if(o instanceof Uint16Array)d.isFloat16BufferAttribute?p=i.HALF_FLOAT:p=i.UNSIGNED_SHORT;else if(o instanceof Int16Array)p=i.SHORT;else if(o instanceof Uint32Array)p=i.UNSIGNED_INT;else if(o instanceof Int32Array)p=i.INT;else if(o instanceof Int8Array)p=i.BYTE;else if(o instanceof Uint8Array)p=i.UNSIGNED_BYTE;else if(o instanceof Uint8ClampedArray)p=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+o);return{buffer:u,type:p,bytesPerElement:o.BYTES_PER_ELEMENT,version:d.version,size:h}}function n(d,l,o){const f=l.array,h=l.updateRanges;if(i.bindBuffer(o,d),h.length===0)i.bufferSubData(o,0,f);else{h.sort((p,m)=>p.start-m.start);let u=0;for(let p=1;p<h.length;p++){const m=h[u],x=h[p];x.start<=m.start+m.count+1?m.count=Math.max(m.count,x.start+x.count-m.start):(++u,h[u]=x)}h.length=u+1;for(let p=0,m=h.length;p<m;p++){const x=h[p];i.bufferSubData(o,x.start*f.BYTES_PER_ELEMENT,f,x.start,x.count)}l.clearUpdateRanges()}l.onUploadCallback()}function r(d){return d.isInterleavedBufferAttribute&&(d=d.data),e.get(d)}function s(d){d.isInterleavedBufferAttribute&&(d=d.data);const l=e.get(d);l&&(i.deleteBuffer(l.buffer),e.delete(d))}function a(d,l){if(d.isInterleavedBufferAttribute&&(d=d.data),d.isGLBufferAttribute){const f=e.get(d);(!f||f.version<d.version)&&e.set(d,{buffer:d.buffer,type:d.type,bytesPerElement:d.elementSize,version:d.version});return}const o=e.get(d);if(o===void 0)e.set(d,t(d,l));else if(o.version<d.version){if(o.size!==d.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(o.buffer,d,l),o.version=d.version}}return{get:r,remove:s,update:a}}var Lu=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Du=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Iu=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Nu=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Uu=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Fu=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Ou=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Bu=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,zu=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,ku=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Gu=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Hu=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Vu=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Wu=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Xu=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,qu=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Yu=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,$u=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Zu=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Ku=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,Ju=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,Qu=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,ju=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,ef=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,tf=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,nf=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,rf=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,sf=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,af=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,of="gl_FragColor = linearToOutputTexel( gl_FragColor );",lf=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,cf=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,df=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	uniform samplerCube envMap;
	#ifdef ENVMAP_TYPE_PMREM
		float roughnessToMip( const in float roughness ) {
			float r = clamp( roughness, 0.0, 1.0 );
			return ENVMAP_MAX_LOD * r * ( 2.0 - r );
		}
	#endif
#endif`,uf=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,ff=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,hf=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,pf=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,mf=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,gf=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,_f=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,vf=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,xf=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Mf=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Sf=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,yf=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,bf=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * worldNormal, ENVMAP_MAX_LOD );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * reflectVec, roughnessToMip( roughness ) );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureLod( envMap, envMapRotation * retroVec, roughnessToMip( roughness ) );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_PMREM
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,Ef=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,wf=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Tf=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Af=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Rf=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.045 );
material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef USE_DIFFUSE_ROUGHNESS
	float diffuseRoughnessFactor = diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		diffuseRoughnessFactor *= texture2D( diffuseRoughnessMap, vDiffuseRoughnessMapUv ).r;
	#endif
	material.diffuseRoughness = saturate( diffuseRoughnessFactor );
#endif
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.045 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Cf=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float diffuseRoughness;
	#endif
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
#ifdef USE_DIFFUSE_ROUGHNESS
	const float EON_EPSILON = 1e-7;
	float FON_DirectionalAlbedo( const in float mu, const in float roughness, const in float A ) {
		float muComp = 1.0 - mu;
		float gOverPi = muComp * ( 0.0571085289 + muComp * ( 0.491881867 + muComp * ( - 0.332181442 + muComp * 0.0714429953 ) ) );
		return A * ( 1.0 + roughness * gOverPi );
	}
	vec3 BRDF_EON( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 diffuseColor, const in float roughness ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return BRDF_Lambert( rho );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float s = dot( lightDir, viewDir ) - dotNL * dotNV;
		float sOverT = ( s > 0.0 ) ? s / max( max( dotNL, dotNV ), EON_EPSILON ) : s;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		vec3 singleScatter = rho * RECIPROCAL_PI * A * ( 1.0 + roughness * sOverT );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		float albedoV = FON_DirectionalAlbedo( dotNV, roughness, A );
		float albedoL = FON_DirectionalAlbedo( dotNL, roughness, A );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		vec3 multiScatter = rhoMultiScatter * RECIPROCAL_PI
			* max( EON_EPSILON, 1.0 - albedoV )
			* max( EON_EPSILON, 1.0 - albedoL )
			/ max( EON_EPSILON, 1.0 - averageAlbedo );
		return singleScatter + multiScatter;
	}
	vec3 EON_DirectionalAlbedo( const in vec3 diffuseColor, const in float roughness, const in float dotNV ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return rho;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		float directionalAlbedo = FON_DirectionalAlbedo( dotNV, roughness, A );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		return rho * directionalAlbedo + rhoMultiScatter * ( 1.0 - directionalAlbedo );
	}
#endif
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = max( material.clearcoatRoughness, 0.045 );
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = max( material.roughness, 0.045 );
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float alphaT = max( material.alphaT, alpha );
		float V = V_GGX_SmithCorrelated_Anisotropic( alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		vec3 diffuseBRDF = BRDF_EON( directLight.direction, geometryViewDir, geometryNormal, material.diffuseColor, material.diffuseRoughness ) * ( 1.0 - material.metalness );
	#else
		vec3 diffuseBRDF = BRDF_Lambert( material.diffuseContribution );
	#endif
	reflectedLight.directDiffuse += irradiance * diffuseBRDF * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuseAlbedo = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness );
		vec3 diffuse = irradiance * RECIPROCAL_PI * diffuseAlbedo * ( 1.0 - singleScattering - multiScattering );
	#else
		vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#endif
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuse = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness ) * ( 1.0 - totalScatteringDielectric );
	#else
		vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	#endif
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Pf=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_LIGHT_PROBE_GRIDS > 0
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		int probeGrid = - 1;
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( isInsideLightProbeGrid( probeWorldPos, probeWorldNormal, probesMin[ i ], probesMax[ i ], probesResolution[ i ] ) ) probeGrid = UNROLLED_LOOP_INDEX;
		}
		#pragma unroll_loop_end
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( probeGrid == UNROLLED_LOOP_INDEX ) irradiance += getLightProbeGridIrradiance( probesSH[ i ], probesMin[ i ], probesMax[ i ], probesResolution[ i ], probeWorldPos, probeWorldNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Lf=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_PMREM )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Df=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,If=`#if NUM_LIGHT_PROBE_GRIDS > 0
uniform highp sampler3D probesSH[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMin[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMax[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesResolution[ NUM_LIGHT_PROBE_GRIDS ];
bool isInsideLightProbeGrid( vec3 worldPos, vec3 worldNormal, vec3 probesMin, vec3 probesMax, vec3 probesResolution ) {
	vec3 spacing = ( probesMax - probesMin ) / probesResolution;
	vec3 samplePos = worldPos + worldNormal * spacing * 0.5;
	vec3 margin = spacing * 0.01;
	return all( greaterThanEqual( samplePos, probesMin - margin ) ) && all( lessThanEqual( samplePos, probesMax + margin ) );
}
vec3 getLightProbeGridIrradiance( highp sampler3D probesSH, vec3 probesMin, vec3 probesMax, vec3 probesResolution, vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 probeSpacing = gridRange / res;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.5 / res, 1.0 - 0.5 / res );
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,Nf=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Uf=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Ff=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Of=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,Bf=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,zf=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,kf=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Gf=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Hf=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Vf=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Wf=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Xf=`#if defined( USE_MORPHCOLORS )
	#if defined( USE_COLOR_ALPHA )
		vColor *= morphTargetBaseInfluence;
	#elif defined( USE_COLOR )
		vColor.rgb *= morphTargetBaseInfluence;
	#endif
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor.rgb += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,qf=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Yf=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,$f=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Zf=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Kf=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Jf=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Qf=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,jf=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,eh=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,th=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,nh=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,ih=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,rh=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,sh=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,ah=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,oh=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,lh=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,ch=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,dh=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,uh=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,fh=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,hh=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				vec2 radius = shadowRadius * texelSize;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float lightDistance = length( lightToPosition );
			float depthRange = shadowCameraFar - shadowCameraNear;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float depthA = - shadowCameraNear / depthRange - shadowBias;
				float depthB = shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#else
				float depthA = shadowCameraFar / depthRange + shadowBias;
				float depthB = - shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			shadow = 0.0;
			for ( int i = 0; i < 5; i ++ ) {
				vec2 offset = vogelDiskSample( i, 5, phi );
				vec3 direction = bd3D + ( tangent * offset.x + bitangent * offset.y ) * texelSize;
				vec3 absDirection = abs( direction );
				float dp = depthA + depthB / max( max( absDirection.x, absDirection.y ), absDirection.z );
				shadow += texture( shadowMap, vec4( direction, dp ) );
			}
			shadow *= 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,ph=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,mh=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,gh=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,_h=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,vh=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,xh=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Mh=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Sh=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,yh=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,bh=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Eh=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,wh=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Th=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Ah=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Rh=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	uniform mat3 diffuseRoughnessMapTransform;
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Ch=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	vDiffuseRoughnessMapUv = ( diffuseRoughnessMapTransform * vec3( DIFFUSE_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Ph=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Lh=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Dh=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Ih=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Nh=`uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <envmap_common_pars_fragment>
void main() {
	#ifdef ENVMAP_TYPE_PMREM
		vec4 texColor = textureLod( envMap, backgroundRotation * vWorldDirection, roughnessToMip( backgroundBlurriness ) );
	#else
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Uh=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Fh=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Oh=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Bh=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,zh=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,kh=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,Gh=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Hh=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Vh=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Wh=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Xh=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,qh=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Yh=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,$h=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Zh=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Kh=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Jh=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Qh=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,jh=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ep=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,tp=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,np=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DIFFUSE_ROUGHNESS
	uniform float diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		uniform sampler2D diffuseRoughnessMap;
	#endif
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ip=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,rp=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,sp=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,ap=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,op=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,lp=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,cp=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,dp=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Ge={alphahash_fragment:Lu,alphahash_pars_fragment:Du,alphamap_fragment:Iu,alphamap_pars_fragment:Nu,alphatest_fragment:Uu,alphatest_pars_fragment:Fu,aomap_fragment:Ou,aomap_pars_fragment:Bu,batching_pars_vertex:zu,batching_vertex:ku,begin_vertex:Gu,beginnormal_vertex:Hu,bsdfs:Vu,iridescence_fragment:Wu,bumpmap_pars_fragment:Xu,clipping_planes_fragment:qu,clipping_planes_pars_fragment:Yu,clipping_planes_pars_vertex:$u,clipping_planes_vertex:Zu,color_fragment:Ku,color_pars_fragment:Ju,color_pars_vertex:Qu,color_vertex:ju,common:ef,defaultnormal_vertex:tf,displacementmap_pars_vertex:nf,displacementmap_vertex:rf,emissivemap_fragment:sf,emissivemap_pars_fragment:af,colorspace_fragment:of,colorspace_pars_fragment:lf,envmap_fragment:cf,envmap_common_pars_fragment:df,envmap_pars_fragment:uf,envmap_pars_vertex:ff,envmap_physical_pars_fragment:bf,envmap_vertex:hf,fog_vertex:pf,fog_pars_vertex:mf,fog_fragment:gf,fog_pars_fragment:_f,gradientmap_pars_fragment:vf,lightmap_pars_fragment:xf,lights_lambert_fragment:Mf,lights_lambert_pars_fragment:Sf,lights_pars_begin:yf,lights_toon_fragment:Ef,lights_toon_pars_fragment:wf,lights_phong_fragment:Tf,lights_phong_pars_fragment:Af,lights_physical_fragment:Rf,lights_physical_pars_fragment:Cf,lights_fragment_begin:Pf,lights_fragment_maps:Lf,lights_fragment_end:Df,lightprobes_pars_fragment:If,logdepthbuf_fragment:Nf,logdepthbuf_pars_fragment:Uf,logdepthbuf_pars_vertex:Ff,logdepthbuf_vertex:Of,map_fragment:Bf,map_pars_fragment:zf,map_particle_fragment:kf,map_particle_pars_fragment:Gf,metalnessmap_fragment:Hf,metalnessmap_pars_fragment:Vf,morphinstance_vertex:Wf,morphcolor_vertex:Xf,morphnormal_vertex:qf,morphtarget_pars_vertex:Yf,morphtarget_vertex:$f,normal_fragment_begin:Zf,normal_fragment_maps:Kf,normal_pars_fragment:Jf,normal_pars_vertex:Qf,normal_vertex:jf,normalmap_pars_fragment:eh,clearcoat_normal_fragment_begin:th,clearcoat_normal_fragment_maps:nh,clearcoat_pars_fragment:ih,iridescence_pars_fragment:rh,opaque_fragment:sh,packing:ah,premultiplied_alpha_fragment:oh,project_vertex:lh,dithering_fragment:ch,dithering_pars_fragment:dh,roughnessmap_fragment:uh,roughnessmap_pars_fragment:fh,shadowmap_pars_fragment:hh,shadowmap_pars_vertex:ph,shadowmap_vertex:mh,shadowmask_pars_fragment:gh,skinbase_vertex:_h,skinning_pars_vertex:vh,skinning_vertex:xh,skinnormal_vertex:Mh,specularmap_fragment:Sh,specularmap_pars_fragment:yh,tonemapping_fragment:bh,tonemapping_pars_fragment:Eh,transmission_fragment:wh,transmission_pars_fragment:Th,uv_pars_fragment:Ah,uv_pars_vertex:Rh,uv_vertex:Ch,worldpos_vertex:Ph,background_vert:Lh,background_frag:Dh,backgroundCube_vert:Ih,backgroundCube_frag:Nh,cube_vert:Uh,cube_frag:Fh,depth_vert:Oh,depth_frag:Bh,distance_vert:zh,distance_frag:kh,equirect_vert:Gh,equirect_frag:Hh,linedashed_vert:Vh,linedashed_frag:Wh,meshbasic_vert:Xh,meshbasic_frag:qh,meshlambert_vert:Yh,meshlambert_frag:$h,meshmatcap_vert:Zh,meshmatcap_frag:Kh,meshnormal_vert:Jh,meshnormal_frag:Qh,meshphong_vert:jh,meshphong_frag:ep,meshphysical_vert:tp,meshphysical_frag:np,meshtoon_vert:ip,meshtoon_frag:rp,points_vert:sp,points_frag:ap,shadow_vert:op,shadow_frag:lp,sprite_vert:cp,sprite_frag:dp},xe={common:{diffuse:{value:new We(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new ke},alphaMap:{value:null},alphaMapTransform:{value:new ke},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new ke}},envmap:{envMap:{value:null},envMapRotation:{value:new ke},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new ke}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new ke}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new ke},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new ke},normalScale:{value:new Be(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new ke},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new ke}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new ke}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new ke}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new We(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:[]},probesMin:{value:[]},probesMax:{value:[]},probesResolution:{value:[]}},points:{diffuse:{value:new We(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new ke},alphaTest:{value:0},uvTransform:{value:new ke}},sprite:{diffuse:{value:new We(16777215)},opacity:{value:1},center:{value:new Be(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new ke},alphaMap:{value:null},alphaMapTransform:{value:new ke},alphaTest:{value:0}}},_n={basic:{uniforms:Xt([xe.common,xe.specularmap,xe.envmap,xe.aomap,xe.lightmap,xe.fog]),vertexShader:Ge.meshbasic_vert,fragmentShader:Ge.meshbasic_frag},lambert:{uniforms:Xt([xe.common,xe.specularmap,xe.envmap,xe.aomap,xe.lightmap,xe.emissivemap,xe.bumpmap,xe.normalmap,xe.displacementmap,xe.fog,xe.lights,{emissive:{value:new We(0)},envMapIntensity:{value:1}}]),vertexShader:Ge.meshlambert_vert,fragmentShader:Ge.meshlambert_frag},phong:{uniforms:Xt([xe.common,xe.specularmap,xe.envmap,xe.aomap,xe.lightmap,xe.emissivemap,xe.bumpmap,xe.normalmap,xe.displacementmap,xe.fog,xe.lights,{emissive:{value:new We(0)},specular:{value:new We(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:Ge.meshphong_vert,fragmentShader:Ge.meshphong_frag},standard:{uniforms:Xt([xe.common,xe.envmap,xe.aomap,xe.lightmap,xe.emissivemap,xe.bumpmap,xe.normalmap,xe.displacementmap,xe.roughnessmap,xe.metalnessmap,xe.fog,xe.lights,{emissive:{value:new We(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Ge.meshphysical_vert,fragmentShader:Ge.meshphysical_frag},toon:{uniforms:Xt([xe.common,xe.aomap,xe.lightmap,xe.emissivemap,xe.bumpmap,xe.normalmap,xe.displacementmap,xe.gradientmap,xe.fog,xe.lights,{emissive:{value:new We(0)}}]),vertexShader:Ge.meshtoon_vert,fragmentShader:Ge.meshtoon_frag},matcap:{uniforms:Xt([xe.common,xe.bumpmap,xe.normalmap,xe.displacementmap,xe.fog,{matcap:{value:null}}]),vertexShader:Ge.meshmatcap_vert,fragmentShader:Ge.meshmatcap_frag},points:{uniforms:Xt([xe.points,xe.fog]),vertexShader:Ge.points_vert,fragmentShader:Ge.points_frag},dashed:{uniforms:Xt([xe.common,xe.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Ge.linedashed_vert,fragmentShader:Ge.linedashed_frag},depth:{uniforms:Xt([xe.common,xe.displacementmap]),vertexShader:Ge.depth_vert,fragmentShader:Ge.depth_frag},normal:{uniforms:Xt([xe.common,xe.bumpmap,xe.normalmap,xe.displacementmap,{opacity:{value:1}}]),vertexShader:Ge.meshnormal_vert,fragmentShader:Ge.meshnormal_frag},sprite:{uniforms:Xt([xe.sprite,xe.fog]),vertexShader:Ge.sprite_vert,fragmentShader:Ge.sprite_frag},background:{uniforms:{uvTransform:{value:new ke},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Ge.background_vert,fragmentShader:Ge.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new ke}},vertexShader:Ge.backgroundCube_vert,fragmentShader:Ge.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Ge.cube_vert,fragmentShader:Ge.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Ge.equirect_vert,fragmentShader:Ge.equirect_frag},distance:{uniforms:Xt([xe.common,xe.displacementmap,{referencePosition:{value:new F},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Ge.distance_vert,fragmentShader:Ge.distance_frag},shadow:{uniforms:Xt([xe.lights,xe.fog,{color:{value:new We(0)},opacity:{value:1}}]),vertexShader:Ge.shadow_vert,fragmentShader:Ge.shadow_frag}};_n.physical={uniforms:Xt([_n.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new ke},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new ke},clearcoatNormalScale:{value:new Be(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new ke},diffuseRoughness:{value:0},diffuseRoughnessMap:{value:null},diffuseRoughnessMapTransform:{value:new ke},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new ke},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new ke},sheen:{value:0},sheenColor:{value:new We(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new ke},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new ke},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new ke},transmissionSamplerSize:{value:new Be},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new ke},attenuationDistance:{value:0},attenuationColor:{value:new We(0)},specularColor:{value:new We(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new ke},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new ke},anisotropyVector:{value:new Be},anisotropyMap:{value:null},anisotropyMapTransform:{value:new ke}}]),vertexShader:Ge.meshphysical_vert,fragmentShader:Ge.meshphysical_frag};const Br={r:0,b:0,g:0},up=new ft,uc=new ke;uc.set(-1,0,0,0,1,0,0,0,1);function fp(i,e,t,n,r,s){const a=new We(0);let d=r===!0?0:1,l,o,f=null,h=0,u=null;function p(g){let S=g.isScene===!0?g.background:null;if(S&&S.isTexture){const M=g.backgroundBlurriness>0;S=e.get(S,M)}return S}function m(g){let S=!1;const M=p(g);M===null?_(a,d):M&&M.isColor&&(_(M,1),S=!0);const A=i.xr.getEnvironmentBlendMode();A==="additive"?t.buffers.color.setClear(0,0,0,1,s):A==="alpha-blend"&&t.buffers.color.setClear(0,0,0,0,s),(i.autoClear||S)&&(t.buffers.depth.setTest(!0),t.buffers.depth.setMask(!0),t.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function x(g,S){const M=p(S);M&&M.isCubeTexture?(o===void 0&&(o=new at(new Pt(1,1,1),new li({name:"BackgroundCubeMaterial",uniforms:Ni(_n.backgroundCube.uniforms),vertexShader:_n.backgroundCube.vertexShader,fragmentShader:_n.backgroundCube.fragmentShader,side:Zt,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),o.geometry.deleteAttribute("normal"),o.geometry.deleteAttribute("uv"),o.onBeforeRender=function(A,E,v){this.matrixWorld.copyPosition(v.matrixWorld)},Object.defineProperty(o.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),n.update(o)),o.material.uniforms.envMap.value=M,o.material.uniforms.backgroundBlurriness.value=S.backgroundBlurriness,o.material.uniforms.backgroundIntensity.value=S.backgroundIntensity,o.material.uniforms.backgroundRotation.value.setFromMatrix4(up.makeRotationFromEuler(S.backgroundRotation)).transpose(),M.isRenderTargetTexture===!1&&o.material.uniforms.backgroundRotation.value.premultiply(uc),o.material.toneMapped=Ke.getTransfer(M.colorSpace)!==st,(f!==M||h!==M.version||u!==i.toneMapping)&&(o.material.needsUpdate=!0,f=M,h=M.version,u=i.toneMapping),o.layers.enableAll(),g.unshift(o,o.geometry,o.material,0,0,null)):M&&M.isTexture&&(l===void 0&&(l=new at(new Fi(2,2),new li({name:"BackgroundMaterial",uniforms:Ni(_n.background.uniforms),vertexShader:_n.background.vertexShader,fragmentShader:_n.background.fragmentShader,side:ai,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),n.update(l)),l.material.uniforms.t2D.value=M,l.material.uniforms.backgroundIntensity.value=S.backgroundIntensity,l.material.toneMapped=Ke.getTransfer(M.colorSpace)!==st,M.matrixAutoUpdate===!0&&M.updateMatrix(),l.material.uniforms.uvTransform.value.copy(M.matrix),(f!==M||h!==M.version||u!==i.toneMapping)&&(l.material.needsUpdate=!0,f=M,h=M.version,u=i.toneMapping),l.layers.enableAll(),g.unshift(l,l.geometry,l.material,0,0,null))}function _(g,S){g.getRGB(Br,oc(i)),t.buffers.color.setClear(Br.r,Br.g,Br.b,S,s)}function c(){o!==void 0&&(o.geometry.dispose(),o.material.dispose(),o=void 0),l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0)}return{getClearColor:function(){return a},setClearColor:function(g,S=1){a.set(g),d=S,_(a,d)},getClearAlpha:function(){return d},setClearAlpha:function(g){d=g,_(a,d)},render:m,addToRenderList:x,dispose:c}}function hp(i,e){const t=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},r=u(null);let s=r,a=!1;function d(N,z,q,C,D){let O=!1;const k=h(N,C,q,z);s!==k&&(s=k,o(s.object)),O=p(N,C,q,D),O&&m(N,C,q,D),D!==null&&e.update(D,i.ELEMENT_ARRAY_BUFFER),(O||a)&&(a=!1,M(N,z,q,C),D!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(D).buffer))}function l(){return i.createVertexArray()}function o(N){return i.bindVertexArray(N)}function f(N){return i.deleteVertexArray(N)}function h(N,z,q,C){const D=C.wireframe===!0;let O=n[z.id];O===void 0&&(O={},n[z.id]=O);const k=N.isInstancedMesh===!0?N.id:0;let Q=O[k];Q===void 0&&(Q={},O[k]=Q);let G=Q[q.id];G===void 0&&(G={},Q[q.id]=G);let K=G[D];return K===void 0&&(K=u(l()),G[D]=K),K}function u(N){const z=[],q=[],C=[];for(let D=0;D<t;D++)z[D]=0,q[D]=0,C[D]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:z,enabledAttributes:q,attributeDivisors:C,object:N,attributes:{},index:null}}function p(N,z,q,C){const D=s.attributes,O=z.attributes;let k=0;const Q=q.getAttributes();for(const G in Q)if(Q[G].location>=0){const j=D[G];let ce=O[G];if(ce===void 0&&(G==="instanceMatrix"&&N.instanceMatrix&&(ce=N.instanceMatrix),G==="instanceColor"&&N.instanceColor&&(ce=N.instanceColor)),j===void 0||j.attribute!==ce||ce&&j.data!==ce.data)return!0;k++}return s.attributesNum!==k||s.index!==C}function m(N,z,q,C){const D={},O=z.attributes;let k=0;const Q=q.getAttributes();for(const G in Q)if(Q[G].location>=0){let j=O[G];j===void 0&&(G==="instanceMatrix"&&N.instanceMatrix&&(j=N.instanceMatrix),G==="instanceColor"&&N.instanceColor&&(j=N.instanceColor));const ce={};ce.attribute=j,j&&j.data&&(ce.data=j.data),D[G]=ce,k++}s.attributes=D,s.attributesNum=k,s.index=C}function x(){const N=s.newAttributes;for(let z=0,q=N.length;z<q;z++)N[z]=0}function _(N){c(N,0)}function c(N,z){const q=s.newAttributes,C=s.enabledAttributes,D=s.attributeDivisors;q[N]=1,C[N]===0&&(i.enableVertexAttribArray(N),C[N]=1),D[N]!==z&&(i.vertexAttribDivisor(N,z),D[N]=z)}function g(){const N=s.newAttributes,z=s.enabledAttributes;for(let q=0,C=z.length;q<C;q++)z[q]!==N[q]&&(i.disableVertexAttribArray(q),z[q]=0)}function S(N,z,q,C,D,O,k){k===!0?i.vertexAttribIPointer(N,z,q,D,O):i.vertexAttribPointer(N,z,q,C,D,O)}function M(N,z,q,C){x();const D=C.attributes,O=q.getAttributes(),k=z.defaultAttributeValues;for(const Q in O){const G=O[Q];if(G.location>=0){let K=D[Q];if(K===void 0&&(Q==="instanceMatrix"&&N.instanceMatrix&&(K=N.instanceMatrix),Q==="instanceColor"&&N.instanceColor&&(K=N.instanceColor)),K!==void 0){const j=K.normalized,ce=K.itemSize,ve=e.get(K);if(ve===void 0)continue;const $=ve.buffer,ie=ve.type,_e=ve.bytesPerElement,we=ie===i.INT||ie===i.UNSIGNED_INT||K.gpuType===Ga;if(K.isInterleavedBufferAttribute){const ae=K.data,Ne=ae.isInterleavedBuffer===!0?ae.stride:ae.itemSize,ot=K.offset;if(ae.isInstancedInterleavedBuffer||ae.isInstancedBufferAttribute){for(let ye=0;ye<G.locationSize;ye++)c(G.location+ye,ae.meshPerAttribute);N.isInstancedMesh!==!0&&C._maxInstanceCount===void 0&&(C._maxInstanceCount=ae.meshPerAttribute*ae.count)}else for(let ye=0;ye<G.locationSize;ye++)_(G.location+ye);i.bindBuffer(i.ARRAY_BUFFER,$);for(let ye=0;ye<G.locationSize;ye++)S(G.location+ye,ce/G.locationSize,ie,j,Ne*_e,(ot+ce/G.locationSize*ye)*_e,we)}else{if(K.isInstancedBufferAttribute){for(let ae=0;ae<G.locationSize;ae++)c(G.location+ae,K.meshPerAttribute);N.isInstancedMesh!==!0&&C._maxInstanceCount===void 0&&(C._maxInstanceCount=K.meshPerAttribute*K.count)}else for(let ae=0;ae<G.locationSize;ae++)_(G.location+ae);i.bindBuffer(i.ARRAY_BUFFER,$);for(let ae=0;ae<G.locationSize;ae++)S(G.location+ae,ce/G.locationSize,ie,j,ce*_e,ce/G.locationSize*ae*_e,we)}}else if(k!==void 0){const j=k[Q];if(j!==void 0)switch(j.length){case 2:i.vertexAttrib2fv(G.location,j);break;case 3:i.vertexAttrib3fv(G.location,j);break;case 4:i.vertexAttrib4fv(G.location,j);break;default:i.vertexAttrib1fv(G.location,j)}}}}g()}function A(){T();for(const N in n){const z=n[N];for(const q in z){const C=z[q];for(const D in C){const O=C[D];for(const k in O)f(O[k].object),delete O[k];delete C[D]}}delete n[N]}}function E(N){if(n[N.id]===void 0)return;const z=n[N.id];for(const q in z){const C=z[q];for(const D in C){const O=C[D];for(const k in O)f(O[k].object),delete O[k];delete C[D]}}delete n[N.id]}function v(N){for(const z in n){const q=n[z];for(const C in q){const D=q[C];if(D[N.id]===void 0)continue;const O=D[N.id];for(const k in O)f(O[k].object),delete O[k];delete D[N.id]}}}function y(N){for(const z in n){const q=n[z],C=N.isInstancedMesh===!0?N.id:0,D=q[C];if(D!==void 0){for(const O in D){const k=D[O];for(const Q in k)f(k[Q].object),delete k[Q];delete D[O]}delete q[C],Object.keys(q).length===0&&delete n[z]}}}function T(){R(),a=!0,s!==r&&(s=r,o(s.object))}function R(){r.geometry=null,r.program=null,r.wireframe=!1}return{setup:d,reset:T,resetDefaultState:R,dispose:A,releaseStatesOfGeometry:E,releaseStatesOfObject:y,releaseStatesOfProgram:v,initAttributes:x,enableAttribute:_,disableUnusedAttributes:g}}function pp(i,e,t){let n;function r(l){n=l}function s(l,o){i.drawArrays(n,l,o),t.update(o,n,1)}function a(l,o,f){f!==0&&(i.drawArraysInstanced(n,l,o,f),t.update(o,n,f))}function d(l,o,f){if(f===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,l,0,o,0,f);let u=0;for(let p=0;p<f;p++)u+=o[p];t.update(u,n,1)}this.setMode=r,this.render=s,this.renderInstances=a,this.renderMultiDraw=d}function mp(i,e,t,n){let r;function s(){if(r!==void 0)return r;if(e.has("EXT_texture_filter_anisotropic")===!0){const v=e.get("EXT_texture_filter_anisotropic");r=i.getParameter(v.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else r=0;return r}function a(v){return!(v!==Sn&&n.convert(v)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function d(v){const y=v===wn&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(v!==en&&v!==Mn&&!y&&n.convert(v)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE))}function l(v){if(v==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";v="mediump"}return v==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let o=t.precision!==void 0?t.precision:"highp";const f=l(o);f!==o&&(Fe("WebGLRenderer:",o,"not supported, using",f,"instead."),o=f);const h=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control"),u=t.logarithmicDepthBuffer===!0&&h===!1;t.reversedDepthBuffer===!0&&h===!1&&Fe("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer."),t.logarithmicDepthBuffer===!0&&h===!0&&Fe("WebGLRenderer: Logarithmic depth buffer is ignored when reversed depth buffer is enabled.");const p=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),m=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),x=i.getParameter(i.MAX_TEXTURE_SIZE),_=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),c=i.getParameter(i.MAX_VERTEX_ATTRIBS),g=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),S=i.getParameter(i.MAX_VARYING_VECTORS),M=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),A=i.getParameter(i.MAX_SAMPLES),E=i.getParameter(i.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:s,getMaxPrecision:l,textureFormatReadable:a,textureTypeReadable:d,precision:o,logarithmicDepthBuffer:u,reversedDepthBuffer:h,maxTextures:p,maxVertexTextures:m,maxTextureSize:x,maxCubemapSize:_,maxAttributes:c,maxVertexUniforms:g,maxVaryings:S,maxFragmentUniforms:M,maxSamples:A,samples:E}}function gp(i){const e=this;let t=null,n=0,r=!1,s=!1;const a=new In,d=new ke,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(h,u){const p=h.length!==0||u||n!==0||r;return r=u,n=h.length,p},this.beginShadows=function(){s=!0,f(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(h,u){t=f(h,u,0)},this.setState=function(h,u,p){const m=h.clippingPlanes,x=h.clipIntersection,_=h.clipShadows,c=i.get(h);if(!r||m===null||m.length===0||s&&!_)s?f(null):o();else{const g=s?0:n,S=g*4;let M=c.clippingState||null;l.value=M,M=f(m,u,S,p);for(let A=0;A!==S;++A)M[A]=t[A];c.clippingState=M,this.numIntersection=x?this.numPlanes:0,this.numPlanes+=g}};function o(){l.value!==t&&(l.value=t,l.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function f(h,u,p,m){const x=h!==null?h.length:0;let _=null;if(x!==0){if(_=l.value,m!==!0||_===null){const c=p+x*4,g=u.matrixWorldInverse;d.getNormalMatrix(g),(_===null||_.length<c)&&(_=new Float32Array(c));for(let S=0,M=p;S!==x;++S,M+=4)a.copy(h[S]).applyMatrix4(g,d),a.normal.toArray(_,M),_[M+3]=a.constant}l.value=_,l.needsUpdate=!0}return e.numPlanes=x,e.numIntersection=0,_}}class eo extends yn{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const n={width:e,height:e,depth:1},r=[n,n,n,n,n,n];this.texture=new rc(r),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new Pt(5,5,5),s=new li({name:"CubemapFromEquirect",uniforms:Ni(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Zt,blending:Ai});s.uniforms.tEquirect.value=t;const a=new at(r,s),d=t.minFilter;return t.minFilter===Xn&&(t.minFilter=$t),new Ia(1,10,this).update(e,a),t.minFilter=d,a.geometry.dispose(),a.material.dispose(),this}clear(e,t=!0,n=!0,r=!0){const s=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,n,r);e.setRenderTarget(s)}}const Xo=256,_p=3,vp=20,fc=256,hc=16,xp=3,Mp=new F,Sp=new We;class ss{constructor(e){this._renderer=e,this._cubeSize=0,this._sourceTarget=null,this._cubeCamera=new Ia(1,10,null),this._boxMesh=new at(new Pt(5,5,5),null),this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null,this._integrationMaterial=null}fromScene(e,t=0,n=.1,r=100,s={}){const{size:a=256,position:d=Mp}=s,l=this._renderer;this._setSize(a);const o=this._allocateTarget(),f=this._getSourceTarget(!0);t>0&&(f.texture.mipmapsAutoUpdate=!1);const h=l.autoClear,u=l.autoClearColor,p=l.autoClearDepth,m=l.autoClearStencil,x=e.background;l.autoClear=!0,l.autoClearColor=!0,l.autoClearDepth=!0,l.autoClearStencil=!0,x===null&&(e.background=l.getClearColor(Sp));const _=new Ia(n,r,f);return _.position.copy(d),_.update(l,e),l.autoClear=h,l.autoClearColor=u,l.autoClearDepth=p,l.autoClearStencil=m,e.background=x,t>0&&(f.texture.mipmapsAutoUpdate=!0,this._blur(o,t)),this._applyPMREM(o),o}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=$o(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Yo(),this._compileMaterial(this._equirectMaterial))}dispose(){this._sourceTarget!==null&&this._sourceTarget.dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._integrationMaterial!==null&&this._integrationMaterial.dispose(),this._boxMesh.geometry.dispose()}static lodToRoughness(e,t){return t>0?1-Math.sqrt(1-e/t):0}_setSize(e){this._cubeSize=Math.max(Xo,Hd(e))}_fromTexture(e,t){e.mapping===Ci||e.mapping===tr?this._setSize(e.image.length===0?Xo:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4);const n=t||this._allocateTarget();return this._textureToCubemap(e),this._applyPMREM(n),n}_allocateTarget(){const e=this._cubeSize,t=qo(e,!1,!1),n=Math.log2(e)-_p;for(let r=0;r<=n;r++)t.texture.mipmaps.push({width:e>>r,height:e>>r});return t.texture.name="PMREM",t.texture.isPMREMTexture=!0,t}_getSourceTarget(e=!1){const t=this._cubeSize,n=this._sourceTarget;return(n===null||n.width!==t||e&&n.depthBuffer===!1)&&(n!==null&&n.dispose(),this._sourceTarget=qo(t,!0,e)),this._sourceTarget}_compileMaterial(e){this._boxMesh.material=e,this._renderer.compile(this._boxMesh,this._cubeCamera.children[0])}_renderCube(e,t,n){const r=this._boxMesh,s=this._cubeCamera;r.material=n,s.renderTarget=e,s.activeMipmapLevel=t;const a=e.width>>t;e.viewport.set(0,0,a,a),s.update(this._renderer,r),e.viewport.set(0,0,e.width,e.height)}_textureToCubemap(e){let t;e.mapping===Ci||e.mapping===tr?(this._cubemapMaterial===null&&(this._cubemapMaterial=$o()),t=this._cubemapMaterial,t.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):(this._equirectMaterial===null&&(this._equirectMaterial=Yo()),t=this._equirectMaterial),t.uniforms.envMap.value=e,this._renderCube(this._getSourceTarget(),0,t)}_applyPMREM(e){this._ggxMaterial===null&&(this._ggxMaterial=yp(),this._integrationMaterial=bp());const t=this._cubeSize,n=e.texture.mipmaps.length-1,r=this._ggxMaterial.uniforms;r.envMap.value=this._sourceTarget.texture;const s=this._integrationMaterial.uniforms;s.envMap.value=this._sourceTarget.texture,s.sourceLod.value=Math.log2(t/hc);for(let a=0;a<=n;a++){const d=ss.lodToRoughness(a,n);if(a>n-xp)s.roughness.value=d,this._renderCube(e,a,this._integrationMaterial);else{const l=d>0?Math.log2(t)+.5*Math.log2(6/(fc*Math.pow(d,4)))+.5:0;r.roughness.value=d,r.lodBias.value=l,this._renderCube(e,a,this._ggxMaterial)}}}_blur(e,t){this._blurMaterial===null&&(this._blurMaterial=Ep());const n=this._blurMaterial,r=n.uniforms,s=this._sourceTarget;r.sigma.value=Math.min(t,Math.PI)/Math.SQRT2,r.envMap.value=s.texture,this._renderCube(e,0,n),r.envMap.value=e.texture,this._renderCube(s,0,n)}}function qo(i,e,t){return new eo(i,{minFilter:Xn,generateMipmaps:e,type:wn,colorSpace:jr,depthBuffer:t})}function cr(i,e,t){return new li({name:i,uniforms:e,vertexShader:Ge.cube_vert,fragmentShader:t,side:Zt,blending:Ai,depthTest:!1,depthWrite:!1})}function yp(){return cr("PMREMGGXConvolution",{envMap:{value:null},roughness:{value:0},lodBias:{value:0}},`

		#define GGX_SAMPLES ${fc}u

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float lodBias;

		#include <common>

		// Van der Corput radical inverse
		float radicalInverse_VdC( uint bits ) {

			bits = ( bits << 16u ) | ( bits >> 16u );
			bits = ( ( bits & 0x55555555u ) << 1u ) | ( ( bits & 0xAAAAAAAAu ) >> 1u );
			bits = ( ( bits & 0x33333333u ) << 2u ) | ( ( bits & 0xCCCCCCCCu ) >> 2u );
			bits = ( ( bits & 0x0F0F0F0Fu ) << 4u ) | ( ( bits & 0xF0F0F0F0u ) >> 4u );
			bits = ( ( bits & 0x00FF00FFu ) << 8u ) | ( ( bits & 0xFF00FF00u ) >> 8u );
			return float( bits ) * 2.3283064365386963e-10; // / 0x100000000

		}

		// Hammersley sequence
		vec2 hammersley( uint i, uint N ) {

			return vec2( float( i ) / float( N ), radicalInverse_VdC( i ) );

		}

		void main() {

			vec3 N = normalize( vWorldDirection );

			// For very low roughness, just sample the environment directly
			if ( roughness < 0.001 ) {

				gl_FragColor = vec4( textureLod( envMap, N, 0.0 ).rgb, 1.0 );
				return;

			}

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			// Tangent space basis for VNDF sampling
			vec3 up = abs( N.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, N ) );
			vec3 bitangent = cross( N, tangent );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			for ( uint i = 0u; i < GGX_SAMPLES; i ++ ) {

				vec2 Xi = hammersley( i, GGX_SAMPLES );

				// With V = N, sample the reflected direction directly.
				float invQ = 1.0 / ( 1.0 - Xi.x + alpha2 * Xi.x );
				float NdotL = ( 1.0 - Xi.x - alpha2 * Xi.x ) * invQ;

				if ( NdotL > 0.0 ) {

					float phi = 2.0 * PI * Xi.y;
					float sinTheta = 2.0 * alpha * sqrt( Xi.x * ( 1.0 - Xi.x ) ) * invQ;
					vec3 L = N * NdotL + ( tangent * cos( phi ) + bitangent * sin( phi ) ) * sinTheta;

					// Match the source mip to the sample's solid angle. The terms
					// independent of the sample are precomputed in lodBias.
					float d = alpha2 * invQ;
					float lod = max( log2( d ) + lodBias, 0.0 );

					// Weight by NdotL for the split-sum approximation
					prefilteredColor += textureLod( envMap, L, lod ).rgb * NdotL;
					totalWeight += NdotL;

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function bp(){return cr("PMREMGGXIntegration",{envMap:{value:null},roughness:{value:0},sourceLod:{value:0},sourceSize:{value:hc}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float sourceLod;
		uniform int sourceSize;

		void main() {

			vec3 N = normalize( vWorldDirection );

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			float texelSize = 2.0 / float( sourceSize );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			// Pair opposite texels: only the one in N's hemisphere contributes.
			for ( int face = 0; face < 3; face ++ ) {

				for ( int y = 0; y < sourceSize; y ++ ) {

					for ( int x = 0; x < sourceSize; x ++ ) {

						vec2 uv = ( vec2( x, y ) + 0.5 ) * texelSize - 1.0;
						vec3 texelDirection = face == 0 ? vec3( 1.0, uv ) : ( face == 1 ? vec3( uv.x, 1.0, uv.y ) : vec3( uv, 1.0 ) );

						float invDistance = inversesqrt( 1.0 + dot( uv, uv ) );
						float NdotL = dot( N, texelDirection );
						texelDirection *= NdotL < 0.0 ? - 1.0 : 1.0;
						NdotL = abs( NdotL ) * invDistance;

						// With V = N, NdotH squared is ( 1 + NdotL ) / 2. Common factors
						// in the GGX distribution and texel solid angle cancel when normalized.
						float d = 1.0 + alpha2 + ( alpha2 - 1.0 ) * NdotL;
						float weight = NdotL * invDistance * invDistance * invDistance / ( d * d );

						prefilteredColor += textureLod( envMap, texelDirection, sourceLod ).rgb * weight;
						totalWeight += weight;

					}

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function Ep(){return cr("PMREMSphericalGaussianBlur",{envMap:{value:null},sigma:{value:0}},`

		#define SAMPLES ${vp}
		#define GOLDEN_ANGLE 2.39996322973

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float sigma;

		#include <common>

		void main() {

			vec3 outputDirection = normalize( vWorldDirection );

			vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, outputDirection ) );
			vec3 bitangent = cross( outputDirection, tangent );

			// Truncate the kernel at three standard deviations or at the antipode.
			float thetaMax = min( 3.0 * sigma, PI );
			float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

			vec3 accumColor = vec3( 0.0 );
			float accumWeight = 0.0;

			for ( int i = 0; i < SAMPLES; i ++ ) {

				// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
				float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
				float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
				float phi = float( i ) * GOLDEN_ANGLE;

				vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
				vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

				// Correct the planar sample density to solid angle.
				float weight = sin( theta ) / theta;

				accumColor += weight * textureLod( envMap, sampleDirection, 0.0 ).rgb;
				accumWeight += weight;

			}

			gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

		}
	`)}function Yo(){return cr("PMREMEquirectangularToCubemap",{envMap:{value:null}},`

		varying vec3 vWorldDirection;

		uniform sampler2D envMap;

		#include <common>

		void main() {

			// Average four subpixel samples to preserve small, bright features.
			vec3 direction = normalize( vWorldDirection );
			vec3 dx = dFdx( direction ) * 0.25;
			vec3 dy = dFdy( direction ) * 0.25;

			vec3 color = textureLod( envMap, equirectUv( normalize( direction - dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction - dx + dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx + dy ) ), 0.0 ).rgb;
			gl_FragColor = vec4( color * 0.25, 1.0 );

		}
	`)}function $o(){return cr("PMREMCubemapToCubemap",{envMap:{value:null},flipEnvMap:{value:-1}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float flipEnvMap;

		void main() {

			gl_FragColor = vec4( textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) ).rgb, 1.0 );

		}
	`)}function wp(i){let e=new WeakMap,t=new WeakMap,n=null;function r(u,p=!1){return u==null?null:p?a(u):s(u)}function s(u){if(u&&u.isTexture){const p=u.mapping;if(p===hs||p===ps)if(e.has(u)){const m=e.get(u).texture;return d(m,u.mapping)}else{const m=u.image;if(m&&m.height>0){const x=new eo(m.height);return x.fromEquirectangularTexture(i,u),e.set(u,x),u.addEventListener("dispose",o),d(x.texture,u.mapping)}else return null}}return u}function a(u){if(u&&u.isTexture&&u.isPMREMTexture!==!0){const p=u.mapping,m=p===hs||p===ps,x=p===Ci||p===tr;if(m||x){let _=t.get(u);const c=_!==void 0?_.texture.pmremVersion:0;if(u.isRenderTargetTexture&&u.pmremVersion!==c)return n===null&&(n=new ss(i)),_=m?n.fromEquirectangular(u,_):n.fromCubemap(u,_),_.texture.pmremVersion=u.pmremVersion,t.set(u,_),_.texture;if(_!==void 0)return _.texture;{const g=u.image;return m&&g&&g.height>0||x&&g&&l(g)?(n===null&&(n=new ss(i)),_=m?n.fromEquirectangular(u):n.fromCubemap(u),_.texture.pmremVersion=u.pmremVersion,t.set(u,_),u.addEventListener("dispose",f),_.texture):null}}}return u}function d(u,p){return p===hs?u.mapping=Ci:p===ps&&(u.mapping=tr),u}function l(u){let p=0;const m=6;for(let x=0;x<m;x++)u[x]!==void 0&&p++;return p===m}function o(u){const p=u.target;p.removeEventListener("dispose",o);const m=e.get(p);m!==void 0&&(e.delete(p),m.dispose())}function f(u){const p=u.target;p.removeEventListener("dispose",f);const m=t.get(p);m!==void 0&&(t.delete(p),m.dispose())}function h(){e=new WeakMap,t=new WeakMap,n!==null&&(n.dispose(),n=null)}return{get:r,dispose:h}}function Tp(i){const e={};function t(n){if(e[n]!==void 0)return e[n];const r=i.getExtension(n);return e[n]=r,r}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const r=t(n);return r===null&&Yr("WebGLRenderer: "+n+" extension not supported."),r}}}function Ap(i,e,t,n){const r={},s=new WeakMap,a=new FinalizationRegistry(m=>delete r[m]);function d(m){l(m.target)}function l(m){m.index!==null&&e.remove(m.index);for(const _ in m.attributes)e.remove(m.attributes[_]);m.removeEventListener("dispose",d),delete r[m.id],a.unregister(m);const x=s.get(m);x&&(e.remove(x),s.delete(m)),n.releaseStatesOfGeometry(m),m.isInstancedBufferGeometry===!0&&delete m._maxInstanceCount,t.memory.geometries--}function o(m,x){return r[x.id]!==void 0||(x.addEventListener("dispose",d),r[x.id]=new WeakRef(x),a.register(x,x.id,x),t.memory.geometries++),x}function f(m){const x=m.attributes;for(const _ in x)e.update(x[_],i.ARRAY_BUFFER)}function h(m){const x=m.index,_=m.attributes.position;let c=0;if(_===void 0)return;const g=x!==null?x.array.length:_.array.length/3-1,S=_.count>=65535?ic:nc,M=new S(Math.ceil(g/3)*6,1),A=M.array;if(x!==null){const v=x.array;c=x.version;for(let y=0,T=0;y<g;y+=3){const R=v[y+0],N=v[y+1],z=v[y+2];A[T++]=R,A[T++]=N,A[T++]=N,A[T++]=z,A[T++]=z,A[T++]=R}}else{c=_.version;for(let v=0,y=0;v<g;v+=3){const T=v+0,R=v+1,N=v+2;A[y++]=T,A[y++]=R,A[y++]=R,A[y++]=N,A[y++]=N,A[y++]=T}}M.version=c;const E=s.get(m);E&&e.remove(E),s.set(m,M)}function u(m){const x=s.get(m);if(x){const _=m.index;_!==null&&x.version<_.version&&h(m)}else h(m);return s.get(m)}function p(){for(const m in r){const x=r[m].deref();x!==void 0&&l(x)}}return{get:o,update:f,getWireframeAttribute:u,dispose:p}}function Rp(i,e,t){let n;function r(h){n=h}let s,a;function d(h){s=h.type,a=h.bytesPerElement}function l(h,u){i.drawElements(n,u,s,h*a),t.update(u,n,1)}function o(h,u,p){p!==0&&(i.drawElementsInstanced(n,u,s,h*a,p),t.update(u,n,p))}function f(h,u,p){if(p===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,u,0,s,h,0,p);let x=0;for(let _=0;_<p;_++)x+=u[_];t.update(x,n,1)}this.setMode=r,this.setIndex=d,this.render=l,this.renderInstances=o,this.renderMultiDraw=f}function Cp(i){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(s,a,d){switch(t.calls++,a){case i.TRIANGLES:t.triangles+=d*(s/3);break;case i.LINES:t.lines+=d*(s/2);break;case i.LINE_STRIP:t.lines+=d*(s-1);break;case i.LINE_LOOP:t.lines+=d*s;break;case i.POINTS:t.points+=d*s;break;default:nt("WebGLInfo: Unknown draw mode:",a);break}}function r(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:r,update:n}}function Pp(i,e,t){const n=new WeakMap,r=new wt;function s(a,d,l){const o=a.morphTargetInfluences,f=d.morphAttributes.position||d.morphAttributes.normal||d.morphAttributes.color,h=f!==void 0?f.length:0;let u=n.get(d);if(u===void 0||u.count!==h){let T=function(){v.dispose(),n.delete(d),d.removeEventListener("dispose",T)};u!==void 0&&u.texture.dispose();const p=d.morphAttributes.position!==void 0,m=d.morphAttributes.normal!==void 0,x=d.morphAttributes.color!==void 0,_=d.morphAttributes.position||[],c=d.morphAttributes.normal||[],g=d.morphAttributes.color||[];let S=0;p===!0&&(S=1),m===!0&&(S=2),x===!0&&(S=3);let M=d.attributes.position.count*S,A=1;M>e.maxTextureSize&&(A=Math.ceil(M/e.maxTextureSize),M=e.maxTextureSize);const E=new Float32Array(M*A*4*h),v=new ec(E,M,A,h);v.type=Mn,v.needsUpdate=!0;const y=S*4;for(let R=0;R<h;R++){const N=_[R],z=c[R],q=g[R],C=M*A*4*R;for(let D=0;D<N.count;D++){const O=D*y;p===!0&&(r.fromBufferAttribute(N,D),E[C+O+0]=r.x,E[C+O+1]=r.y,E[C+O+2]=r.z,E[C+O+3]=0),m===!0&&(r.fromBufferAttribute(z,D),E[C+O+4]=r.x,E[C+O+5]=r.y,E[C+O+6]=r.z,E[C+O+7]=0),x===!0&&(r.fromBufferAttribute(q,D),E[C+O+8]=r.x,E[C+O+9]=r.y,E[C+O+10]=r.z,E[C+O+11]=q.itemSize===4?r.w:1)}}u={count:h,texture:v,size:new Be(M,A)},n.set(d,u),d.addEventListener("dispose",T)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)l.getUniforms().setValue(i,"morphTexture",a.morphTexture,t);else{let p=0;for(let x=0;x<o.length;x++)p+=o[x];const m=d.morphTargetsRelative?1:1-p;l.getUniforms().setValue(i,"morphTargetBaseInfluence",m),l.getUniforms().setValue(i,"morphTargetInfluences",o)}l.getUniforms().setValue(i,"morphTargetsTexture",u.texture,t),l.getUniforms().setValue(i,"morphTargetsTextureSize",u.size)}return{update:s}}function Lp(i,e,t,n,r){let s=new WeakMap;function a(o){const f=r.render.frame,h=o.geometry,u=e.get(o,h);if(s.get(u)!==f&&(e.update(u),s.set(u,f)),o.isInstancedMesh&&(o.hasEventListener("dispose",l)===!1&&o.addEventListener("dispose",l),s.get(o)!==f&&(t.update(o.instanceMatrix,i.ARRAY_BUFFER),o.instanceColor!==null&&t.update(o.instanceColor,i.ARRAY_BUFFER),s.set(o,f))),o.isSkinnedMesh){const p=o.skeleton;s.get(p)!==f&&(p.update(),s.set(p,f))}return u}function d(){s=new WeakMap}function l(o){const f=o.target;f.removeEventListener("dispose",l),n.releaseStatesOfObject(f),t.remove(f.instanceMatrix),f.instanceColor!==null&&t.remove(f.instanceColor)}return{update:a,dispose:d}}const Dp={[Ul]:"LINEAR_TONE_MAPPING",[Fl]:"REINHARD_TONE_MAPPING",[Ol]:"CINEON_TONE_MAPPING",[Bl]:"ACES_FILMIC_TONE_MAPPING",[kl]:"AGX_TONE_MAPPING",[Gl]:"NEUTRAL_TONE_MAPPING",[zl]:"CUSTOM_TONE_MAPPING"};function Ip(i,e,t,n,r,s){const a=new yn(e,t,{type:i,depthBuffer:r,stencilBuffer:s,samples:n?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1});let d=null,l=null,o=null;const f=new Mt;f.setAttribute("position",new qe([-1,3,0,-1,-1,0,3,-1,0],3)),f.setAttribute("uv",new qe([0,2,0,0,2,0],2));const h=new Mu({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),u=new at(f,h),p=new os(-1,1,1,-1,0,1);let m=null,x=null,_=!1,c,g=null,S=[],M=!1;this.setSize=function(A,E){a.setSize(A,E),d!==null&&d.setSize(A,E),l!==null&&l.setSize(A,E);for(let v=0;v<S.length;v++){const y=S[v];y.setSize&&y.setSize(A,E)}},this.setEffects=function(A){S=A,M=S.length>0&&S[0].isRenderPass===!0;const E=a.width,v=a.height;S.length>0&&d===null&&(d=new yn(E,v,{type:wn,depthBuffer:!1,stencilBuffer:!1}),l=new yn(E,v,{type:wn,depthBuffer:!1,stencilBuffer:!1}));const y=r===!0&&S.some(T=>T.needsDepthTexture===!0);y!==(a.depthTexture!==null)&&(y===!0&&o===null&&(o=new Di(E,v),s===!0&&(o.format=qn,o.type=Pi)),a.dispose(),a.depthTexture=y?o:null,a.resolveDepthBuffer=y,a.storeMultisampledDepthBuffer=y);for(let T=0;T<S.length;T++){const R=S[T];R.setSize&&R.setSize(E,v),y&&R.needsDepthTexture===!0&&R.setDepthTexture&&R.setDepthTexture(o)}},this.begin=function(A,E){if(_||A.toneMapping===Un&&S.length===0)return!1;if(g=E,E!==null){const v=E.width,y=E.height;(a.width!==v||a.height!==y)&&this.setSize(v,y)}return M===!1&&A.setRenderTarget(a),c=A.toneMapping,A.toneMapping=Un,!0},this.hasRenderPass=function(){return M},this.end=function(A,E){A.toneMapping=c,_=!0;let v=a,y=d;for(let T=0;T<S.length;T++){const R=S[T];R.enabled!==!1&&(R.render(A,y,v,E),R.needsSwap!==!1&&(v=y,y=y===d?l:d))}if(m!==A.outputColorSpace||x!==A.toneMapping){m=A.outputColorSpace,x=A.toneMapping,h.defines={},Ke.getTransfer(m)===st&&(h.defines.SRGB_TRANSFER="");const T=Dp[x];T&&(h.defines[T]=""),h.needsUpdate=!0}h.uniforms.tDiffuse.value=v.texture,A.setRenderTarget(g),A.render(u,p),g=null,_=!1},this.isCompositing=function(){return _},this.dispose=function(){a.dispose(),d!==null&&d.dispose(),l!==null&&l.dispose(),f.dispose(),h.dispose()}}const pc=new qt,mc=new Di(1,1),gc=new sc(1),_c=new ec,vc=new Kd,xc=new rc,Zo=[],Ko=[],Jo=new Float32Array(16),Qo=new Float32Array(9),jo=new Float32Array(4);function Oi(i,e,t){const n=i[0];if(n<=0||n>0)return i;const r=e*t;let s=Zo[r];if(s===void 0&&(s=new Float32Array(r),Zo[r]=s),e!==0){n.toArray(s,0);for(let a=1,d=0;a!==e;++a)d+=t,i[a].toArray(s,d)}return s}function Lt(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function Dt(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function ls(i,e){let t=Ko[e];t===void 0&&(t=new Int32Array(e),Ko[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function Np(i,e){const t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function Up(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Lt(t,e))return;i.uniform2fv(this.addr,e),Dt(t,e)}}function Fp(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Lt(t,e))return;i.uniform3fv(this.addr,e),Dt(t,e)}}function Op(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Lt(t,e))return;i.uniform4fv(this.addr,e),Dt(t,e)}}function Bp(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Lt(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),Dt(t,e)}else{if(Lt(t,n))return;jo.set(n),i.uniformMatrix2fv(this.addr,!1,jo),Dt(t,n)}}function zp(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Lt(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),Dt(t,e)}else{if(Lt(t,n))return;Qo.set(n),i.uniformMatrix3fv(this.addr,!1,Qo),Dt(t,n)}}function kp(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Lt(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),Dt(t,e)}else{if(Lt(t,n))return;Jo.set(n),i.uniformMatrix4fv(this.addr,!1,Jo),Dt(t,n)}}function Gp(i,e){const t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function Hp(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Lt(t,e))return;i.uniform2iv(this.addr,e),Dt(t,e)}}function Vp(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Lt(t,e))return;i.uniform3iv(this.addr,e),Dt(t,e)}}function Wp(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Lt(t,e))return;i.uniform4iv(this.addr,e),Dt(t,e)}}function Xp(i,e){const t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function qp(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Lt(t,e))return;i.uniform2uiv(this.addr,e),Dt(t,e)}}function Yp(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Lt(t,e))return;i.uniform3uiv(this.addr,e),Dt(t,e)}}function $p(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Lt(t,e))return;i.uniform4uiv(this.addr,e),Dt(t,e)}}function cs(i){return i.version===0&&(i.compareFunction=Ql,i.needsUpdate=!0),i}function Zp(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r);let s;this.type===i.SAMPLER_2D_SHADOW?s=cs(mc):s=pc,t.setTexture2D(e||s,r)}function Kp(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTexture3D(e||vc,r)}function Jp(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r);let s;this.type===i.SAMPLER_CUBE_SHADOW?s=cs(gc):s=xc,t.setTextureCube(e||s,r)}function Qp(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTexture2DArray(e||_c,r)}function jp(i){switch(i){case 5126:return Np;case 35664:return Up;case 35665:return Fp;case 35666:return Op;case 35674:return Bp;case 35675:return zp;case 35676:return kp;case 5124:case 35670:return Gp;case 35667:case 35671:return Hp;case 35668:case 35672:return Vp;case 35669:case 35673:return Wp;case 5125:return Xp;case 36294:return qp;case 36295:return Yp;case 36296:return $p;case 35678:case 36198:case 36298:case 36306:case 35682:return Zp;case 35679:case 36299:case 36307:return Kp;case 35680:case 36300:case 36308:case 36293:return Jp;case 36289:case 36303:case 36311:case 36292:return Qp}}function em(i,e){i.uniform1fv(this.addr,e)}function tm(i,e){const t=Oi(e,this.size,2);i.uniform2fv(this.addr,t)}function nm(i,e){const t=Oi(e,this.size,3);i.uniform3fv(this.addr,t)}function im(i,e){const t=Oi(e,this.size,4);i.uniform4fv(this.addr,t)}function rm(i,e){const t=Oi(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function sm(i,e){const t=Oi(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function am(i,e){const t=Oi(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function om(i,e){i.uniform1iv(this.addr,e)}function lm(i,e){i.uniform2iv(this.addr,e)}function cm(i,e){i.uniform3iv(this.addr,e)}function dm(i,e){i.uniform4iv(this.addr,e)}function um(i,e){i.uniform1uiv(this.addr,e)}function fm(i,e){i.uniform2uiv(this.addr,e)}function hm(i,e){i.uniform3uiv(this.addr,e)}function pm(i,e){i.uniform4uiv(this.addr,e)}function mm(i,e,t){const n=this.cache,r=e.length,s=ls(t,r);Lt(n,s)||(i.uniform1iv(this.addr,s),Dt(n,s));let a;this.type===i.SAMPLER_2D_SHADOW?a=cs(mc):a=pc;for(let d=0;d!==r;++d)t.setTexture2D(e[d]||a,s[d])}function gm(i,e,t){const n=this.cache,r=e.length,s=ls(t,r);Lt(n,s)||(i.uniform1iv(this.addr,s),Dt(n,s));for(let a=0;a!==r;++a)t.setTexture3D(e[a]||vc,s[a])}function _m(i,e,t){const n=this.cache,r=e.length,s=ls(t,r);Lt(n,s)||(i.uniform1iv(this.addr,s),Dt(n,s));let a;this.type===i.SAMPLER_CUBE_SHADOW?a=cs(gc):a=xc;for(let d=0;d!==r;++d)t.setTextureCube(e[d]||a,s[d])}function vm(i,e,t){const n=this.cache,r=e.length,s=ls(t,r);Lt(n,s)||(i.uniform1iv(this.addr,s),Dt(n,s));for(let a=0;a!==r;++a)t.setTexture2DArray(e[a]||_c,s[a])}function xm(i){switch(i){case 5126:return em;case 35664:return tm;case 35665:return nm;case 35666:return im;case 35674:return rm;case 35675:return sm;case 35676:return am;case 5124:case 35670:return om;case 35667:case 35671:return lm;case 35668:case 35672:return cm;case 35669:case 35673:return dm;case 5125:return um;case 36294:return fm;case 36295:return hm;case 36296:return pm;case 35678:case 36198:case 36298:case 36306:case 35682:return mm;case 35679:case 36299:case 36307:return gm;case 35680:case 36300:case 36308:case 36293:return _m;case 36289:case 36303:case 36311:case 36292:return vm}}class Mm{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=jp(t.type)}}class Sm{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=xm(t.type)}}class ym{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){const r=this.seq;for(let s=0,a=r.length;s!==a;++s){const d=r[s];d.setValue(e,t[d.id],n)}}}const Gs=/(\w+)(\])?(\[|\.)?/g;function el(i,e){i.seq.push(e),i.map[e.id]=e}function bm(i,e,t){const n=i.name,r=n.length;for(Gs.lastIndex=0;;){const s=Gs.exec(n),a=Gs.lastIndex;let d=s[1];const l=s[2]==="]",o=s[3];if(l&&(d=d|0),o===void 0||o==="["&&a+2===r){el(t,o===void 0?new Mm(d,i,e):new Sm(d,i,e));break}else{let h=t.map[d];h===void 0&&(h=new ym(d),el(t,h)),t=h}}}class Zr{constructor(e,t){this.seq=[],this.map={};const n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let a=0;a<n;++a){const d=e.getActiveUniform(t,a),l=e.getUniformLocation(t,d.name);bm(d,l,this)}const r=[],s=[];for(const a of this.seq)a.type===e.SAMPLER_2D_SHADOW||a.type===e.SAMPLER_CUBE_SHADOW||a.type===e.SAMPLER_2D_ARRAY_SHADOW?r.push(a):s.push(a);r.length>0&&(this.seq=r.concat(s))}setValue(e,t,n,r){const s=this.map[t];s!==void 0&&s.setValue(e,n,r)}setOptional(e,t,n){const r=t[n];r!==void 0&&this.setValue(e,n,r)}static upload(e,t,n,r){for(let s=0,a=t.length;s!==a;++s){const d=t[s],l=n[d.id];l.needsUpdate!==!1&&d.setValue(e,l.value,r)}}static seqWithValue(e,t){const n=[];for(let r=0,s=e.length;r!==s;++r){const a=e[r];a.id in t&&n.push(a)}return n}}function tl(i,e,t){const n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}const Em=37297;let wm=0;function Tm(i,e){const t=i.split(`
`),n=[],r=Math.max(e-6,0),s=Math.min(e+6,t.length);for(let a=r;a<s;a++){const d=a+1;n.push(`${d===e?">":" "} ${d}: ${t[a]}`)}return n.join(`
`)}const nl=new ke;function Am(i){Ke._getMatrix(nl,Ke.workingColorSpace,i);const e=`mat3( ${nl.elements.map(t=>t.toFixed(4))} )`;switch(Ke.getTransfer(i)){case es:return[e,"LinearTransferOETF"];case st:return[e,"sRGBTransferOETF"];default:return Fe("WebGLProgram: Unsupported color space: ",i),[e,"LinearTransferOETF"]}}function il(i,e,t){const n=i.getShaderParameter(e,i.COMPILE_STATUS),s=(i.getShaderInfoLog(e)||"").trim();if(n&&s==="")return"";const a=/ERROR: 0:(\d+)/.exec(s);if(a){const d=parseInt(a[1]);return t.toUpperCase()+`

`+s+`

`+Tm(i.getShaderSource(e),d)}else return s}function Rm(i,e){const t=Am(e);return[`vec4 ${i}( vec4 value ) {`,`	return ${t[1]}( vec4( ${t[0]} * value.rgb, value.a ) );`,"}"].join(`
`)}const Cm={[Ul]:"Linear",[Fl]:"Reinhard",[Ol]:"Cineon",[Bl]:"ACESFilmic",[kl]:"AgX",[Gl]:"Neutral",[zl]:"Custom"};function Pm(i,e){const t=Cm[e];return t===void 0?(Fe("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+i+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const zr=new F;function Lm(){Ke.getLuminanceCoefficients(zr);const i=zr.x.toFixed(4),e=zr.y.toFixed(4),t=zr.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function Dm(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Ji).join(`
`)}function Im(i){const e=[];for(const t in i){const n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function Nm(i,e){const t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let r=0;r<n;r++){const s=i.getActiveAttrib(e,r),a=s.name;let d=1;s.type===i.FLOAT_MAT2&&(d=2),s.type===i.FLOAT_MAT3&&(d=3),s.type===i.FLOAT_MAT4&&(d=4),t[a]={type:s.type,location:i.getAttribLocation(e,a),locationSize:d}}return t}function Ji(i){return i!==""}function rl(i,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_SUN_LIGHTS/g,e.numSunLights).replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,e.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows).replace(/NUM_LIGHT_PROBE_GRIDS/g,e.numLightProbeGrids)}function sl(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const Um=/^[ \t]*#include +<([\w\d./]+)>/gm;function Ua(i){return i.replace(Um,Fm)}function Fm(i,e){const t=Ge[e];if(t===void 0)throw new Error("THREE.WebGLProgram: Can not resolve #include <"+e+">");return Ua(t)}const Om=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function al(i){return i.replace(Om,Bm)}function Bm(i,e,t,n){let r="";for(let s=parseInt(e);s<parseInt(t);s++)r+=n.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return r}function ol(i){let e=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}const zm={[Hr]:"SHADOWMAP_TYPE_PCF",[Ki]:"SHADOWMAP_TYPE_VSM"};function km(i){return zm[i.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const Gm={[tr]:"ENVMAP_MODE_REFRACTION"};function Hm(i){return i.envMap===!1?"ENVMAP_MODE_REFLECTION":Gm[i.envMapMode]||"ENVMAP_MODE_REFLECTION"}const Vm={[Nl]:"ENVMAP_BLENDING_MULTIPLY",[wd]:"ENVMAP_BLENDING_MIX",[Td]:"ENVMAP_BLENDING_ADD"};function Wm(i){return i.envMap===!1?"ENVMAP_BLENDING_NONE":Vm[i.combine]||"ENVMAP_BLENDING_NONE"}function Xm(i,e,t,n){const r=i.getContext(),s=t.defines;let a=t.vertexShader,d=t.fragmentShader;const l=km(t),o=t.envMapPMREM===!0?"ENVMAP_TYPE_PMREM":"ENVMAP_TYPE_CUBE",f=Hm(t),h=Wm(t),u=Dm(t),p=Im(s),m=r.createProgram();let x,_,c=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(x=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p].filter(Ji).join(`
`),x.length>0&&(x+=`
`),_=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p].filter(Ji).join(`
`),_.length>0&&(_+=`
`)):(x=[ol(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+f:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.diffuseRoughnessMap?"#define USE_DIFFUSE_ROUGHNESSMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.diffuseRoughnessMapUv?"#define DIFFUSE_ROUGHNESSMAP_UV "+t.diffuseRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexNormals?"#define HAS_NORMAL":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Ji).join(`
`),_=[ol(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+o:"",t.envMap?"#define "+f:"",t.envMap?"#define "+h:"",t.envMapPMREM?"#define ENVMAP_MAX_LOD "+t.envMapMaxLod+".0":"",t.envMapPMREM?"#define ENVMAP_SIZE "+t.envMapSize+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.diffuseRoughness?"#define USE_DIFFUSE_ROUGHNESS":"",t.diffuseRoughnessMap?"#define USE_DIFFUSE_ROUGHNESSMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.retroreflection?"#define USE_RETROREFLECTION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas||t.batchingColor?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Un?"#define TONE_MAPPING":"",t.toneMapping!==Un?Ge.tonemapping_pars_fragment:"",t.toneMapping!==Un?Pm("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Ge.colorspace_pars_fragment,Rm("linearToOutputTexel",t.outputColorSpace),Lm(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Ji).join(`
`)),a=Ua(a),a=rl(a,t),a=sl(a,t),d=Ua(d),d=rl(d,t),d=sl(d,t),a=al(a),d=al(d),t.isRawShaderMaterial!==!0&&(c=`#version 300 es
`,x=[u,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+x,_=["#define varying in",t.glslVersion===mo?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===mo?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+_);const g=c+x+a,S=c+_+d,M=tl(r,r.VERTEX_SHADER,g),A=tl(r,r.FRAGMENT_SHADER,S);r.attachShader(m,M),r.attachShader(m,A),t.index0AttributeName!==void 0?r.bindAttribLocation(m,0,t.index0AttributeName):t.hasPositionAttribute===!0&&r.bindAttribLocation(m,0,"position"),r.linkProgram(m);function E(R){if(i.debug.checkShaderErrors){const N=r.getProgramInfoLog(m)||"",z=r.getShaderInfoLog(M)||"",q=r.getShaderInfoLog(A)||"",C=N.trim(),D=z.trim(),O=q.trim();let k=!0,Q=!0;if(r.getProgramParameter(m,r.LINK_STATUS)===!1)if(k=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(r,m,M,A);else{const G=il(r,M,"vertex"),K=il(r,A,"fragment");nt("WebGLProgram: Shader Error "+r.getError()+" - VALIDATE_STATUS "+r.getProgramParameter(m,r.VALIDATE_STATUS)+`

Material Name: `+R.name+`
Material Type: `+R.type+`

Program Info Log: `+C+`
`+G+`
`+K)}else C!==""?Fe("WebGLProgram: Program Info Log:",C):(D===""||O==="")&&(Q=!1);Q&&(R.diagnostics={runnable:k,programLog:C,vertexShader:{log:D,prefix:x},fragmentShader:{log:O,prefix:_}})}r.deleteShader(M),r.deleteShader(A),v=new Zr(r,m),y=Nm(r,m)}let v;this.getUniforms=function(){return v===void 0&&E(this),v};let y;this.getAttributes=function(){return y===void 0&&E(this),y};let T=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return T===!1&&(T=r.getProgramParameter(m,Em)),T},this.destroy=function(){n.releaseStatesOfProgram(this),r.deleteProgram(m),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=wm++,this.cacheKey=e,this.usedTimes=1,this.program=m,this.vertexShader=M,this.fragmentShader=A,this}let qm=0;class Ym{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,n){const r=this._getShaderCacheForMaterial(e);return r.has(t)===!1&&(r.add(t),t.usedTimes++),r.has(n)===!1&&(r.add(n),n.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){const t=this.shaderCache;let n=t.get(e);return n===void 0&&(n=new $m(e),t.set(e,n)),n}}class $m{constructor(e){this.id=qm++,this.code=e,this.usedTimes=0}}function Zm(i){return i===oi||i===Jr||i===Qr}function Km(i,e,t,n,r,s){const a=new Za,d=new Ym,l=new Set,o=[],f=new Map,h=n.logarithmicDepthBuffer,u={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function p(v){return l.add(v),v===0?"uv":`uv${v}`}function m(v,y,T,R,N,z){const q=R.fog,C=N.geometry,D=v.isMeshStandardMaterial||v.isMeshLambertMaterial||v.isMeshPhongMaterial?R.environment:null,O=v.isMeshStandardMaterial||v.isMeshLambertMaterial&&!v.envMap||v.isMeshPhongMaterial&&!v.envMap,k=e.get(v.envMap||D,O),Q=u[v.type];let G=n.precision;v.precision!==null&&(G=n.getMaxPrecision(v.precision),G!==v.precision&&Fe("WebGLProgram.getParameters:",v.precision,"not supported, using",G,"instead."));const K=C.morphAttributes.position||C.morphAttributes.normal||C.morphAttributes.color,j=K!==void 0?K.length:0;let ce=0;C.morphAttributes.position!==void 0&&(ce=1),C.morphAttributes.normal!==void 0&&(ce=2),C.morphAttributes.color!==void 0&&(ce=3);let ve,$,ie,_e;if(Q){const ge=_n[Q];ve=ge.vertexShader,$=ge.fragmentShader}else{ve=v.vertexShader,$=v.fragmentShader;const ge=d.getVertexShaderStage(v),et=d.getFragmentShaderStage(v);d.update(v,ge,et),ie=ge.id,_e=et.id}const we=i.getRenderTarget(),ae=i.state.buffers.depth.getReversed(),Ne=N.isInstancedMesh===!0,ot=N.isBatchedMesh===!0,ye=!!v.map,He=!!v.matcap,Xe=!!k,Ve=Xe&&k.isPMREMTexture===!0,Tt=!!v.aoMap,lt=!!v.lightMap,Je=!!v.bumpMap&&v.wireframe===!1,Qe=!!v.normalMap,At=!!v.displacementMap,bt=!!v.emissiveMap,Ht=!!v.metalnessMap,_t=!!v.roughnessMap,Vt=v.anisotropy>0,B=v.clearcoat>0,St=v.diffuseRoughness>0,ct=v.dispersion>0,dt=v.retroreflectivity>0,he=v.iridescence>0,yt=v.sheen>0,De=v.transmission>0,Ue=Vt&&!!v.anisotropyMap,P=B&&!!v.clearcoatMap,b=B&&!!v.clearcoatNormalMap,V=B&&!!v.clearcoatRoughnessMap,re=St&&!!v.diffuseRoughnessMap,ne=he&&!!v.iridescenceMap,oe=he&&!!v.iridescenceThicknessMap,L=yt&&!!v.sheenColorMap,Z=yt&&!!v.sheenRoughnessMap,ee=!!v.specularMap,fe=!!v.specularColorMap,I=!!v.specularIntensityMap,te=De&&!!v.transmissionMap,J=De&&!!v.thicknessMap,ue=!!v.gradientMap,le=!!v.alphaMap,de=v.alphaTest>0,Ce=!!v.alphaHash,Le=!!v.extensions;let se=Un;v.toneMapped&&(we===null||we.isXRRenderTarget===!0)&&(se=i.toneMapping);const be=Ve?k.isCompressedCubeTexture?k.image[0].mipmaps:k.mipmaps:null,Oe={shaderID:Q,shaderType:v.type,shaderName:v.name,vertexShader:ve,fragmentShader:$,defines:v.defines,customVertexShaderID:ie,customFragmentShaderID:_e,isRawShaderMaterial:v.isRawShaderMaterial===!0,glslVersion:v.glslVersion,precision:G,batching:ot,batchingColor:ot&&N._colorsTexture!==null,instancing:Ne,instancingColor:Ne&&N.instanceColor!==null,instancingMorph:Ne&&N.morphTexture!==null,outputColorSpace:we===null?i.outputColorSpace:we.isXRRenderTarget===!0?we.texture.colorSpace:Ke.workingColorSpace,alphaToCoverage:!!v.alphaToCoverage,map:ye,matcap:He,envMap:Xe,envMapMode:Xe&&k.mapping,envMapPMREM:Ve,envMapMaxLod:Ve?be.length-1:null,envMapSize:Ve?be[0].width:null,aoMap:Tt,lightMap:lt,bumpMap:Je,normalMap:Qe,displacementMap:At,emissiveMap:bt,normalMapObjectSpace:Qe&&v.normalMapType===Cd,normalMapTangentSpace:Qe&&v.normalMapType===La,packedNormalMap:Qe&&v.normalMapType===La&&Zm(v.normalMap.format),metalnessMap:Ht,roughnessMap:_t,anisotropy:Vt,anisotropyMap:Ue,clearcoat:B,clearcoatMap:P,clearcoatNormalMap:b,clearcoatRoughnessMap:V,diffuseRoughness:St,diffuseRoughnessMap:re,dispersion:ct,retroreflection:dt,iridescence:he,iridescenceMap:ne,iridescenceThicknessMap:oe,sheen:yt,sheenColorMap:L,sheenRoughnessMap:Z,specularMap:ee,specularColorMap:fe,specularIntensityMap:I,transmission:De,transmissionMap:te,thicknessMap:J,gradientMap:ue,opaque:v.transparent===!1&&v.blending===Qi&&v.alphaToCoverage===!1,alphaMap:le,alphaTest:de,alphaHash:Ce,combine:v.combine,mapUv:ye&&p(v.map.channel),aoMapUv:Tt&&p(v.aoMap.channel),lightMapUv:lt&&p(v.lightMap.channel),bumpMapUv:Je&&p(v.bumpMap.channel),normalMapUv:Qe&&p(v.normalMap.channel),displacementMapUv:At&&p(v.displacementMap.channel),emissiveMapUv:bt&&p(v.emissiveMap.channel),metalnessMapUv:Ht&&p(v.metalnessMap.channel),roughnessMapUv:_t&&p(v.roughnessMap.channel),anisotropyMapUv:Ue&&p(v.anisotropyMap.channel),clearcoatMapUv:P&&p(v.clearcoatMap.channel),clearcoatNormalMapUv:b&&p(v.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:V&&p(v.clearcoatRoughnessMap.channel),diffuseRoughnessMapUv:re&&p(v.diffuseRoughnessMap.channel),iridescenceMapUv:ne&&p(v.iridescenceMap.channel),iridescenceThicknessMapUv:oe&&p(v.iridescenceThicknessMap.channel),sheenColorMapUv:L&&p(v.sheenColorMap.channel),sheenRoughnessMapUv:Z&&p(v.sheenRoughnessMap.channel),specularMapUv:ee&&p(v.specularMap.channel),specularColorMapUv:fe&&p(v.specularColorMap.channel),specularIntensityMapUv:I&&p(v.specularIntensityMap.channel),transmissionMapUv:te&&p(v.transmissionMap.channel),thicknessMapUv:J&&p(v.thicknessMap.channel),alphaMapUv:le&&p(v.alphaMap.channel),vertexTangents:!!C.attributes.tangent&&(Qe||Vt),vertexNormals:!!C.attributes.normal,vertexColors:v.vertexColors,vertexAlphas:v.vertexColors===!0&&!!C.attributes.color&&C.attributes.color.itemSize===4,pointsUvs:N.isPoints===!0&&!!C.attributes.uv&&(ye||le),fog:!!q,useFog:v.fog===!0,fogExp2:!!q&&q.isFogExp2,flatShading:v.wireframe===!1&&(v.flatShading===!0||C.attributes.normal===void 0&&Qe===!1&&(v.isMeshLambertMaterial||v.isMeshPhongMaterial||v.isMeshStandardMaterial||v.isMeshPhysicalMaterial)),sizeAttenuation:v.sizeAttenuation===!0,logarithmicDepthBuffer:h,reversedDepthBuffer:ae,skinning:N.isSkinnedMesh===!0,hasPositionAttribute:C.attributes.position!==void 0,morphTargets:C.morphAttributes.position!==void 0,morphNormals:C.morphAttributes.normal!==void 0,morphColors:C.morphAttributes.color!==void 0,morphTargetsCount:j,morphTextureStride:ce,numSunLights:y.sun.length,numDirLights:y.directional.length,numPointLights:y.point.length,numSpotLights:y.spot.length,numSpotLightMaps:y.spotLightMap.length,numRectAreaLights:y.rectArea.length,numHemiLights:y.hemi.length,numSunLightShadows:y.sunShadowMap.length,numDirLightShadows:y.directionalShadowMap.length,numPointLightShadows:y.pointShadowMap.length,numSpotLightShadows:y.spotShadowMap.length,numSpotLightShadowsWithMaps:y.numSpotLightShadowsWithMaps,numLightProbes:y.numLightProbes,numLightProbeGrids:z.filter(ge=>ge.texture!==null).length,numClippingPlanes:s.numPlanes,numClipIntersection:s.numIntersection,dithering:v.dithering,shadowMapEnabled:i.shadowMap.enabled&&T.length>0,shadowMapType:i.shadowMap.type,toneMapping:se,decodeVideoTexture:ye&&v.map.isVideoTexture===!0&&Ke.getTransfer(v.map.colorSpace)===st,decodeVideoTextureEmissive:bt&&v.emissiveMap.isVideoTexture===!0&&Ke.getTransfer(v.emissiveMap.colorSpace)===st,premultipliedAlpha:v.premultipliedAlpha,doubleSided:v.side===vn,flipSided:v.side===Zt,useDepthPacking:v.depthPacking>=0,depthPacking:v.depthPacking||0,index0AttributeName:v.index0AttributeName,extensionClipCullDistance:Le&&v.extensions.clipCullDistance===!0&&t.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Le&&v.extensions.multiDraw===!0||ot)&&t.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:t.has("KHR_parallel_shader_compile"),customProgramCacheKey:v.customProgramCacheKey()};return Oe.vertexUv1s=l.has(1),Oe.vertexUv2s=l.has(2),Oe.vertexUv3s=l.has(3),l.clear(),Oe}function x(v){const y=[];if(v.shaderID?y.push(v.shaderID):(y.push(v.customVertexShaderID),y.push(v.customFragmentShaderID)),v.defines!==void 0)for(const T in v.defines)y.push(T),y.push(v.defines[T]);return v.isRawShaderMaterial===!1&&(_(y,v),c(y,v),y.push(i.outputColorSpace)),y.push(v.customProgramCacheKey),y.join()}function _(v,y){v.push(y.precision),v.push(y.outputColorSpace),v.push(y.envMapMode),v.push(y.envMapPMREM),v.push(y.envMapMaxLod),v.push(y.envMapSize),v.push(y.mapUv),v.push(y.alphaMapUv),v.push(y.lightMapUv),v.push(y.aoMapUv),v.push(y.bumpMapUv),v.push(y.normalMapUv),v.push(y.displacementMapUv),v.push(y.emissiveMapUv),v.push(y.metalnessMapUv),v.push(y.roughnessMapUv),v.push(y.anisotropyMapUv),v.push(y.clearcoatMapUv),v.push(y.clearcoatNormalMapUv),v.push(y.clearcoatRoughnessMapUv),v.push(y.diffuseRoughnessMapUv),v.push(y.iridescenceMapUv),v.push(y.iridescenceThicknessMapUv),v.push(y.sheenColorMapUv),v.push(y.sheenRoughnessMapUv),v.push(y.specularMapUv),v.push(y.specularColorMapUv),v.push(y.specularIntensityMapUv),v.push(y.transmissionMapUv),v.push(y.thicknessMapUv),v.push(y.combine),v.push(y.fogExp2),v.push(y.sizeAttenuation),v.push(y.morphTargetsCount),v.push(y.numSunLights),v.push(y.numDirLights),v.push(y.numPointLights),v.push(y.numSpotLights),v.push(y.numSpotLightMaps),v.push(y.numHemiLights),v.push(y.numRectAreaLights),v.push(y.numSunLightShadows),v.push(y.numDirLightShadows),v.push(y.numPointLightShadows),v.push(y.numSpotLightShadows),v.push(y.numSpotLightShadowsWithMaps),v.push(y.numLightProbes),v.push(y.numLightProbeGrids),v.push(y.shadowMapType),v.push(y.toneMapping),v.push(y.numClippingPlanes),v.push(y.numClipIntersection),v.push(y.depthPacking)}function c(v,y){a.disableAll(),y.instancing&&a.enable(0),y.instancingColor&&a.enable(1),y.instancingMorph&&a.enable(2),y.matcap&&a.enable(3),y.envMap&&a.enable(4),y.normalMapObjectSpace&&a.enable(5),y.normalMapTangentSpace&&a.enable(6),y.clearcoat&&a.enable(7),y.iridescence&&a.enable(8),y.alphaTest&&a.enable(9),y.vertexColors&&a.enable(10),y.vertexAlphas&&a.enable(11),y.vertexUv1s&&a.enable(12),y.vertexUv2s&&a.enable(13),y.vertexUv3s&&a.enable(14),y.vertexTangents&&a.enable(15),y.anisotropy&&a.enable(16),y.alphaHash&&a.enable(17),y.batching&&a.enable(18),y.dispersion&&a.enable(19),y.retroreflection&&a.enable(24),y.diffuseRoughness&&a.enable(25),y.batchingColor&&a.enable(20),y.gradientMap&&a.enable(21),y.packedNormalMap&&a.enable(22),y.vertexNormals&&a.enable(23),v.push(a.mask),a.disableAll(),y.fog&&a.enable(0),y.useFog&&a.enable(1),y.flatShading&&a.enable(2),y.logarithmicDepthBuffer&&a.enable(3),y.reversedDepthBuffer&&a.enable(4),y.skinning&&a.enable(5),y.morphTargets&&a.enable(6),y.morphNormals&&a.enable(7),y.morphColors&&a.enable(8),y.premultipliedAlpha&&a.enable(9),y.shadowMapEnabled&&a.enable(10),y.doubleSided&&a.enable(11),y.flipSided&&a.enable(12),y.useDepthPacking&&a.enable(13),y.dithering&&a.enable(14),y.transmission&&a.enable(15),y.sheen&&a.enable(16),y.opaque&&a.enable(17),y.pointsUvs&&a.enable(18),y.decodeVideoTexture&&a.enable(19),y.decodeVideoTextureEmissive&&a.enable(20),y.alphaToCoverage&&a.enable(21),y.numLightProbeGrids>0&&a.enable(22),y.hasPositionAttribute&&a.enable(23),v.push(a.mask)}function g(v){const y=u[v.type];let T;if(y){const R=_n[y];T=_u.clone(R.uniforms)}else T=v.uniforms;return T}function S(v,y){let T=f.get(y);return T!==void 0?++T.usedTimes:(T=new Xm(i,y,v,r),o.push(T),f.set(y,T)),T}function M(v){if(--v.usedTimes===0){const y=o.indexOf(v);o[y]=o[o.length-1],o.pop(),f.delete(v.cacheKey),v.destroy()}}function A(v){d.remove(v)}function E(){d.dispose()}return{getParameters:m,getProgramCacheKey:x,getUniforms:g,acquireProgram:S,releaseProgram:M,releaseShaderCache:A,programs:o,dispose:E}}function Jm(){let i=new WeakMap;function e(a){return i.has(a)}function t(a){let d=i.get(a);return d===void 0&&(d={},i.set(a,d)),d}function n(a){i.delete(a)}function r(a,d,l){i.get(a)[d]=l}function s(){i=new WeakMap}return{has:e,get:t,remove:n,update:r,dispose:s}}function Qm(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.materialVariant!==e.materialVariant?i.materialVariant-e.materialVariant:i.z!==e.z?i.z-e.z:i.id-e.id}function ll(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function cl(){const i=[];let e=0;const t=[],n=[],r=[];function s(){e=0,t.length=0,n.length=0,r.length=0}function a(u){let p=0;return u.isInstancedMesh&&(p+=2),u.isSkinnedMesh&&(p+=1),p}function d(u,p,m,x,_,c){let g=i[e];return g===void 0?(g={id:u.id,object:u,geometry:p,material:m,materialVariant:a(u),groupOrder:x,renderOrder:u.renderOrder,z:_,group:c},i[e]=g):(g.id=u.id,g.object=u,g.geometry=p,g.material=m,g.materialVariant=a(u),g.groupOrder=x,g.renderOrder=u.renderOrder,g.z=_,g.group=c),e++,g}function l(u,p,m,x,_,c,g){g.reversedDepth===!0&&(_=-_);const S=d(u,p,m,x,_,c);m.transmission>0?n.push(S):m.transparent===!0?r.push(S):t.push(S)}function o(u,p,m,x,_,c){const g=d(u,p,m,x,_,c);m.transmission>0?n.unshift(g):m.transparent===!0?r.unshift(g):t.unshift(g)}function f(u,p){t.length>1&&t.sort(u||Qm),n.length>1&&n.sort(p||ll),r.length>1&&r.sort(p||ll)}function h(){for(let u=e,p=i.length;u<p;u++){const m=i[u];if(m.id===null)break;m.id=null,m.object=null,m.geometry=null,m.material=null,m.group=null}}return{opaque:t,transmissive:n,transparent:r,init:s,push:l,unshift:o,finish:h,sort:f}}function jm(){let i=new WeakMap;function e(n,r){const s=i.get(n);let a;return s===void 0?(a=new cl,i.set(n,[a])):r>=s.length?(a=new cl,s.push(a)):a=s[r],a}function t(){i=new WeakMap}return{get:e,dispose:t}}function e0(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"SunLight":case"DirectionalLight":t={direction:new F,color:new We};break;case"SpotLight":t={position:new F,direction:new F,color:new We,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new F,color:new We,distance:0,decay:0};break;case"HemisphereLight":t={direction:new F,skyColor:new We,groundColor:new We};break;case"RectAreaLight":t={color:new We,position:new F,halfWidth:new F,halfHeight:new F};break}return i[e.id]=t,t}}}function t0(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"SunLight":case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Be};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Be};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Be,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}let n0=0;function i0(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function r0(i){const e=new e0,t=t0(),n={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let o=0;o<9;o++)n.probe.push(new F);const r=new F,s=new ft,a=new ft;function d(o){let f=0,h=0,u=0;for(let z=0;z<9;z++)n.probe[z].set(0,0,0);let p=0,m=0,x=0,_=0,c=0,g=0,S=0,M=0,A=0,E=0,v=0,y=0,T=0,R=0;o.sort(i0);for(let z=0,q=o.length;z<q;z++){const C=o[z],D=C.color,O=C.intensity,k=C.distance;let Q=null;if(C.shadow&&C.shadow.map&&(C.shadow.map.texture.format===oi?Q=C.shadow.map.texture:Q=C.shadow.map.depthTexture||C.shadow.map.texture),C.isAmbientLight)f+=D.r*O,h+=D.g*O,u+=D.b*O;else if(C.isLightProbe){for(let G=0;G<9;G++)n.probe[G].addScaledVector(C.sh.coefficients[G],O);R++}else if(C.isSunLight){const G=e.get(C);if(G.color.copy(C.color).multiplyScalar(C.intensity),C.castShadow){const K=C.shadow,j=t.get(C);j.shadowIntensity=K.intensity,j.shadowBias=K.bias,j.shadowNormalBias=K.normalBias,j.shadowRadius=K.radius,j.shadowMapSize.copy(K.mapSize).multiply(K.getFrameExtents()),n.sunShadow[m]=j,n.sunShadowMap[m]=Q;const ce=K.getViewportCount();for(let ve=0;ve<ce;ve++)n.sunShadowMatrix[x+ve]=K.getMatrix(ve),n.sunShadowCascade[x+ve]=K._cascadeData[ve];x+=ce,m++}n.sun[p]=G,p++}else if(C.isDirectionalLight){const G=e.get(C);if(G.color.copy(C.color).multiplyScalar(C.intensity),C.castShadow){const K=C.shadow,j=t.get(C);j.shadowIntensity=K.intensity,j.shadowBias=K.bias,j.shadowNormalBias=K.normalBias,j.shadowRadius=K.radius,j.shadowMapSize=K.mapSize,n.directionalShadow[_]=j,n.directionalShadowMap[_]=Q,n.directionalShadowMatrix[_]=C.shadow.matrix,A++}n.directional[_]=G,_++}else if(C.isSpotLight){const G=e.get(C);G.position.setFromMatrixPosition(C.matrixWorld),G.color.copy(D).multiplyScalar(O),G.distance=k,G.coneCos=Math.cos(C.angle),G.penumbraCos=Math.cos(C.angle*(1-C.penumbra)),G.decay=C.decay,n.spot[g]=G;const K=C.shadow;if(C.map&&(n.spotLightMap[y]=C.map,y++,K.updateMatrices(C),C.castShadow&&T++),n.spotLightMatrix[g]=K.matrix,C.castShadow){const j=t.get(C);j.shadowIntensity=K.intensity,j.shadowBias=K.bias,j.shadowNormalBias=K.normalBias,j.shadowRadius=K.radius,j.shadowMapSize=K.mapSize,n.spotShadow[g]=j,n.spotShadowMap[g]=Q,v++}g++}else if(C.isRectAreaLight){const G=e.get(C);G.color.copy(D).multiplyScalar(O),G.halfWidth.set(C.width*.5,0,0),G.halfHeight.set(0,C.height*.5,0),n.rectArea[S]=G,S++}else if(C.isPointLight){const G=e.get(C);if(G.color.copy(C.color).multiplyScalar(C.intensity),G.distance=C.distance,G.decay=C.decay,C.castShadow){const K=C.shadow,j=t.get(C);j.shadowIntensity=K.intensity,j.shadowBias=K.bias,j.shadowNormalBias=K.normalBias,j.shadowRadius=K.radius,j.shadowMapSize=K.mapSize,j.shadowCameraNear=K.camera.near,j.shadowCameraFar=K.camera.far,n.pointShadow[c]=j,n.pointShadowMap[c]=Q,n.pointShadowMatrix[c]=C.shadow.matrix,E++}n.point[c]=G,c++}else if(C.isHemisphereLight){const G=e.get(C);G.skyColor.copy(C.color).multiplyScalar(O),G.groundColor.copy(C.groundColor).multiplyScalar(O),n.hemi[M]=G,M++}}S>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=xe.LTC_FLOAT_1,n.rectAreaLTC2=xe.LTC_FLOAT_2):(n.rectAreaLTC1=xe.LTC_HALF_1,n.rectAreaLTC2=xe.LTC_HALF_2)),n.ambient[0]=f,n.ambient[1]=h,n.ambient[2]=u;const N=n.hash;(N.sunLength!==p||N.directionalLength!==_||N.pointLength!==c||N.spotLength!==g||N.rectAreaLength!==S||N.hemiLength!==M||N.numSunShadows!==m||N.numDirectionalShadows!==A||N.numPointShadows!==E||N.numSpotShadows!==v||N.numSpotMaps!==y||N.numLightProbes!==R)&&(n.sun.length=p,n.directional.length=_,n.spot.length=g,n.rectArea.length=S,n.point.length=c,n.hemi.length=M,n.sunShadow.length=m,n.sunShadowMap.length=m,n.sunShadowMatrix.length=x,n.sunShadowCascade.length=x,n.directionalShadow.length=A,n.directionalShadowMap.length=A,n.directionalShadowMatrix.length=A,n.pointShadow.length=E,n.pointShadowMap.length=E,n.pointShadowMatrix.length=E,n.spotShadow.length=v,n.spotShadowMap.length=v,n.spotLightMatrix.length=v+y-T,n.spotLightMap.length=y,n.numSpotLightShadowsWithMaps=T,n.numLightProbes=R,N.sunLength=p,N.directionalLength=_,N.pointLength=c,N.spotLength=g,N.rectAreaLength=S,N.hemiLength=M,N.numSunShadows=m,N.numDirectionalShadows=A,N.numPointShadows=E,N.numSpotShadows=v,N.numSpotMaps=y,N.numLightProbes=R,n.version=n0++)}function l(o,f){let h=0,u=0,p=0,m=0,x=0,_=0;const c=f.matrixWorldInverse;for(let g=0,S=o.length;g<S;g++){const M=o[g];if(M.isSunLight){const A=n.sun[h];A.direction.setFromMatrixPosition(M.matrixWorld),A.direction.transformDirection(c),h++}else if(M.isDirectionalLight){const A=n.directional[u];A.direction.setFromMatrixPosition(M.matrixWorld),r.setFromMatrixPosition(M.target.matrixWorld),A.direction.sub(r),A.direction.transformDirection(c),u++}else if(M.isSpotLight){const A=n.spot[m];A.position.setFromMatrixPosition(M.matrixWorld),A.position.applyMatrix4(c),A.direction.setFromMatrixPosition(M.matrixWorld),r.setFromMatrixPosition(M.target.matrixWorld),A.direction.sub(r),A.direction.transformDirection(c),m++}else if(M.isRectAreaLight){const A=n.rectArea[x];A.position.setFromMatrixPosition(M.matrixWorld),A.position.applyMatrix4(c),a.identity(),s.copy(M.matrixWorld),s.premultiply(c),a.extractRotation(s),A.halfWidth.set(M.width*.5,0,0),A.halfHeight.set(0,M.height*.5,0),A.halfWidth.applyMatrix4(a),A.halfHeight.applyMatrix4(a),x++}else if(M.isPointLight){const A=n.point[p];A.position.setFromMatrixPosition(M.matrixWorld),A.position.applyMatrix4(c),p++}else if(M.isHemisphereLight){const A=n.hemi[_];A.direction.setFromMatrixPosition(M.matrixWorld),A.direction.transformDirection(c),_++}}}return{setup:d,setupView:l,state:n}}function dl(i){const e=new r0(i),t=[],n=[],r=[];function s(h){f.camera=h,t.length=0,n.length=0,r.length=0}function a(h){h.isLightProbeGrid?r.push(h):t.push(h)}function d(h){n.push(h)}function l(){e.setup(t),r.sort((h,u)=>h.priority-u.priority||h.id-u.id)}function o(h){e.setupView(t,h)}const f={lightsArray:t,shadowsArray:n,lightProbeGridArray:r,camera:null,lights:e,transmissionRenderTarget:{},textureUnits:0};return{init:s,state:f,setupLights:l,setupLightsView:o,pushLight:a,pushShadow:d}}function s0(i){let e=new WeakMap;function t(r,s=0){const a=e.get(r);let d;return a===void 0?(d=new dl(i),e.set(r,[d])):s>=a.length?(d=new dl(i),a.push(d)):d=a[s],d}function n(){e=new WeakMap}return{get:t,dispose:n}}const a0=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,o0=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,l0=[new F(1,0,0),new F(-1,0,0),new F(0,1,0),new F(0,-1,0),new F(0,0,1),new F(0,0,-1)],c0=[new F(0,-1,0),new F(0,-1,0),new F(0,0,1),new F(0,0,-1),new F(0,-1,0),new F(0,-1,0)],ul=new ft,qi=new F,Hs=new F;function d0(i,e,t){let n=new rr;const r=new Be,s=new Be,a=new wt,d=new Su,l=new yu,o={},f=t.maxTextureSize,h={[ai]:Zt,[Zt]:ai,[vn]:vn},u=new li({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Be},radius:{value:4}},vertexShader:a0,fragmentShader:o0}),p=u.clone();p.defines.HORIZONTAL_PASS=1;const m=new Mt;m.setAttribute("position",new On(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const x=new at(m,u),_=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Hr;let c=this.type;this.render=function(E,v,y){if(_.enabled===!1||_.autoUpdate===!1&&_.needsUpdate===!1||E.length===0)return;this.type===ad&&(Fe("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."),this.type=Hr);const T=i.getRenderTarget(),R=i.getActiveCubeFace(),N=i.getActiveMipmapLevel(),z=i.state;z.setBlending(Ai),z.buffers.depth.getReversed()===!0?z.buffers.color.setClear(0,0,0,0):z.buffers.color.setClear(1,1,1,1),z.buffers.depth.setTest(!0),z.setScissorTest(!1);const q=c!==this.type;q&&v.traverse(function(C){C.material&&(Array.isArray(C.material)?C.material.forEach(D=>D.needsUpdate=!0):C.material.needsUpdate=!0)});for(let C=0,D=E.length;C<D;C++){const O=E[C],k=O.shadow;if(k===void 0){Fe("WebGLShadowMap:",O,"has no shadow.");continue}if(k.autoUpdate===!1&&k.needsUpdate===!1)continue;r.copy(k.mapSize);const Q=k.getFrameExtents();r.multiply(Q),s.copy(k.mapSize),(r.x>f||r.y>f)&&(r.x>f&&(s.x=Math.floor(f/Q.x),r.x=s.x*Q.x,k.mapSize.x=s.x),r.y>f&&(s.y=Math.floor(f/Q.y),r.y=s.y*Q.y,k.mapSize.y=s.y));const G=i.state.buffers.depth.getReversed();if(k.camera._reversedDepth=G,k.map===null||q===!0){if(k.map!==null&&(k.map.depthTexture!==null&&(k.map.depthTexture.dispose(),k.map.depthTexture=null),k.map.dispose()),this.type===Ki){if(O.isPointLight){Fe("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}k.map=new yn(r.x,r.y,{format:oi,type:wn,minFilter:$t,magFilter:$t,generateMipmaps:!1}),k.map.texture.name=O.name+".shadowMap",k.map.depthTexture=new Di(r.x,r.y,Mn),k.map.depthTexture.name=O.name+".shadowMapDepth",k.map.depthTexture.format=Yn,k.map.depthTexture.compareFunction=null,k.map.depthTexture.minFilter=Ft,k.map.depthTexture.magFilter=Ft}else O.isPointLight?(k.map=new eo(r.x),k.map.depthTexture=new sc(r.x,En)):(k.map=new yn(r.x,r.y),k.map.depthTexture=new Di(r.x,r.y,En)),k.map.depthTexture.name=O.name+".shadowMap",k.map.depthTexture.format=Yn,this.type===Hr?(k.map.depthTexture.compareFunction=G?Jl:Kl,k.map.depthTexture.minFilter=$t,k.map.depthTexture.magFilter=$t):(k.map.depthTexture.compareFunction=null,k.map.depthTexture.minFilter=Ft,k.map.depthTexture.magFilter=Ft);k.camera.updateProjectionMatrix()}k.map.isWebGLCubeRenderTarget!==!0&&(k.map.width!==r.x||k.map.height!==r.y)&&k.map.setSize(r.x,r.y);const K=k.map.isWebGLCubeRenderTarget?6:k.getViewportCount();O.isPointLight!==!0&&k.updateMatrices(O,y);const j=(k.camera.layers.mask&4294967294)!==0?k.camera.layers:y.layers;for(let ce=0;ce<K;ce++){const ve=k.getCamera(ce);if(O.isPointLight){const $=k.camera,ie=k.matrix,_e=O.distance||$.far;_e!==$.far&&($.far=_e,$.updateProjectionMatrix()),qi.setFromMatrixPosition(O.matrixWorld),$.position.copy(qi),Hs.copy($.position),Hs.add(l0[ce]),$.up.copy(c0[ce]),$.lookAt(Hs),$.updateMatrixWorld(),ie.makeTranslation(-qi.x,-qi.y,-qi.z),ul.multiplyMatrices($.projectionMatrix,$.matrixWorldInverse),k._frustum.setFromProjectionMatrix(ul,$.coordinateSystem,$.reversedDepth)}if(k.map.isWebGLCubeRenderTarget)i.setRenderTarget(k.map,ce),i.clear();else{ce===0&&(i.setRenderTarget(k.map),i.clear());const $=k.getViewport(ce);a.set(s.x*$.x,s.y*$.y,s.x*$.z,s.y*$.w),z.viewport(a)}n=k.getFrustum(ce),M(v,y,ve,O,j,this.type)}k.isPointLightShadow!==!0&&this.type===Ki&&g(k,y),k.needsUpdate=!1}c=this.type,_.needsUpdate=!1,i.setRenderTarget(T,R,N)};function g(E,v){const y=e.update(x);u.defines.VSM_SAMPLES!==E.blurSamples&&(u.defines.VSM_SAMPLES=E.blurSamples,p.defines.VSM_SAMPLES=E.blurSamples,u.needsUpdate=!0,p.needsUpdate=!0),E.mapPass===null?E.mapPass=new yn(r.x,r.y,{format:oi,type:wn}):(E.mapPass.width!==E.map.width||E.mapPass.height!==E.map.height)&&E.mapPass.setSize(E.map.width,E.map.height),u.uniforms.shadow_pass.value=E.map.depthTexture,u.uniforms.resolution.value.set(E.map.width,E.map.height),u.uniforms.radius.value=E.radius,i.setRenderTarget(E.mapPass),i.clear(),i.renderBufferDirect(v,null,y,u,x,null),p.uniforms.shadow_pass.value=E.mapPass.texture,p.uniforms.resolution.value.set(E.map.width,E.map.height),p.uniforms.radius.value=E.radius,i.setRenderTarget(E.map),i.clear(),i.renderBufferDirect(v,null,y,p,x,null)}function S(E,v,y,T){let R=null;const N=y.isPointLight===!0?E.customDistanceMaterial:E.customDepthMaterial;if(N!==void 0)R=N;else if(R=y.isPointLight===!0?l:d,i.localClippingEnabled&&v.clipShadows===!0&&Array.isArray(v.clippingPlanes)&&v.clippingPlanes.length!==0||v.displacementMap&&v.displacementScale!==0||v.alphaMap&&v.alphaTest>0||v.map&&v.alphaTest>0||v.alphaToCoverage===!0){const z=R.uuid,q=v.uuid;let C=o[z];C===void 0&&(C={},o[z]=C);let D=C[q];D===void 0&&(D=R.clone(),C[q]=D,v.addEventListener("dispose",A)),R=D}if(R.visible=v.visible,R.wireframe=v.wireframe,T===Ki?R.side=v.shadowSide!==null?v.shadowSide:v.side:R.side=v.shadowSide!==null?v.shadowSide:h[v.side],R.alphaMap=v.alphaMap,R.alphaTest=v.alphaToCoverage===!0?.5:v.alphaTest,R.map=v.map,R.clipShadows=v.clipShadows,R.clippingPlanes=v.clippingPlanes,R.clipIntersection=v.clipIntersection,R.displacementMap=v.displacementMap,R.displacementScale=v.displacementScale,R.displacementBias=v.displacementBias,R.wireframeLinewidth=v.wireframeLinewidth,R.linewidth=v.linewidth,y.isPointLight===!0&&R.isMeshDistanceMaterial===!0){const z=i.properties.get(R);z.light=y}return R}function M(E,v,y,T,R,N){if(E.visible===!1)return;if(E.layers.test(R)&&(E.isMesh||E.isLine||E.isPoints)&&(E.castShadow||E.receiveShadow&&N===Ki)&&(!E.frustumCulled||E.intersectsFrustum(n))){E.modelViewMatrix.multiplyMatrices(y.matrixWorldInverse,E.matrixWorld);const C=e.update(E),D=E.material;if(Array.isArray(D)){const O=C.groups;for(let k=0,Q=O.length;k<Q;k++){const G=O[k],K=D[G.materialIndex];if(K&&K.visible){const j=S(E,K,T,N);E.onBeforeShadow(i,E,v,y,C,j,G),i.renderBufferDirect(y,null,C,j,E,G),E.onAfterShadow(i,E,v,y,C,j,G)}}}else if(D.visible){const O=S(E,D,T,N);E.onBeforeShadow(i,E,v,y,C,O,null),i.renderBufferDirect(y,null,C,O,E,null),E.onAfterShadow(i,E,v,y,C,O,null)}}const q=E.children;for(let C=0,D=q.length;C<D;C++)M(q[C],v,y,T,R,N)}function A(E){E.target.removeEventListener("dispose",A);for(const y in o){const T=o[y],R=E.target.uuid;R in T&&(T[R].dispose(),delete T[R])}}}function u0(i,e){function t(){let I=!1;const te=new wt;let J=null;const ue=new wt(0,0,0,0);return{setMask:function(le){J!==le&&!I&&(i.colorMask(le,le,le,le),J=le)},setLocked:function(le){I=le},setClear:function(le,de,Ce,Le,se){se===!0&&(le*=Le,de*=Le,Ce*=Le),te.set(le,de,Ce,Le),ue.equals(te)===!1&&(i.clearColor(le,de,Ce,Le),ue.copy(te))},reset:function(){I=!1,J=null,ue.set(-1,0,0,0)}}}function n(){let I=!1,te=!1,J=null,ue=null,le=null;return{setReversed:function(de){if(te!==de){const Ce=e.get("EXT_clip_control");de?Ce.clipControlEXT(Ce.LOWER_LEFT_EXT,Ce.ZERO_TO_ONE_EXT):Ce.clipControlEXT(Ce.LOWER_LEFT_EXT,Ce.NEGATIVE_ONE_TO_ONE_EXT),te=de;const Le=le;le=null,this.setClear(Le)}},getReversed:function(){return te},setTest:function(de){de?ae(i.DEPTH_TEST):Ne(i.DEPTH_TEST)},setMask:function(de){J!==de&&!I&&(i.depthMask(de),J=de)},setFunc:function(de){if(te&&(de=kd[de]),ue!==de){switch(de){case qs:i.depthFunc(i.NEVER);break;case Ys:i.depthFunc(i.ALWAYS);break;case $s:i.depthFunc(i.LESS);break;case er:i.depthFunc(i.LEQUAL);break;case Zs:i.depthFunc(i.EQUAL);break;case Ks:i.depthFunc(i.GEQUAL);break;case Js:i.depthFunc(i.GREATER);break;case Qs:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}ue=de}},setLocked:function(de){I=de},setClear:function(de){le!==de&&(le=de,te&&(de=1-de),i.clearDepth(de))},reset:function(){I=!1,J=null,ue=null,le=null,te=!1}}}function r(){let I=!1,te=null,J=null,ue=null,le=null,de=null,Ce=null,Le=null,se=null;return{setTest:function(be){I||(be?ae(i.STENCIL_TEST):Ne(i.STENCIL_TEST))},setMask:function(be){te!==be&&!I&&(i.stencilMask(be),te=be)},setFunc:function(be,Oe,ge){(J!==be||ue!==Oe||le!==ge)&&(i.stencilFunc(be,Oe,ge),J=be,ue=Oe,le=ge)},setOp:function(be,Oe,ge){(de!==be||Ce!==Oe||Le!==ge)&&(i.stencilOp(be,Oe,ge),de=be,Ce=Oe,Le=ge)},setLocked:function(be){I=be},setClear:function(be){se!==be&&(i.clearStencil(be),se=be)},reset:function(){I=!1,te=null,J=null,ue=null,le=null,de=null,Ce=null,Le=null,se=null}}}const s=new t,a=new n,d=new r;let l={};const o=new WeakMap;let f={},h={},u={},p=new WeakMap,m=[],x=null,_=!1,c=null,g=null,S=null,M=null,A=null,E=null,v=null,y=new We(0,0,0),T=0,R=!1,N=null,z=null,q=null,C=null,D=null;const O=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let k=!1,Q=0;const G=i.getParameter(i.VERSION);G.indexOf("WebGL")!==-1?(Q=parseFloat(/^WebGL (\d)/.exec(G)[1]),k=Q>=1):G.indexOf("OpenGL ES")!==-1&&(Q=parseFloat(/^OpenGL ES (\d)/.exec(G)[1]),k=Q>=2);let K=null,j={};const ce=i.getParameter(i.SCISSOR_BOX),ve=i.getParameter(i.VIEWPORT),$=new wt().fromArray(ce),ie=new wt().fromArray(ve);function _e(I,te,J,ue){const le=new Uint8Array(4),de=i.createTexture();i.bindTexture(I,de),i.texParameteri(I,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(I,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let Ce=0;Ce<J;Ce++)I===i.TEXTURE_3D||I===i.TEXTURE_2D_ARRAY?i.texImage3D(te,0,i.RGBA,1,1,ue,0,i.RGBA,i.UNSIGNED_BYTE,le):i.texImage2D(te+Ce,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,le);return de}const we={};we[i.TEXTURE_2D]=_e(i.TEXTURE_2D,i.TEXTURE_2D,1),we[i.TEXTURE_CUBE_MAP]=_e(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),we[i.TEXTURE_2D_ARRAY]=_e(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),we[i.TEXTURE_3D]=_e(i.TEXTURE_3D,i.TEXTURE_3D,1,1),s.setClear(0,0,0,1),a.setClear(1),d.setClear(0),ae(i.DEPTH_TEST),a.setFunc(er),Je(!1),Qe(uo),ae(i.CULL_FACE),Tt(Ai);function ae(I){f[I]!==!0&&(i.enable(I),f[I]=!0)}function Ne(I){f[I]!==!1&&(i.disable(I),f[I]=!1)}function ot(I,te){return u[I]!==te?(i.bindFramebuffer(I,te),u[I]=te,I===i.DRAW_FRAMEBUFFER&&(u[i.FRAMEBUFFER]=te),I===i.FRAMEBUFFER&&(u[i.DRAW_FRAMEBUFFER]=te),!0):!1}function ye(I,te){let J=m,ue=!1;if(I){J=p.get(te),J===void 0&&(J=[],p.set(te,J));const le=I.textures;if(J.length!==le.length||J[0]!==i.COLOR_ATTACHMENT0){for(let de=0,Ce=le.length;de<Ce;de++)J[de]=i.COLOR_ATTACHMENT0+de;J.length=le.length,ue=!0}}else J[0]!==i.BACK&&(J[0]=i.BACK,ue=!0);ue&&i.drawBuffers(J)}function He(I){return x!==I?(i.useProgram(I),x=I,!0):!1}const Xe={[Ei]:i.FUNC_ADD,[ld]:i.FUNC_SUBTRACT,[cd]:i.FUNC_REVERSE_SUBTRACT};Xe[dd]=i.MIN,Xe[ud]=i.MAX;const Ve={[fd]:i.ZERO,[hd]:i.ONE,[pd]:i.SRC_COLOR,[Dl]:i.SRC_ALPHA,[Md]:i.SRC_ALPHA_SATURATE,[vd]:i.DST_COLOR,[gd]:i.DST_ALPHA,[md]:i.ONE_MINUS_SRC_COLOR,[Il]:i.ONE_MINUS_SRC_ALPHA,[xd]:i.ONE_MINUS_DST_COLOR,[_d]:i.ONE_MINUS_DST_ALPHA,[Sd]:i.CONSTANT_COLOR,[yd]:i.ONE_MINUS_CONSTANT_COLOR,[bd]:i.CONSTANT_ALPHA,[Ed]:i.ONE_MINUS_CONSTANT_ALPHA};function Tt(I,te,J,ue,le,de,Ce,Le,se,be){if(I===Ai){_===!0&&(Ne(i.BLEND),_=!1);return}if(_===!1&&(ae(i.BLEND),_=!0),I!==od){if(I!==c||be!==R){if((g!==Ei||A!==Ei)&&(i.blendEquation(i.FUNC_ADD),g=Ei,A=Ei),be)switch(I){case Qi:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case fo:i.blendFunc(i.ONE,i.ONE);break;case ho:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case po:i.blendFuncSeparate(i.DST_COLOR,i.ONE_MINUS_SRC_ALPHA,i.ZERO,i.ONE);break;default:nt("WebGLState: Invalid blending: ",I);break}else switch(I){case Qi:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case fo:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE,i.ONE,i.ONE);break;case ho:nt("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case po:nt("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:nt("WebGLState: Invalid blending: ",I);break}S=null,M=null,E=null,v=null,y.set(0,0,0),T=0,c=I,R=be}return}le=le||te,de=de||J,Ce=Ce||ue,(te!==g||le!==A)&&(i.blendEquationSeparate(Xe[te],Xe[le]),g=te,A=le),(J!==S||ue!==M||de!==E||Ce!==v)&&(i.blendFuncSeparate(Ve[J],Ve[ue],Ve[de],Ve[Ce]),S=J,M=ue,E=de,v=Ce),(Le.equals(y)===!1||se!==T)&&(i.blendColor(Le.r,Le.g,Le.b,se),y.copy(Le),T=se),c=I,R=!1}function lt(I,te){I.side===vn?Ne(i.CULL_FACE):ae(i.CULL_FACE);let J=I.side===Zt;te&&(J=!J),Je(J),I.blending===Qi&&I.transparent===!1?Tt(Ai):Tt(I.blending,I.blendEquation,I.blendSrc,I.blendDst,I.blendEquationAlpha,I.blendSrcAlpha,I.blendDstAlpha,I.blendColor,I.blendAlpha,I.premultipliedAlpha),a.setFunc(I.depthFunc),a.setTest(I.depthTest),a.setMask(I.depthWrite),s.setMask(I.colorWrite);const ue=I.stencilWrite;d.setTest(ue),ue&&(d.setMask(I.stencilWriteMask),d.setFunc(I.stencilFunc,I.stencilRef,I.stencilFuncMask),d.setOp(I.stencilFail,I.stencilZFail,I.stencilZPass)),bt(I.polygonOffset,I.polygonOffsetFactor,I.polygonOffsetUnits),I.alphaToCoverage===!0?ae(i.SAMPLE_ALPHA_TO_COVERAGE):Ne(i.SAMPLE_ALPHA_TO_COVERAGE)}function Je(I){N!==I&&(I?i.frontFace(i.CW):i.frontFace(i.CCW),N=I)}function Qe(I){I!==rd?(ae(i.CULL_FACE),I!==z&&(I===uo?i.cullFace(i.BACK):I===sd?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Ne(i.CULL_FACE),z=I}function At(I){I!==q&&(k&&i.lineWidth(I),q=I)}function bt(I,te,J){I?(ae(i.POLYGON_OFFSET_FILL),(C!==te||D!==J)&&(C=te,D=J,a.getReversed()&&(te=-te,J=-J),i.polygonOffset(te,J))):Ne(i.POLYGON_OFFSET_FILL)}function Ht(I){I?ae(i.SCISSOR_TEST):Ne(i.SCISSOR_TEST)}function _t(I){I===void 0&&(I=i.TEXTURE0+O-1),K!==I&&(i.activeTexture(I),K=I)}function Vt(I,te,J){J===void 0&&(K===null?J=i.TEXTURE0+O-1:J=K);let ue=j[J];ue===void 0&&(ue={type:void 0,texture:void 0},j[J]=ue),(ue.type!==I||ue.texture!==te)&&(K!==J&&(i.activeTexture(J),K=J),i.bindTexture(I,te||we[I]),ue.type=I,ue.texture=te)}function B(){const I=j[K];I!==void 0&&I.type!==void 0&&(i.bindTexture(I.type,null),I.type=void 0,I.texture=void 0)}function St(){try{i.compressedTexImage2D(...arguments)}catch(I){nt("WebGLState:",I)}}function ct(){try{i.compressedTexImage3D(...arguments)}catch(I){nt("WebGLState:",I)}}function dt(){try{i.texSubImage2D(...arguments)}catch(I){nt("WebGLState:",I)}}function he(){try{i.texSubImage3D(...arguments)}catch(I){nt("WebGLState:",I)}}function yt(){try{i.compressedTexSubImage2D(...arguments)}catch(I){nt("WebGLState:",I)}}function De(){try{i.compressedTexSubImage3D(...arguments)}catch(I){nt("WebGLState:",I)}}function Ue(){try{i.texStorage2D(...arguments)}catch(I){nt("WebGLState:",I)}}function P(){try{i.texStorage3D(...arguments)}catch(I){nt("WebGLState:",I)}}function b(){try{i.texImage2D(...arguments)}catch(I){nt("WebGLState:",I)}}function V(){try{i.texImage3D(...arguments)}catch(I){nt("WebGLState:",I)}}function re(I){return h[I]!==void 0?h[I]:i.getParameter(I)}function ne(I,te){h[I]!==te&&(i.pixelStorei(I,te),h[I]=te)}function oe(I){$.equals(I)===!1&&(i.scissor(I.x,I.y,I.z,I.w),$.copy(I))}function L(I){ie.equals(I)===!1&&(i.viewport(I.x,I.y,I.z,I.w),ie.copy(I))}function Z(I,te){let J=o.get(te);J===void 0&&(J=new WeakMap,o.set(te,J));let ue=J.get(I);ue===void 0&&(ue=i.getUniformBlockIndex(te,I.name),i.uniformBlockBinding(te,ue,ue),J.set(I,ue))}function ee(I,te,J){const le=o.get(te).get(I);l[le]!==J&&(i.bindBufferBase(i.UNIFORM_BUFFER,le,J),l[le]=J)}function fe(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),a.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),i.pixelStorei(i.PACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,!1),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,i.BROWSER_DEFAULT_WEBGL),i.pixelStorei(i.PACK_ROW_LENGTH,0),i.pixelStorei(i.PACK_SKIP_PIXELS,0),i.pixelStorei(i.PACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_ROW_LENGTH,0),i.pixelStorei(i.UNPACK_IMAGE_HEIGHT,0),i.pixelStorei(i.UNPACK_SKIP_PIXELS,0),i.pixelStorei(i.UNPACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_SKIP_IMAGES,0),f={},h={},K=null,j={},u={},l={},p=new WeakMap,m=[],x=null,_=!1,c=null,g=null,S=null,M=null,A=null,E=null,v=null,y=new We(0,0,0),T=0,R=!1,N=null,z=null,q=null,C=null,D=null,$.set(0,0,i.canvas.width,i.canvas.height),ie.set(0,0,i.canvas.width,i.canvas.height),s.reset(),a.reset(),d.reset()}return{buffers:{color:s,depth:a,stencil:d},enable:ae,disable:Ne,bindFramebuffer:ot,drawBuffers:ye,useProgram:He,setBlending:Tt,setMaterial:lt,setFlipSided:Je,setCullFace:Qe,setLineWidth:At,setPolygonOffset:bt,setScissorTest:Ht,activeTexture:_t,bindTexture:Vt,unbindTexture:B,compressedTexImage2D:St,compressedTexImage3D:ct,texImage2D:b,texImage3D:V,pixelStorei:ne,getParameter:re,updateUBOMapping:Z,uniformBlockBinding:ee,texStorage2D:Ue,texStorage3D:P,texSubImage2D:dt,texSubImage3D:he,compressedTexSubImage2D:yt,compressedTexSubImage3D:De,scissor:oe,viewport:L,reset:fe}}function f0(i,e,t,n,r,s,a){const d=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),o=new Be,f=new WeakMap,h=new Set;let u;const p=new WeakMap,m=new Set,x=new FinalizationRegistry(P=>m.delete(P));let _=!1;try{_=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function c(P,b){return _?new OffscreenCanvas(P,b):ts("canvas")}function g(P,b,V){let re=1;const ne=Ue(P);if((ne.width>V||ne.height>V)&&(re=V/Math.max(ne.width,ne.height)),re<1)if(typeof HTMLImageElement<"u"&&P instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&P instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&P instanceof ImageBitmap||typeof VideoFrame<"u"&&P instanceof VideoFrame){const oe=Math.floor(re*ne.width),L=Math.floor(re*ne.height);u===void 0&&(u=c(oe,L));const Z=b?c(oe,L):u;return Z.width=oe,Z.height=L,Z.getContext("2d").drawImage(P,0,0,oe,L),Fe("WebGLRenderer: Texture has been resized from ("+ne.width+"x"+ne.height+") to ("+oe+"x"+L+")."),Z}else return"data"in P&&Fe("WebGLRenderer: Image in DataTexture is too big ("+ne.width+"x"+ne.height+")."),P;return P}function S(P){return P.generateMipmaps}function M(P){i.generateMipmap(P)}function A(P){return P.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:P.isWebGL3DRenderTarget?i.TEXTURE_3D:P.isWebGLArrayRenderTarget||P.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function E(P,b,V,re,ne,oe=!1){if(P!==null){if(i[P]!==void 0)return i[P];Fe("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+P+"'")}let L;re&&(L=e.get("EXT_texture_norm16"),L||Fe("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let Z=b;if(b===i.RED&&(V===i.FLOAT&&(Z=i.R32F),V===i.HALF_FLOAT&&(Z=i.R16F),V===i.UNSIGNED_BYTE&&(Z=i.R8),V===i.UNSIGNED_SHORT&&L&&(Z=L.R16_EXT),V===i.SHORT&&L&&(Z=L.R16_SNORM_EXT)),b===i.RED_INTEGER&&(V===i.UNSIGNED_BYTE&&(Z=i.R8UI),V===i.UNSIGNED_SHORT&&(Z=i.R16UI),V===i.UNSIGNED_INT&&(Z=i.R32UI),V===i.BYTE&&(Z=i.R8I),V===i.SHORT&&(Z=i.R16I),V===i.INT&&(Z=i.R32I)),b===i.RG&&(V===i.FLOAT&&(Z=i.RG32F),V===i.HALF_FLOAT&&(Z=i.RG16F),V===i.UNSIGNED_BYTE&&(Z=i.RG8),V===i.UNSIGNED_SHORT&&L&&(Z=L.RG16_EXT),V===i.SHORT&&L&&(Z=L.RG16_SNORM_EXT)),b===i.RG_INTEGER&&(V===i.UNSIGNED_BYTE&&(Z=i.RG8UI),V===i.UNSIGNED_SHORT&&(Z=i.RG16UI),V===i.UNSIGNED_INT&&(Z=i.RG32UI),V===i.BYTE&&(Z=i.RG8I),V===i.SHORT&&(Z=i.RG16I),V===i.INT&&(Z=i.RG32I)),b===i.RGB_INTEGER&&(V===i.UNSIGNED_BYTE&&(Z=i.RGB8UI),V===i.UNSIGNED_SHORT&&(Z=i.RGB16UI),V===i.UNSIGNED_INT&&(Z=i.RGB32UI),V===i.BYTE&&(Z=i.RGB8I),V===i.SHORT&&(Z=i.RGB16I),V===i.INT&&(Z=i.RGB32I)),b===i.RGBA_INTEGER&&(V===i.UNSIGNED_BYTE&&(Z=i.RGBA8UI),V===i.UNSIGNED_SHORT&&(Z=i.RGBA16UI),V===i.UNSIGNED_INT&&(Z=i.RGBA32UI),V===i.BYTE&&(Z=i.RGBA8I),V===i.SHORT&&(Z=i.RGBA16I),V===i.INT&&(Z=i.RGBA32I)),b===i.RGB&&(V===i.UNSIGNED_SHORT&&L&&(Z=L.RGB16_EXT),V===i.SHORT&&L&&(Z=L.RGB16_SNORM_EXT),V===i.UNSIGNED_INT_5_9_9_9_REV&&(Z=i.RGB9_E5),V===i.UNSIGNED_INT_10F_11F_11F_REV&&(Z=i.R11F_G11F_B10F)),b===i.RGBA){const ee=oe?es:Ke.getTransfer(ne);V===i.FLOAT&&(Z=i.RGBA32F),V===i.HALF_FLOAT&&(Z=i.RGBA16F),V===i.UNSIGNED_BYTE&&(Z=ee===st?i.SRGB8_ALPHA8:i.RGBA8),V===i.UNSIGNED_SHORT&&L&&(Z=L.RGBA16_EXT),V===i.SHORT&&L&&(Z=L.RGBA16_SNORM_EXT),V===i.UNSIGNED_SHORT_4_4_4_4&&(Z=i.RGBA4),V===i.UNSIGNED_SHORT_5_5_5_1&&(Z=i.RGB5_A1)}return(Z===i.R16F||Z===i.R32F||Z===i.RG16F||Z===i.RG32F||Z===i.RGBA16F||Z===i.RGBA32F)&&e.get("EXT_color_buffer_float"),Z}function v(P,b){let V;return P?b===null||b===En||b===Pi?V=i.DEPTH24_STENCIL8:b===Mn?V=i.DEPTH32F_STENCIL8:b===nr&&(V=i.DEPTH24_STENCIL8,Fe("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):b===null||b===En||b===Pi?V=i.DEPTH_COMPONENT24:b===Mn?V=i.DEPTH_COMPONENT32F:b===nr&&(V=i.DEPTH_COMPONENT16),V}function y(P,b){return S(P)===!0||P.isFramebufferTexture&&P.minFilter!==Ft&&P.minFilter!==$t?Math.log2(Math.max(b.width,b.height))+1:P.mipmaps.length>0?P.mipmaps.length:P.isCompressedTexture&&Array.isArray(P.image)?b.mipmaps.length:1}function T(P){const b=new WeakRef(P);n.get(P).__ref=b,m.add(b),x.register(P,b,b)}function R(P){const b=n.get(P).__ref;b!==void 0&&(m.delete(b),x.unregister(b))}function N(P){q(P.target)}function z(P){C(P.target)}function q(P){P.removeEventListener("dispose",N),R(P),O(P),P.isVideoTexture&&f.delete(P),P.isHTMLTexture&&h.delete(P)}function C(P){P.removeEventListener("dispose",z),R(P),Q(P)}function D(){for(const P of m){const b=P.deref();b!==void 0&&(b.isRenderTarget===!0?C(b):q(b))}m.clear(),h.clear()}function O(P){const b=n.get(P);if(b.__webglInit===void 0)return;const V=P.source,re=p.get(V);if(re){const ne=re[b.__cacheKey];ne.usedTimes--,ne.usedTimes===0&&k(P),Object.keys(re).length===0&&p.delete(V)}n.remove(P)}function k(P){const b=n.get(P);i.deleteTexture(b.__webglTexture);const V=P.source,re=p.get(V);delete re[b.__cacheKey],a.memory.textures--}function Q(P){const b=n.get(P);b.__depthDisposeCallback&&b.__depthDisposeCallback();const V=P.depthTexture;if(V&&V.renderTarget===P&&q(V),P.isWebGLCubeRenderTarget)for(let ne=0;ne<6;ne++){if(Array.isArray(b.__webglFramebuffer[ne]))for(let oe=0;oe<b.__webglFramebuffer[ne].length;oe++)i.deleteFramebuffer(b.__webglFramebuffer[ne][oe]);else i.deleteFramebuffer(b.__webglFramebuffer[ne]);b.__webglDepthbuffer&&i.deleteRenderbuffer(b.__webglDepthbuffer[ne])}else{if(Array.isArray(b.__webglFramebuffer))for(let ne=0;ne<b.__webglFramebuffer.length;ne++)i.deleteFramebuffer(b.__webglFramebuffer[ne]);else i.deleteFramebuffer(b.__webglFramebuffer);if(b.__webglDepthbuffer&&i.deleteRenderbuffer(b.__webglDepthbuffer),b.__webglMultisampledFramebuffer&&i.deleteFramebuffer(b.__webglMultisampledFramebuffer),b.__webglColorRenderbuffer)for(let ne=0;ne<b.__webglColorRenderbuffer.length;ne++)b.__webglColorRenderbuffer[ne]&&i.deleteRenderbuffer(b.__webglColorRenderbuffer[ne]);b.__webglDepthRenderbuffer&&i.deleteRenderbuffer(b.__webglDepthRenderbuffer)}const re=P.textures;for(let ne=0,oe=re.length;ne<oe;ne++){const L=n.get(re[ne]);L.__webglTexture&&(i.deleteTexture(L.__webglTexture),a.memory.textures--),n.remove(re[ne])}n.remove(P)}let G=0;function K(){G=0}function j(){return G}function ce(P){G=P}function ve(){const P=G;return P>=r.maxTextures&&Fe("WebGLTextures: Trying to use "+(P+1)+" texture units while this GPU supports only "+r.maxTextures),G+=1,P}function $(P){const b=[];return b.push(P.wrapS),b.push(P.wrapT),b.push(P.wrapR||0),b.push(P.magFilter),b.push(P.minFilter),b.push(P.anisotropy),b.push(P.internalFormat),b.push(P.format),b.push(P.type),b.push(P.generateMipmaps),b.push(P.mipmapsAutoUpdate),b.push(P.premultiplyAlpha),b.push(P.flipY),b.push(P.unpackAlignment),b.push(P.colorSpace),b.join()}function ie(P,b){const V=n.get(P);if(P.isVideoTexture&&yt(P),P.isRenderTargetTexture===!1&&P.isExternalTexture!==!0&&P.version>0&&V.__version!==P.version){const re=P.image;if(re===null)Fe("WebGLRenderer: Texture marked for update but no image data found.");else if(re.complete===!1)Fe("WebGLRenderer: Texture marked for update but image is incomplete");else{lt(V,P,b);return}}else P.isExternalTexture&&(V.__webglTexture=P.sourceTexture?P.sourceTexture:null);t.bindTexture(i.TEXTURE_2D,V.__webglTexture,i.TEXTURE0+b)}function _e(P,b){const V=n.get(P);if(P.isRenderTargetTexture===!1&&P.version>0&&V.__version!==P.version){lt(V,P,b);return}else P.isExternalTexture&&(V.__webglTexture=P.sourceTexture?P.sourceTexture:null);t.bindTexture(i.TEXTURE_2D_ARRAY,V.__webglTexture,i.TEXTURE0+b)}function we(P,b){const V=n.get(P);if(P.isRenderTargetTexture===!1&&P.version>0&&V.__version!==P.version){lt(V,P,b);return}t.bindTexture(i.TEXTURE_3D,V.__webglTexture,i.TEXTURE0+b)}function ae(P,b){const V=n.get(P);if(P.version>0&&V.__version!==P.version){Je(V,P,b);return}t.bindTexture(i.TEXTURE_CUBE_MAP,V.__webglTexture,i.TEXTURE0+b)}const Ne={[js]:i.REPEAT,[Nn]:i.CLAMP_TO_EDGE,[ea]:i.MIRRORED_REPEAT},ot={[Ft]:i.NEAREST,[Ad]:i.NEAREST_MIPMAP_NEAREST,[hr]:i.NEAREST_MIPMAP_LINEAR,[$t]:i.LINEAR,[ms]:i.LINEAR_MIPMAP_NEAREST,[Xn]:i.LINEAR_MIPMAP_LINEAR},ye={[Ld]:i.NEVER,[Ql]:i.ALWAYS,[Dd]:i.LESS,[Kl]:i.LEQUAL,[Id]:i.EQUAL,[Jl]:i.GEQUAL,[Nd]:i.GREATER,[Ud]:i.NOTEQUAL};function He(P,b){if(b.type===Mn&&e.has("OES_texture_float_linear")===!1&&(b.magFilter===$t||b.magFilter===ms||b.magFilter===hr||b.magFilter===Xn||b.minFilter===$t||b.minFilter===ms||b.minFilter===hr||b.minFilter===Xn)&&Fe("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(P,i.TEXTURE_WRAP_S,Ne[b.wrapS]),i.texParameteri(P,i.TEXTURE_WRAP_T,Ne[b.wrapT]),(P===i.TEXTURE_3D||P===i.TEXTURE_2D_ARRAY)&&i.texParameteri(P,i.TEXTURE_WRAP_R,Ne[b.wrapR]),i.texParameteri(P,i.TEXTURE_MAG_FILTER,ot[b.magFilter]),i.texParameteri(P,i.TEXTURE_MIN_FILTER,ot[b.minFilter]),b.compareFunction&&(i.texParameteri(P,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(P,i.TEXTURE_COMPARE_FUNC,ye[b.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(b.magFilter===Ft||b.minFilter!==hr&&b.minFilter!==Xn||b.type===Mn&&e.has("OES_texture_float_linear")===!1)return;if(b.anisotropy>1||n.get(b).__currentAnisotropy){const V=e.get("EXT_texture_filter_anisotropic");i.texParameterf(P,V.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(b.anisotropy,r.getMaxAnisotropy())),n.get(b).__currentAnisotropy=b.anisotropy}}}function Xe(P,b){let V=!1;P.__webglInit===void 0&&(P.__webglInit=!0,b.addEventListener("dispose",N),T(b));const re=b.source;let ne=p.get(re);ne===void 0&&(ne={},p.set(re,ne));const oe=$(b);if(oe!==P.__cacheKey){ne[oe]===void 0&&(ne[oe]={texture:i.createTexture(),usedTimes:0},a.memory.textures++,V=!0),ne[oe].usedTimes++;const L=ne[P.__cacheKey];L!==void 0&&(ne[P.__cacheKey].usedTimes--,L.usedTimes===0&&k(b)),P.__cacheKey=oe,P.__webglTexture=ne[oe].texture}return V}function Ve(P,b,V){return Math.floor(Math.floor(P/V)/b)}function Tt(P,b,V,re){const oe=P.updateRanges;if(oe.length===0)t.texSubImage2D(i.TEXTURE_2D,0,0,0,b.width,b.height,V,re,b.data);else{oe.sort((I,te)=>I.start-te.start);let L=0;for(let I=1;I<oe.length;I++){const te=oe[L],J=oe[I],ue=te.start+te.count,le=Ve(J.start,b.width,4),de=Ve(te.start,b.width,4);J.start<=ue+1&&le===de&&Ve(J.start+J.count-1,b.width,4)===le?te.count=Math.max(te.count,J.start+J.count-te.start):(++L,oe[L]=J)}oe.length=L+1;const Z=t.getParameter(i.UNPACK_ROW_LENGTH),ee=t.getParameter(i.UNPACK_SKIP_PIXELS),fe=t.getParameter(i.UNPACK_SKIP_ROWS);t.pixelStorei(i.UNPACK_ROW_LENGTH,b.width);for(let I=0,te=oe.length;I<te;I++){const J=oe[I],ue=Math.floor(J.start/4),le=Math.ceil(J.count/4),de=ue%b.width,Ce=Math.floor(ue/b.width),Le=le,se=1;t.pixelStorei(i.UNPACK_SKIP_PIXELS,de),t.pixelStorei(i.UNPACK_SKIP_ROWS,Ce),t.texSubImage2D(i.TEXTURE_2D,0,de,Ce,Le,se,V,re,b.data)}P.clearUpdateRanges(),t.pixelStorei(i.UNPACK_ROW_LENGTH,Z),t.pixelStorei(i.UNPACK_SKIP_PIXELS,ee),t.pixelStorei(i.UNPACK_SKIP_ROWS,fe)}}function lt(P,b,V){let re=i.TEXTURE_2D;(b.isDataArrayTexture||b.isCompressedArrayTexture)&&(re=i.TEXTURE_2D_ARRAY),b.isData3DTexture&&(re=i.TEXTURE_3D);const ne=Xe(P,b),oe=b.source;t.bindTexture(re,P.__webglTexture,i.TEXTURE0+V);const L=n.get(oe);if(oe.version!==L.__version||ne===!0){if(t.activeTexture(i.TEXTURE0+V),(typeof ImageBitmap<"u"&&b.image instanceof ImageBitmap)===!1){const se=Ke.getPrimaries(Ke.workingColorSpace),be=b.colorSpace===Wn?null:Ke.getPrimaries(b.colorSpace),Oe=b.colorSpace===Wn||se===be?i.NONE:i.BROWSER_DEFAULT_WEBGL;t.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,b.flipY),t.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),t.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Oe)}t.pixelStorei(i.UNPACK_ALIGNMENT,b.unpackAlignment);let ee=g(b.image,!1,r.maxTextureSize);ee=De(b,ee);const fe=s.convert(b.format,b.colorSpace),I=s.convert(b.type);let te=E(b.internalFormat,fe,I,b.normalized,b.colorSpace,b.isVideoTexture);He(re,b);let J;const ue=b.mipmaps,le=b.isVideoTexture!==!0,de=L.__version===void 0||ne===!0,Ce=oe.dataReady,Le=y(b,ee);if(b.isDepthTexture)te=v(b.format===qn,b.type),de&&(le?t.texStorage2D(i.TEXTURE_2D,1,te,ee.width,ee.height):t.texImage2D(i.TEXTURE_2D,0,te,ee.width,ee.height,0,fe,I,null));else if(b.isDataTexture)if(ue.length>0){le&&de&&t.texStorage2D(i.TEXTURE_2D,Le,te,ue[0].width,ue[0].height);for(let se=0,be=ue.length;se<be;se++)J=ue[se],le?Ce&&t.texSubImage2D(i.TEXTURE_2D,se,0,0,J.width,J.height,fe,I,J.data):t.texImage2D(i.TEXTURE_2D,se,te,J.width,J.height,0,fe,I,J.data);b.generateMipmaps=!1}else le?(de&&t.texStorage2D(i.TEXTURE_2D,Le,te,ee.width,ee.height),Ce&&Tt(b,ee,fe,I)):t.texImage2D(i.TEXTURE_2D,0,te,ee.width,ee.height,0,fe,I,ee.data);else if(b.isCompressedTexture)if(b.isCompressedArrayTexture){le&&de&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Le,te,ue[0].width,ue[0].height,ee.depth);for(let se=0,be=ue.length;se<be;se++)if(J=ue[se],b.format!==Sn)if(fe!==null)if(le){if(Ce)if(b.layerUpdates.size>0){const Oe=Wo(J.width,J.height,b.format,b.type);for(const ge of b.layerUpdates){const et=J.data.subarray(ge*Oe/J.data.BYTES_PER_ELEMENT,(ge+1)*Oe/J.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,se,0,0,ge,J.width,J.height,1,fe,et)}}else t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,se,0,0,0,J.width,J.height,ee.depth,fe,J.data)}else t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,se,te,J.width,J.height,ee.depth,0,J.data,0,0);else Fe("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else le?Ce&&t.texSubImage3D(i.TEXTURE_2D_ARRAY,se,0,0,0,J.width,J.height,ee.depth,fe,I,J.data):t.texImage3D(i.TEXTURE_2D_ARRAY,se,te,J.width,J.height,ee.depth,0,fe,I,J.data);b.layerUpdates.size>0&&b.clearLayerUpdates()}else{le&&de&&t.texStorage2D(i.TEXTURE_2D,Le,te,ue[0].width,ue[0].height);for(let se=0,be=ue.length;se<be;se++)J=ue[se],b.format!==Sn?fe!==null?le?Ce&&t.compressedTexSubImage2D(i.TEXTURE_2D,se,0,0,J.width,J.height,fe,J.data):t.compressedTexImage2D(i.TEXTURE_2D,se,te,J.width,J.height,0,J.data):Fe("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):le?Ce&&t.texSubImage2D(i.TEXTURE_2D,se,0,0,J.width,J.height,fe,I,J.data):t.texImage2D(i.TEXTURE_2D,se,te,J.width,J.height,0,fe,I,J.data)}else if(b.isDataArrayTexture)if(le){if(de&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Le,te,ee.width,ee.height,ee.depth),Ce)if(b.layerUpdates.size>0){const se=Wo(ee.width,ee.height,b.format,b.type);for(const be of b.layerUpdates){const Oe=ee.data.subarray(be*se/ee.data.BYTES_PER_ELEMENT,(be+1)*se/ee.data.BYTES_PER_ELEMENT);t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,be,ee.width,ee.height,1,fe,I,Oe)}b.clearLayerUpdates()}else t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,ee.width,ee.height,ee.depth,fe,I,ee.data)}else t.texImage3D(i.TEXTURE_2D_ARRAY,0,te,ee.width,ee.height,ee.depth,0,fe,I,ee.data);else if(b.isData3DTexture)le?(de&&t.texStorage3D(i.TEXTURE_3D,Le,te,ee.width,ee.height,ee.depth),Ce&&t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,ee.width,ee.height,ee.depth,fe,I,ee.data)):t.texImage3D(i.TEXTURE_3D,0,te,ee.width,ee.height,ee.depth,0,fe,I,ee.data);else if(b.isFramebufferTexture){if(de)if(le)t.texStorage2D(i.TEXTURE_2D,Le,te,ee.width,ee.height);else{let se=ee.width,be=ee.height;for(let Oe=0;Oe<Le;Oe++)t.texImage2D(i.TEXTURE_2D,Oe,te,se,be,0,fe,I,null),se>>=1,be>>=1}}else if(b.isHTMLTexture){if("texElementImage2D"in i){const se=i.canvas;if(se.hasAttribute("layoutsubtree")||se.setAttribute("layoutsubtree","true"),ee.parentNode!==se){se.appendChild(ee),h.add(b),se.onpaint=be=>{const Oe=be.changedElements;for(const ge of h)Oe.includes(ge.image)&&(ge.needsUpdate=!0)},se.requestPaint();return}if(i.texElementImage2D.length===3)i.texElementImage2D(i.TEXTURE_2D,i.RGBA8,ee);else{const Oe=i.RGBA,ge=i.RGBA,et=i.UNSIGNED_BYTE;i.texElementImage2D(i.TEXTURE_2D,0,Oe,ge,et,ee)}i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MIN_FILTER,i.LINEAR),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE)}}else if(ue.length>0){if(le&&de){const se=Ue(ue[0]);t.texStorage2D(i.TEXTURE_2D,Le,te,se.width,se.height)}for(let se=0,be=ue.length;se<be;se++)J=ue[se],le?Ce&&t.texSubImage2D(i.TEXTURE_2D,se,0,0,fe,I,J):t.texImage2D(i.TEXTURE_2D,se,te,fe,I,J);b.generateMipmaps=!1}else if(le){if(de){const se=Ue(ee);t.texStorage2D(i.TEXTURE_2D,Le,te,se.width,se.height)}Ce&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,fe,I,ee)}else t.texImage2D(i.TEXTURE_2D,0,te,fe,I,ee);S(b)&&b.mipmapsAutoUpdate===!0&&M(re),L.__version=oe.version,b.onUpdate&&b.onUpdate(b)}P.__version=b.version}function Je(P,b,V){if(b.image.length!==6)return;const re=Xe(P,b),ne=b.source;t.bindTexture(i.TEXTURE_CUBE_MAP,P.__webglTexture,i.TEXTURE0+V);const oe=n.get(ne);if(ne.version!==oe.__version||re===!0){t.activeTexture(i.TEXTURE0+V);const L=Ke.getPrimaries(Ke.workingColorSpace),Z=b.colorSpace===Wn?null:Ke.getPrimaries(b.colorSpace),ee=b.colorSpace===Wn||L===Z?i.NONE:i.BROWSER_DEFAULT_WEBGL;t.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,b.flipY),t.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),t.pixelStorei(i.UNPACK_ALIGNMENT,b.unpackAlignment),t.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,ee);const fe=b.isCompressedTexture||b.image[0].isCompressedTexture,I=b.image[0]&&b.image[0].isDataTexture,te=[];for(let ge=0;ge<6;ge++)!fe&&!I?te[ge]=g(b.image[ge],!0,r.maxCubemapSize):te[ge]=I?b.image[ge].image:b.image[ge],te[ge]=De(b,te[ge]);const J=te[0],ue=s.convert(b.format,b.colorSpace),le=s.convert(b.type);let de=E(b.internalFormat,ue,le,b.normalized,b.colorSpace);const Ce=b.isVideoTexture!==!0,Le=oe.__version===void 0||re===!0,se=ne.dataReady;let be=y(b,J);He(i.TEXTURE_CUBE_MAP,b);let Oe;if(b.isDepthTexture){if(de=v(b.format===qn,b.type),Le)if(Ce)t.texStorage2D(i.TEXTURE_CUBE_MAP,1,de,J.width,J.height);else for(let ge=0;ge<6;ge++)t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0,de,J.width,J.height,0,ue,le,null)}else if(fe){Ce&&Le&&t.texStorage2D(i.TEXTURE_CUBE_MAP,be,de,J.width,J.height);for(let ge=0;ge<6;ge++){Oe=te[ge].mipmaps;for(let et=0;et<Oe.length;et++){const Et=Oe[et];b.format!==Sn?ue!==null?Ce?se&&t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,et,0,0,Et.width,Et.height,ue,Et.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,et,de,Et.width,Et.height,0,Et.data):Fe("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Ce?se&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,et,0,0,Et.width,Et.height,ue,le,Et.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,et,de,Et.width,Et.height,0,ue,le,Et.data)}}}else{if(Oe=b.mipmaps,Ce&&Le){Oe.length>0&&be++;const ge=Ue(te[0]);t.texStorage2D(i.TEXTURE_CUBE_MAP,be,de,ge.width,ge.height)}for(let ge=0;ge<6;ge++)if(I){Ce?se&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0,0,0,te[ge].width,te[ge].height,ue,le,te[ge].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0,de,te[ge].width,te[ge].height,0,ue,le,te[ge].data);for(let et=0;et<Oe.length;et++){const on=Oe[et].image[ge].image;Ce?se&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,et+1,0,0,on.width,on.height,ue,le,on.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,et+1,de,on.width,on.height,0,ue,le,on.data)}}else{Ce?se&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0,0,0,ue,le,te[ge]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0,de,ue,le,te[ge]);for(let et=0;et<Oe.length;et++){const Et=Oe[et];Ce?se&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,et+1,0,0,ue,le,Et.image[ge]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,et+1,de,ue,le,Et.image[ge])}}}S(b)&&b.mipmapsAutoUpdate===!0&&M(i.TEXTURE_CUBE_MAP),oe.__version=ne.version,b.onUpdate&&b.onUpdate(b)}P.__version=b.version}function Qe(P,b,V,re,ne,oe){const L=s.convert(V.format,V.colorSpace),Z=s.convert(V.type),ee=E(V.internalFormat,L,Z,V.normalized,V.colorSpace),fe=n.get(b),I=n.get(V);if(I.__renderTarget=b,!fe.__hasExternalTextures){const te=Math.max(1,b.width>>oe),J=Math.max(1,b.height>>oe);ne===i.TEXTURE_3D||ne===i.TEXTURE_2D_ARRAY?t.texImage3D(ne,oe,ee,te,J,b.depth,0,L,Z,null):t.texImage2D(ne,oe,ee,te,J,0,L,Z,null)}t.bindFramebuffer(i.FRAMEBUFFER,P),he(b)?d.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,re,ne,I.__webglTexture,0,dt(b)):(ne===i.TEXTURE_2D||ne>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&ne<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,re,ne,I.__webglTexture,oe),t.bindFramebuffer(i.FRAMEBUFFER,null)}function At(P,b,V){if(i.bindRenderbuffer(i.RENDERBUFFER,P),b.depthBuffer){const re=b.depthTexture,ne=re&&re.isDepthTexture?re.type:null,oe=v(b.stencilBuffer,ne),L=b.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;he(b)?d.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,dt(b),oe,b.width,b.height):V?i.renderbufferStorageMultisample(i.RENDERBUFFER,dt(b),oe,b.width,b.height):i.renderbufferStorage(i.RENDERBUFFER,oe,b.width,b.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,L,i.RENDERBUFFER,P)}else{const re=b.textures;for(let ne=0;ne<re.length;ne++){const oe=re[ne],L=s.convert(oe.format,oe.colorSpace),Z=s.convert(oe.type),ee=E(oe.internalFormat,L,Z,oe.normalized,oe.colorSpace);he(b)?d.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,dt(b),ee,b.width,b.height):V?i.renderbufferStorageMultisample(i.RENDERBUFFER,dt(b),ee,b.width,b.height):i.renderbufferStorage(i.RENDERBUFFER,ee,b.width,b.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function bt(P,b,V){const re=b.isWebGLCubeRenderTarget===!0;if(t.bindFramebuffer(i.FRAMEBUFFER,P),!(b.depthTexture&&b.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const ne=n.get(b.depthTexture);ne.__renderTarget=b;const oe=re?b.depthTexture.image[0]:b.depthTexture.image;(!ne.__webglTexture||oe.width!==b.width||oe.height!==b.height)&&(oe.width=b.width,oe.height=b.height,b.depthTexture.needsUpdate=!0),re?ae(b.depthTexture,0):ie(b.depthTexture,0);const L=ne.__webglTexture,Z=dt(b),ee=re?i.TEXTURE_CUBE_MAP_POSITIVE_X+V:i.TEXTURE_2D,fe=b.depthTexture.format===qn?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;if(b.depthTexture.format===Yn)he(b)?d.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,fe,ee,L,0,Z):i.framebufferTexture2D(i.FRAMEBUFFER,fe,ee,L,0);else if(b.depthTexture.format===qn)he(b)?d.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,fe,ee,L,0,Z):i.framebufferTexture2D(i.FRAMEBUFFER,fe,ee,L,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function Ht(P){const b=n.get(P),V=P.isWebGLCubeRenderTarget===!0;if(b.__boundDepthTexture!==P.depthTexture){const re=P.depthTexture;if(b.__depthDisposeCallback&&b.__depthDisposeCallback(),re){const ne=()=>{delete b.__boundDepthTexture,delete b.__depthDisposeCallback,re.removeEventListener("dispose",ne)};re.addEventListener("dispose",ne),b.__depthDisposeCallback=ne}b.__boundDepthTexture=re}if(P.depthTexture&&!b.__autoAllocateDepthBuffer)if(V)for(let re=0;re<6;re++)bt(b.__webglFramebuffer[re],P,re);else P.texture.mipmaps.length>0?bt(b.__webglFramebuffer[0],P,0):bt(b.__webglFramebuffer,P,0);else if(V){b.__webglDepthbuffer=[];for(let re=0;re<6;re++)if(t.bindFramebuffer(i.FRAMEBUFFER,b.__webglFramebuffer[re]),b.__webglDepthbuffer[re]===void 0)b.__webglDepthbuffer[re]=i.createRenderbuffer(),At(b.__webglDepthbuffer[re],P,!1);else{const ne=P.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,oe=b.__webglDepthbuffer[re];i.bindRenderbuffer(i.RENDERBUFFER,oe),i.framebufferRenderbuffer(i.FRAMEBUFFER,ne,i.RENDERBUFFER,oe)}}else if(P.texture.mipmaps.length>0?t.bindFramebuffer(i.FRAMEBUFFER,b.__webglFramebuffer[0]):t.bindFramebuffer(i.FRAMEBUFFER,b.__webglFramebuffer),b.__webglDepthbuffer===void 0)b.__webglDepthbuffer=i.createRenderbuffer(),At(b.__webglDepthbuffer,P,!1);else{const ne=P.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,oe=b.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,oe),i.framebufferRenderbuffer(i.FRAMEBUFFER,ne,i.RENDERBUFFER,oe)}t.bindFramebuffer(i.FRAMEBUFFER,null)}function _t(P,b,V){const re=n.get(P);b!==void 0&&Qe(re.__webglFramebuffer,P,P.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),V!==void 0&&Ht(P)}function Vt(P){const b=P.texture,V=n.get(P),re=n.get(b);P.addEventListener("dispose",z),T(P);const ne=P.textures,oe=P.isWebGLCubeRenderTarget===!0,L=ne.length>1;if(L||(re.__webglTexture===void 0&&(re.__webglTexture=i.createTexture()),re.__version=b.version,a.memory.textures++),oe){V.__webglFramebuffer=[];for(let Z=0;Z<6;Z++)if(b.mipmaps.length>0){V.__webglFramebuffer[Z]=[];for(let ee=0;ee<b.mipmaps.length;ee++)V.__webglFramebuffer[Z][ee]=i.createFramebuffer()}else V.__webglFramebuffer[Z]=i.createFramebuffer()}else{if(b.mipmaps.length>0){V.__webglFramebuffer=[];for(let Z=0;Z<b.mipmaps.length;Z++)V.__webglFramebuffer[Z]=i.createFramebuffer()}else V.__webglFramebuffer=i.createFramebuffer();if(L)for(let Z=0,ee=ne.length;Z<ee;Z++){const fe=n.get(ne[Z]);fe.__webglTexture===void 0&&(fe.__webglTexture=i.createTexture(),a.memory.textures++)}if(P.samples>0&&he(P)===!1){V.__webglMultisampledFramebuffer=i.createFramebuffer(),V.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,V.__webglMultisampledFramebuffer);for(let Z=0;Z<ne.length;Z++){const ee=ne[Z];V.__webglColorRenderbuffer[Z]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,V.__webglColorRenderbuffer[Z]);const fe=s.convert(ee.format,ee.colorSpace),I=s.convert(ee.type),te=E(ee.internalFormat,fe,I,ee.normalized,ee.colorSpace,P.isXRRenderTarget===!0),J=dt(P);i.renderbufferStorageMultisample(i.RENDERBUFFER,J,te,P.width,P.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Z,i.RENDERBUFFER,V.__webglColorRenderbuffer[Z])}i.bindRenderbuffer(i.RENDERBUFFER,null),P.depthBuffer&&(V.__webglDepthRenderbuffer=i.createRenderbuffer(),At(V.__webglDepthRenderbuffer,P,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if(oe){t.bindTexture(i.TEXTURE_CUBE_MAP,re.__webglTexture),He(i.TEXTURE_CUBE_MAP,b);for(let Z=0;Z<6;Z++)if(b.mipmaps.length>0)for(let ee=0;ee<b.mipmaps.length;ee++)Qe(V.__webglFramebuffer[Z][ee],P,b,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,ee);else Qe(V.__webglFramebuffer[Z],P,b,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0);S(b)?M(i.TEXTURE_CUBE_MAP):b.mipmaps.length>0&&i.texParameteri(i.TEXTURE_CUBE_MAP,i.TEXTURE_MAX_LEVEL,b.mipmaps.length-1),t.unbindTexture()}else if(L){for(let Z=0,ee=ne.length;Z<ee;Z++){const fe=ne[Z],I=n.get(fe);let te=i.TEXTURE_2D;(P.isWebGL3DRenderTarget||P.isWebGLArrayRenderTarget)&&(te=P.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(te,I.__webglTexture),He(te,fe),Qe(V.__webglFramebuffer,P,fe,i.COLOR_ATTACHMENT0+Z,te,0),S(fe)&&M(te)}t.unbindTexture()}else{let Z=i.TEXTURE_2D;if((P.isWebGL3DRenderTarget||P.isWebGLArrayRenderTarget)&&(Z=P.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(Z,re.__webglTexture),He(Z,b),b.mipmaps.length>0)for(let ee=0;ee<b.mipmaps.length;ee++)Qe(V.__webglFramebuffer[ee],P,b,i.COLOR_ATTACHMENT0,Z,ee);else Qe(V.__webglFramebuffer,P,b,i.COLOR_ATTACHMENT0,Z,0);S(b)?M(Z):b.mipmaps.length>0&&i.texParameteri(Z,i.TEXTURE_MAX_LEVEL,b.mipmaps.length-1),t.unbindTexture()}P.depthBuffer&&Ht(P)}function B(P){const b=P.textures;for(let V=0,re=b.length;V<re;V++){const ne=b[V];if(S(ne)&&ne.mipmapsAutoUpdate===!0){const oe=A(P),L=n.get(ne).__webglTexture;t.bindTexture(oe,L),M(oe),t.unbindTexture()}}}const St=[];function ct(P){if(P.samples>0){if(he(P)===!1){const b=P.textures,V=P.width,re=P.height;let ne=i.COLOR_BUFFER_BIT;const oe=P.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,L=n.get(P),Z=b.length>1;if(Z)for(let fe=0;fe<b.length;fe++)t.bindFramebuffer(i.FRAMEBUFFER,L.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+fe,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,L.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+fe,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,L.__webglMultisampledFramebuffer),P.texture.mipmaps.length>0?t.bindFramebuffer(i.DRAW_FRAMEBUFFER,L.__webglFramebuffer[0]):t.bindFramebuffer(i.DRAW_FRAMEBUFFER,L.__webglFramebuffer);for(let fe=0;fe<b.length;fe++){if(P.resolveDepthBuffer&&(P.depthBuffer&&(ne|=i.DEPTH_BUFFER_BIT),P.stencilBuffer&&P.resolveStencilBuffer&&(ne|=i.STENCIL_BUFFER_BIT)),Z){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,L.__webglColorRenderbuffer[fe]);const I=n.get(b[fe]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,I,0)}i.blitFramebuffer(0,0,V,re,0,0,V,re,ne,i.NEAREST),l===!0&&(St.length=0,St.push(i.COLOR_ATTACHMENT0+fe),P.depthBuffer&&P.storeMultisampledDepthBuffer===!1&&St.push(oe),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,St))}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),Z)for(let fe=0;fe<b.length;fe++){t.bindFramebuffer(i.FRAMEBUFFER,L.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+fe,i.RENDERBUFFER,L.__webglColorRenderbuffer[fe]);const I=n.get(b[fe]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,L.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+fe,i.TEXTURE_2D,I,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,L.__webglMultisampledFramebuffer)}else if(P.depthBuffer&&P.storeMultisampledDepthBuffer===!1&&l){const b=P.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[b])}}}function dt(P){return Math.min(r.maxSamples,P.samples)}function he(P){const b=n.get(P);return P.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&b.__useRenderToTexture!==!1}function yt(P){const b=a.render.frame;f.get(P)!==b&&(f.set(P,b),P.update())}function De(P,b){const V=P.colorSpace,re=P.format,ne=P.type;return P.isCompressedTexture===!0||P.isVideoTexture===!0||V!==jr&&V!==Wn&&(Ke.getTransfer(V)===st?(re!==Sn||ne!==en)&&Fe("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):nt("WebGLTextures: Unsupported texture color space:",V)),b}function Ue(P){return typeof HTMLImageElement<"u"&&P instanceof HTMLImageElement?(o.width=P.naturalWidth||P.width,o.height=P.naturalHeight||P.height):typeof VideoFrame<"u"&&P instanceof VideoFrame?(o.width=P.displayWidth,o.height=P.displayHeight):(o.width=P.width,o.height=P.height),o}this.allocateTextureUnit=ve,this.resetTextureUnits=K,this.getTextureUnits=j,this.setTextureUnits=ce,this.setTexture2D=ie,this.setTexture2DArray=_e,this.setTexture3D=we,this.setTextureCube=ae,this.rebindTextures=_t,this.setupRenderTarget=Vt,this.updateRenderTargetMipmap=B,this.updateMultisampleRenderTarget=ct,this.setupDepthRenderbuffer=Ht,this.setupFrameBufferTexture=Qe,this.useMultisampledRTT=he,this.dispose=D}function h0(i,e){function t(n,r=Wn){let s;const a=Ke.getTransfer(r);if(n===en)return i.UNSIGNED_BYTE;if(n===Ha)return i.UNSIGNED_SHORT_4_4_4_4;if(n===Va)return i.UNSIGNED_SHORT_5_5_5_1;if(n===Xl)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===ql)return i.UNSIGNED_INT_10F_11F_11F_REV;if(n===Vl)return i.BYTE;if(n===Wl)return i.SHORT;if(n===nr)return i.UNSIGNED_SHORT;if(n===Ga)return i.INT;if(n===En)return i.UNSIGNED_INT;if(n===Mn)return i.FLOAT;if(n===wn)return i.HALF_FLOAT;if(n===Yl)return i.ALPHA;if(n===$l)return i.RGB;if(n===Sn)return i.RGBA;if(n===Yn)return i.DEPTH_COMPONENT;if(n===qn)return i.DEPTH_STENCIL;if(n===Zl)return i.RED;if(n===Wa)return i.RED_INTEGER;if(n===oi)return i.RG;if(n===Xa)return i.RG_INTEGER;if(n===qa)return i.RGBA_INTEGER;if(n===Vr||n===Wr||n===Xr||n===qr)if(a===st)if(s=e.get("WEBGL_compressed_texture_s3tc_srgb"),s!==null){if(n===Vr)return s.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Wr)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Xr)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===qr)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(s=e.get("WEBGL_compressed_texture_s3tc"),s!==null){if(n===Vr)return s.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Wr)return s.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Xr)return s.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===qr)return s.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===ta||n===na||n===ia||n===ra)if(s=e.get("WEBGL_compressed_texture_pvrtc"),s!==null){if(n===ta)return s.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===na)return s.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===ia)return s.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===ra)return s.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===sa||n===aa||n===oa||n===la||n===ca||n===Jr||n===da)if(s=e.get("WEBGL_compressed_texture_etc"),s!==null){if(n===sa||n===aa)return a===st?s.COMPRESSED_SRGB8_ETC2:s.COMPRESSED_RGB8_ETC2;if(n===oa)return a===st?s.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:s.COMPRESSED_RGBA8_ETC2_EAC;if(n===la)return s.COMPRESSED_R11_EAC;if(n===ca)return s.COMPRESSED_SIGNED_R11_EAC;if(n===Jr)return s.COMPRESSED_RG11_EAC;if(n===da)return s.COMPRESSED_SIGNED_RG11_EAC}else return null;if(n===ua||n===fa||n===ha||n===pa||n===ma||n===ga||n===_a||n===va||n===xa||n===Ma||n===Sa||n===ya||n===ba||n===Ea)if(s=e.get("WEBGL_compressed_texture_astc"),s!==null){if(n===ua)return a===st?s.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:s.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===fa)return a===st?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:s.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===ha)return a===st?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:s.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===pa)return a===st?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:s.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===ma)return a===st?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:s.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===ga)return a===st?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:s.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===_a)return a===st?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:s.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===va)return a===st?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:s.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===xa)return a===st?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:s.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Ma)return a===st?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:s.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Sa)return a===st?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:s.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===ya)return a===st?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:s.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===ba)return a===st?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:s.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===Ea)return a===st?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:s.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===wa||n===Ta||n===Aa)if(s=e.get("EXT_texture_compression_bptc"),s!==null){if(n===wa)return a===st?s.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:s.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Ta)return s.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Aa)return s.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Ra||n===Ca||n===Qr||n===Pa)if(s=e.get("EXT_texture_compression_rgtc"),s!==null){if(n===Ra)return s.COMPRESSED_RED_RGTC1_EXT;if(n===Ca)return s.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Qr)return s.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Pa)return s.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===Pi?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:t}}const p0=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,m0=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class g0{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const n=new ac(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,n=new li({vertexShader:p0,fragmentShader:m0,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new at(new Fi(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class _0 extends ci{constructor(e,t){super();const n=this;let r=null,s=1,a=null,d="local-floor",l=1,o=null,f=null,h=null,u=null,p=null,m=null;const x=typeof XRWebGLBinding<"u",_=new g0,c={},g=t.getContextAttributes();let S=null,M=null;const A=[],E=[],v=new Be;let y=null,T=null;const R=new gn;R.viewport=new wt;const N=new gn;N.viewport=new wt;const z=[R,N],q=new Au;let C=null,D=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function($){let ie=A[$];return ie===void 0&&(ie=new bs,A[$]=ie),ie.getTargetRaySpace()},this.getControllerGrip=function($){let ie=A[$];return ie===void 0&&(ie=new bs,A[$]=ie),ie.getGripSpace()},this.getHand=function($){let ie=A[$];return ie===void 0&&(ie=new bs,A[$]=ie),ie.getHandSpace()};function O($){const ie=E.indexOf($.inputSource);if(ie===-1)return;const _e=A[ie];_e!==void 0&&(_e.update($.inputSource,$.frame,o||a),_e.dispatchEvent({type:$.type,data:$.inputSource}))}function k(){r.removeEventListener("select",O),r.removeEventListener("selectstart",O),r.removeEventListener("selectend",O),r.removeEventListener("squeeze",O),r.removeEventListener("squeezestart",O),r.removeEventListener("squeezeend",O),r.removeEventListener("end",k),r.removeEventListener("inputsourceschange",Q);for(let $=0;$<A.length;$++){const ie=E[$];ie!==null&&(E[$]=null,A[$].disconnect(ie))}C=null,D=null,_.reset();for(const $ in c)delete c[$];if(e.setRenderTarget(S),p=null,u=null,h=null,r=null,M=null,ve.stop(),n.isPresenting=!1,e.setPixelRatio(y),e.setSize(v.width,v.height,!1),T!==null){const $=T.camera;$.fov=T.fov,$.zoom=T.zoom,$.updateProjectionMatrix(),T=null}n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function($){s=$,n.isPresenting===!0&&Fe("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function($){d=$,n.isPresenting===!0&&Fe("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return o||a},this.setReferenceSpace=function($){o=$},this.getBaseLayer=function(){return u!==null?u:p},this.getBinding=function(){return h===null&&x&&(h=new XRWebGLBinding(r,t)),h},this.getFrame=function(){return m},this.getSession=function(){return r},this.setSession=async function($){if(r=$,r!==null){if(S=e.getRenderTarget(),r.addEventListener("select",O),r.addEventListener("selectstart",O),r.addEventListener("selectend",O),r.addEventListener("squeeze",O),r.addEventListener("squeezestart",O),r.addEventListener("squeezeend",O),r.addEventListener("end",k),r.addEventListener("inputsourceschange",Q),g.xrCompatible!==!0&&await t.makeXRCompatible(),y=e.getPixelRatio(),e.getSize(v),x&&"createProjectionLayer"in XRWebGLBinding.prototype){let _e=null,we=null,ae=null;g.depth&&(ae=g.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,_e=g.stencil?qn:Yn,we=g.stencil?Pi:En);const Ne={colorFormat:t.RGBA8,depthFormat:ae,scaleFactor:s};h=this.getBinding(),u=h.createProjectionLayer(Ne),r.updateRenderState({layers:[u]}),e.setPixelRatio(1),e.setSize(u.textureWidth,u.textureHeight,!1),M=new yn(u.textureWidth,u.textureHeight,{format:Sn,type:en,depthTexture:new Di(u.textureWidth,u.textureHeight,we,void 0,void 0,void 0,void 0,void 0,void 0,_e),stencilBuffer:g.stencil,colorSpace:e.outputColorSpace,samples:g.antialias?4:0,resolveDepthBuffer:u.ignoreDepthValues===!1,resolveStencilBuffer:u.ignoreDepthValues===!1,storeMultisampledDepthBuffer:u.ignoreDepthValues===!1,storeMultisampledStencilBuffer:u.ignoreDepthValues===!1})}else{const _e={antialias:g.antialias,alpha:!0,depth:g.depth,stencil:g.stencil,framebufferScaleFactor:s};p=new XRWebGLLayer(r,t,_e),r.updateRenderState({baseLayer:p}),e.setPixelRatio(1),e.setSize(p.framebufferWidth,p.framebufferHeight,!1),M=new yn(p.framebufferWidth,p.framebufferHeight,{format:Sn,type:en,colorSpace:e.outputColorSpace,stencilBuffer:g.stencil,resolveDepthBuffer:p.ignoreDepthValues===!1,resolveStencilBuffer:p.ignoreDepthValues===!1,storeMultisampledDepthBuffer:p.ignoreDepthValues===!1,storeMultisampledStencilBuffer:p.ignoreDepthValues===!1})}M.isXRRenderTarget=!0,this.setFoveation(l),o=null,a=await r.requestReferenceSpace(d),ve.setContext(r),ve.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return _.getDepthTexture()};function Q($){for(let ie=0;ie<$.removed.length;ie++){const _e=$.removed[ie],we=E.indexOf(_e);we>=0&&(E[we]=null,A[we].disconnect(_e))}for(let ie=0;ie<$.added.length;ie++){const _e=$.added[ie];let we=E.indexOf(_e);if(we===-1){for(let Ne=0;Ne<A.length;Ne++)if(Ne>=E.length){E.push(_e),we=Ne;break}else if(E[Ne]===null){E[Ne]=_e,we=Ne;break}if(we===-1)break}const ae=A[we];ae&&ae.connect(_e)}}function G($,ie){ie===null?$.matrixWorld.copy($.matrix):$.matrixWorld.multiplyMatrices(ie.matrixWorld,$.matrix),$.matrixWorldInverse.copy($.matrixWorld).invert()}this.updateCamera=function($){if(r===null)return;let ie=$.near,_e=$.far;_.texture!==null&&(_.depthNear>0&&(ie=_.depthNear),_.depthFar>0&&(_e=_.depthFar)),q.near=N.near=R.near=ie,q.far=N.far=R.far=_e,(C!==q.near||D!==q.far)&&(r.updateRenderState({depthNear:q.near,depthFar:q.far}),C=q.near,D=q.far),q.layers.mask=$.layers.mask|6,R.layers.mask=q.layers.mask&-5,N.layers.mask=q.layers.mask&-3;const we=$.parent,ae=q.cameras;G(q,we);for(let Ne=0;Ne<ae.length;Ne++)G(ae[Ne],we);q.projectionMatrix.copy(R.projectionMatrix),q.projectionMatrixInverse.copy(R.projectionMatrixInverse),T===null&&$.isPerspectiveCamera&&(T={camera:$,fov:$.fov,zoom:$.zoom}),K($,q,we)};function K($,ie,_e){_e===null?$.matrix.copy(ie.matrixWorld):($.matrix.copy(_e.matrixWorld),$.matrix.invert(),$.matrix.multiply(ie.matrixWorld)),$.matrix.decompose($.position,$.quaternion,$.scale),$.updateMatrixWorld(!0),$.projectionMatrix.copy(ie.projectionMatrix),$.projectionMatrixInverse.copy(ie.projectionMatrixInverse),$.isPerspectiveCamera&&($.fov=Da*2*Math.atan(1/$.projectionMatrix.elements[5]),$.zoom=1)}this.getCamera=function(){return q},this.getFoveation=function(){if(!(u===null&&p===null))return l},this.setFoveation=function($){l=$,u!==null&&(u.fixedFoveation=$),p!==null&&p.fixedFoveation!==void 0&&(p.fixedFoveation=$)},this.hasDepthSensing=function(){return _.texture!==null},this.getDepthSensingMesh=function(){return _.getMesh(q)},this.getCameraTexture=function($){return c[$]};let j=null;function ce($,ie){if(f=ie.getViewerPose(o||a),m=ie,f!==null){const _e=f.views;p!==null&&(e.setRenderTargetFramebuffer(M,p.framebuffer),e.setRenderTarget(M));let we=!1;_e.length!==q.cameras.length&&(q.cameras.length=0,we=!0);for(let ye=0;ye<_e.length;ye++){const He=_e[ye];let Xe=null;if(p!==null)Xe=p.getViewport(He);else{const Tt=h.getViewSubImage(u,He);Xe=Tt.viewport,ye===0&&(e.setRenderTargetTextures(M,Tt.colorTexture,Tt.depthStencilTexture),e.setRenderTarget(M))}let Ve=z[ye];Ve===void 0&&(Ve=new gn,Ve.layers.enable(ye),Ve.viewport=new wt,z[ye]=Ve),Ve.matrix.fromArray(He.transform.matrix),Ve.matrix.decompose(Ve.position,Ve.quaternion,Ve.scale),Ve.projectionMatrix.fromArray(He.projectionMatrix),Ve.projectionMatrixInverse.copy(Ve.projectionMatrix).invert(),Ve.viewport.set(Xe.x,Xe.y,Xe.width,Xe.height),ye===0&&(q.matrix.copy(Ve.matrix),q.matrix.decompose(q.position,q.quaternion,q.scale)),we===!0&&q.cameras.push(Ve)}const ae=r.enabledFeatures;if(ae&&ae.includes("depth-sensing")&&r.depthUsage=="gpu-optimized"&&x){h=n.getBinding();const ye=h.getDepthInformation(_e[0]);ye&&ye.isValid&&ye.texture&&_.init(ye,r.renderState)}if(ae&&ae.includes("camera-access")&&x){e.state.unbindTexture(),h=n.getBinding();for(let ye=0;ye<_e.length;ye++){const He=_e[ye].camera;if(He){let Xe=c[He];Xe||(Xe=new ac,c[He]=Xe);const Ve=h.getCameraImage(He);Xe.sourceTexture=Ve}}}}for(let _e=0;_e<A.length;_e++){const we=E[_e],ae=A[_e];we!==null&&ae!==void 0&&ae.update(we,ie,o||a)}j&&j($,ie),ie.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:ie}),m=null}const ve=new dc;ve.setAnimationLoop(ce),this.setAnimationLoop=function($){j=$},this.dispose=function(){}}}const v0=new ft,Mc=new ke;Mc.set(-1,0,0,0,1,0,0,0,1);function x0(i,e){function t(_,c){_.matrixAutoUpdate===!0&&_.updateMatrix(),c.value.copy(_.matrix)}function n(_,c){c.color.getRGB(_.fogColor.value,oc(i)),c.isFog?(_.fogNear.value=c.near,_.fogFar.value=c.far):c.isFogExp2&&(_.fogDensity.value=c.density)}function r(_,c,g,S,M){c.isNodeMaterial?c.uniformsNeedUpdate=!1:c.isMeshBasicMaterial?s(_,c):c.isMeshLambertMaterial?(s(_,c),c.envMap&&(_.envMapIntensity.value=c.envMapIntensity)):c.isMeshToonMaterial?(s(_,c),h(_,c)):c.isMeshPhongMaterial?(s(_,c),f(_,c),c.envMap&&(_.envMapIntensity.value=c.envMapIntensity)):c.isMeshStandardMaterial?(s(_,c),u(_,c),c.isMeshPhysicalMaterial&&p(_,c,M)):c.isMeshMatcapMaterial?(s(_,c),m(_,c)):c.isMeshDepthMaterial?s(_,c):c.isMeshDistanceMaterial?(s(_,c),x(_,c)):c.isMeshNormalMaterial?s(_,c):c.isLineBasicMaterial?(a(_,c),c.isLineDashedMaterial&&d(_,c)):c.isPointsMaterial?l(_,c,g,S):c.isSpriteMaterial?o(_,c):c.isShadowMaterial?(_.color.value.copy(c.color),_.opacity.value=c.opacity):c.isShaderMaterial&&(c.uniformsNeedUpdate=!1)}function s(_,c){_.opacity.value=c.opacity,c.color&&_.diffuse.value.copy(c.color),c.emissive&&_.emissive.value.copy(c.emissive).multiplyScalar(c.emissiveIntensity),c.map&&(_.map.value=c.map,t(c.map,_.mapTransform)),c.alphaMap&&(_.alphaMap.value=c.alphaMap,t(c.alphaMap,_.alphaMapTransform)),c.bumpMap&&(_.bumpMap.value=c.bumpMap,t(c.bumpMap,_.bumpMapTransform),_.bumpScale.value=c.bumpScale,c.side===Zt&&(_.bumpScale.value*=-1)),c.normalMap&&(_.normalMap.value=c.normalMap,t(c.normalMap,_.normalMapTransform),_.normalScale.value.copy(c.normalScale),c.side===Zt&&_.normalScale.value.negate()),c.displacementMap&&(_.displacementMap.value=c.displacementMap,t(c.displacementMap,_.displacementMapTransform),_.displacementScale.value=c.displacementScale,_.displacementBias.value=c.displacementBias),c.emissiveMap&&(_.emissiveMap.value=c.emissiveMap,t(c.emissiveMap,_.emissiveMapTransform)),c.specularMap&&(_.specularMap.value=c.specularMap,t(c.specularMap,_.specularMapTransform)),c.alphaTest>0&&(_.alphaTest.value=c.alphaTest);const g=e.get(c),S=g.envMap,M=g.envMapRotation;S&&(_.envMap.value=S,_.envMapRotation.value.setFromMatrix4(v0.makeRotationFromEuler(M)).transpose(),S.isCubeTexture&&S.isRenderTargetTexture===!1&&_.envMapRotation.value.premultiply(Mc),_.reflectivity.value=c.reflectivity,_.ior.value=c.ior,_.refractionRatio.value=c.refractionRatio),c.lightMap&&(_.lightMap.value=c.lightMap,_.lightMapIntensity.value=c.lightMapIntensity,t(c.lightMap,_.lightMapTransform)),c.aoMap&&(_.aoMap.value=c.aoMap,_.aoMapIntensity.value=c.aoMapIntensity,t(c.aoMap,_.aoMapTransform))}function a(_,c){_.diffuse.value.copy(c.color),_.opacity.value=c.opacity,c.map&&(_.map.value=c.map,t(c.map,_.mapTransform))}function d(_,c){_.dashSize.value=c.dashSize,_.totalSize.value=c.dashSize+c.gapSize,_.scale.value=c.scale}function l(_,c,g,S){_.diffuse.value.copy(c.color),_.opacity.value=c.opacity,_.size.value=c.size*g,_.scale.value=S*.5,c.map&&(_.map.value=c.map,t(c.map,_.uvTransform)),c.alphaMap&&(_.alphaMap.value=c.alphaMap,t(c.alphaMap,_.alphaMapTransform)),c.alphaTest>0&&(_.alphaTest.value=c.alphaTest)}function o(_,c){_.diffuse.value.copy(c.color),_.opacity.value=c.opacity,_.rotation.value=c.rotation,c.map&&(_.map.value=c.map,t(c.map,_.mapTransform)),c.alphaMap&&(_.alphaMap.value=c.alphaMap,t(c.alphaMap,_.alphaMapTransform)),c.alphaTest>0&&(_.alphaTest.value=c.alphaTest)}function f(_,c){_.specular.value.copy(c.specular),_.shininess.value=Math.max(c.shininess,1e-4)}function h(_,c){c.gradientMap&&(_.gradientMap.value=c.gradientMap)}function u(_,c){_.metalness.value=c.metalness,c.metalnessMap&&(_.metalnessMap.value=c.metalnessMap,t(c.metalnessMap,_.metalnessMapTransform)),_.roughness.value=c.roughness,c.roughnessMap&&(_.roughnessMap.value=c.roughnessMap,t(c.roughnessMap,_.roughnessMapTransform)),c.envMap&&(_.envMapIntensity.value=c.envMapIntensity)}function p(_,c,g){_.ior.value=c.ior,c.diffuseRoughness>0&&(_.diffuseRoughness.value=c.diffuseRoughness,c.diffuseRoughnessMap&&(_.diffuseRoughnessMap.value=c.diffuseRoughnessMap,t(c.diffuseRoughnessMap,_.diffuseRoughnessMapTransform))),c.sheen>0&&(_.sheenColor.value.copy(c.sheenColor).multiplyScalar(c.sheen),_.sheenRoughness.value=c.sheenRoughness,c.sheenColorMap&&(_.sheenColorMap.value=c.sheenColorMap,t(c.sheenColorMap,_.sheenColorMapTransform)),c.sheenRoughnessMap&&(_.sheenRoughnessMap.value=c.sheenRoughnessMap,t(c.sheenRoughnessMap,_.sheenRoughnessMapTransform))),c.clearcoat>0&&(_.clearcoat.value=c.clearcoat,_.clearcoatRoughness.value=c.clearcoatRoughness,c.clearcoatMap&&(_.clearcoatMap.value=c.clearcoatMap,t(c.clearcoatMap,_.clearcoatMapTransform)),c.clearcoatRoughnessMap&&(_.clearcoatRoughnessMap.value=c.clearcoatRoughnessMap,t(c.clearcoatRoughnessMap,_.clearcoatRoughnessMapTransform)),c.clearcoatNormalMap&&(_.clearcoatNormalMap.value=c.clearcoatNormalMap,t(c.clearcoatNormalMap,_.clearcoatNormalMapTransform),_.clearcoatNormalScale.value.copy(c.clearcoatNormalScale),c.side===Zt&&_.clearcoatNormalScale.value.negate())),c.dispersion>0&&(_.dispersion.value=c.dispersion),c.retroreflectivity>0&&(_.retroreflectivity.value=c.retroreflectivity),c.iridescence>0&&(_.iridescence.value=c.iridescence,_.iridescenceIOR.value=c.iridescenceIOR,_.iridescenceThicknessMinimum.value=c.iridescenceThicknessMinimum,_.iridescenceThicknessMaximum.value=c.iridescenceThicknessMaximum,c.iridescenceMap&&(_.iridescenceMap.value=c.iridescenceMap,t(c.iridescenceMap,_.iridescenceMapTransform)),c.iridescenceThicknessMap&&(_.iridescenceThicknessMap.value=c.iridescenceThicknessMap,t(c.iridescenceThicknessMap,_.iridescenceThicknessMapTransform))),c.transmission>0&&(_.transmission.value=c.transmission,_.transmissionSamplerMap.value=g.texture,_.transmissionSamplerSize.value.set(g.width,g.height),c.transmissionMap&&(_.transmissionMap.value=c.transmissionMap,t(c.transmissionMap,_.transmissionMapTransform)),_.thickness.value=c.thickness,c.thicknessMap&&(_.thicknessMap.value=c.thicknessMap,t(c.thicknessMap,_.thicknessMapTransform)),_.attenuationDistance.value=c.attenuationDistance,_.attenuationColor.value.copy(c.attenuationColor)),c.anisotropy>0&&(_.anisotropyVector.value.set(c.anisotropy*Math.cos(c.anisotropyRotation),c.anisotropy*Math.sin(c.anisotropyRotation)),c.anisotropyMap&&(_.anisotropyMap.value=c.anisotropyMap,t(c.anisotropyMap,_.anisotropyMapTransform))),_.specularIntensity.value=c.specularIntensity,_.specularColor.value.copy(c.specularColor),c.specularColorMap&&(_.specularColorMap.value=c.specularColorMap,t(c.specularColorMap,_.specularColorMapTransform)),c.specularIntensityMap&&(_.specularIntensityMap.value=c.specularIntensityMap,t(c.specularIntensityMap,_.specularIntensityMapTransform))}function m(_,c){c.matcap&&(_.matcap.value=c.matcap)}function x(_,c){const g=e.get(c).light;_.referencePosition.value.setFromMatrixPosition(g.matrixWorld),_.nearDistance.value=g.shadow.camera.near,_.farDistance.value=g.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:r}}function M0(i,e,t,n){let r={},s={};function a(g,S){const M=S.program;n.uniformBlockBinding(g,M,r[g.id])}function d(g,S){let M=r[g.id];M===void 0&&(m(g),M=l(g),r[g.id]=M,g.addEventListener("dispose",_));const A=S.program;n.updateUBOMapping(g,A);const E=e.render.frame;s[g.id]!==E&&(o(g),s[g.id]=E)}function l(g){const S=i.createBuffer(),M=g.__size,A=g.usage;return i.bindBuffer(i.UNIFORM_BUFFER,S),i.bufferData(i.UNIFORM_BUFFER,M,A),i.bindBuffer(i.UNIFORM_BUFFER,null),S}function o(g){const S=r[g.id],M=g.uniforms,A=g.__cache;i.bindBuffer(i.UNIFORM_BUFFER,S);for(let E=0,v=M.length;E<v;E++){const y=M[E];if(Array.isArray(y))for(let T=0,R=y.length;T<R;T++)f(y[T],E,T,A);else f(y,E,0,A)}i.bindBuffer(i.UNIFORM_BUFFER,null)}function f(g,S,M,A){if(u(g,S,M,A)===!0){const E=g.__offset,v=g.value;if(Array.isArray(v)){let y=0;for(let T=0;T<v.length;T++){const R=v[T],N=x(R,!0);h(R,g.__data,y),y+=N.storage/Float32Array.BYTES_PER_ELEMENT}}else h(v,g.__data,0);i.bufferSubData(i.UNIFORM_BUFFER,E,g.__data)}}function h(g,S,M){typeof g=="number"||typeof g=="boolean"?S[M]=g:g.isMatrix3?(S[M]=g.elements[0],S[M+1]=g.elements[1],S[M+2]=g.elements[2],S[M+3]=0,S[M+4]=g.elements[3],S[M+5]=g.elements[4],S[M+6]=g.elements[5],S[M+7]=0,S[M+8]=g.elements[6],S[M+9]=g.elements[7],S[M+10]=g.elements[8],S[M+11]=0):ArrayBuffer.isView(g)?S.set(g.subarray(0,S.length-M),M):g.toArray(S,M)}function u(g,S,M,A){const E=g.value,v=S+"_"+M;if(Array.isArray(E)){A[v]===void 0&&(A[v]=[]);const y=A[v];let T=!1;for(let R=0;R<E.length;R++)p(E[R],y,R)===!0&&(T=!0);return T}return p(E,A,v)}function p(g,S,M){if(S[M]===void 0)return typeof g=="number"||typeof g=="boolean"?S[M]=g:ArrayBuffer.isView(g)?S[M]=g.slice():S[M]=g.clone(),!0;{const A=S[M];if(typeof g=="number"||typeof g=="boolean"){if(A!==g)return S[M]=g,!0}else{if(ArrayBuffer.isView(g))return!0;if(A.equals(g)===!1)return A.copy(g),!0}}return!1}function m(g){const S=g.uniforms;let M=0;const A=16;for(let v=0,y=S.length;v<y;v++){const T=Array.isArray(S[v])?S[v]:[S[v]];for(let R=0,N=T.length;R<N;R++){const z=T[R],q=Array.isArray(z.value)?z.value:[z.value],C=Array.isArray(S[v])||Array.isArray(z.value);let D=M;for(let k=0,Q=q.length;k<Q;k++){const G=q[k],K=x(G,C),j=M%A,ce=j%K.boundary,ve=j+ce;M+=ce,ve!==0&&A-ve<K.storage&&(M+=A-ve),k===0&&(D=M),M+=K.storage}const O=z.type==="int"?Int32Array:z.type==="uint"?Uint32Array:Float32Array;z.__data=new O((M-D)/Float32Array.BYTES_PER_ELEMENT),z.__offset=D}}const E=M%A;return E>0&&(M+=A-E),g.__size=M,g.__cache={},this}function x(g,S){const M={boundary:0,storage:0};return typeof g=="number"||typeof g=="boolean"?(M.boundary=4,M.storage=4):g.isVector2?(M.boundary=8,M.storage=8):g.isVector3||g.isColor?(M.boundary=16,M.storage=12):g.isVector4?(M.boundary=16,M.storage=16):g.isMatrix3?(M.boundary=16,M.storage=48):g.isMatrix4?(M.boundary=16,M.storage=64):g.isTexture?Fe("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(g)?(M.boundary=16,M.storage=g.byteLength):Fe("WebGLRenderer: Unsupported uniform value type.",g),S===!0&&(M.boundary=16,M.storage=Math.ceil(M.storage/16)*16),M}function _(g){const S=g.target;S.removeEventListener("dispose",_),i.deleteBuffer(r[S.id]),delete r[S.id],delete s[S.id]}function c(){for(const g in r)i.deleteBuffer(r[g]);r={},s={}}return{bind:a,update:d,dispose:c}}const S0=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let mn=null;function y0(){return mn===null&&(mn=new fu(S0,16,16,oi,wn),mn.name="DFG_LUT",mn.minFilter=$t,mn.magFilter=$t,mn.wrapS=Nn,mn.wrapT=Nn,mn.generateMipmaps=!1,mn.needsUpdate=!0),mn}class b0{constructor(e={}){const{canvas:t=Bd(),context:n=null,depth:r=!0,stencil:s=!1,alpha:a=!1,antialias:d=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:o=!1,powerPreference:f="default",failIfMajorPerformanceCaveat:h=!1,reversedDepthBuffer:u=!1,outputBufferType:p=en}=e;this.isWebGLRenderer=!0;let m;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");m=n.getContextAttributes().alpha}else m=a;const x=p,_=new Set([qa,Xa,Wa]),c=new Set([en,En,nr,Pi,Ha,Va]),g=new Uint32Array(4),S=new Int32Array(4),M={textures:[],min:[],max:[],resolution:[]};let A=null,E=null;const v=[],y=[];let T=null;this.domElement=t,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Un,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const R=this;let N=!1,z=null,q=null,C=null,D=null;this._outputColorSpace=jt;let O=0,k=0,Q=null,G=-1,K=null;const j=new wt,ce=new wt;let ve=null;const $=new We(0);let ie=0,_e=t.width,we=t.height,ae=1,Ne=null,ot=null;const ye=new wt(0,0,_e,we),He=new wt(0,0,_e,we);let Xe=!1;const Ve=new rr,Tt=new Ja;let lt=!1,Je=!1;const Qe=new ft,At=new F,bt=new wt,Ht={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let _t=!1;function Vt(){return Q===null?ae:1}let B=n;function St(w,U){return t.getContext(w,U)}let ct,dt,he,yt,De,Ue,P,b,V,re,ne,oe,L,Z,ee,fe,I,te,J,ue,le,de,Ce;try{const w={alpha:!0,depth:r,stencil:s,antialias:d,premultipliedAlpha:l,preserveDrawingBuffer:o,powerPreference:f,failIfMajorPerformanceCaveat:h};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${ka}`),t.addEventListener("webglcontextlost",be,!1),t.addEventListener("webglcontextrestored",Oe,!1),t.addEventListener("webglcontextcreationerror",ge,!1),B===null){const U="webgl2";if(B=St(U,w),B===null)throw St(U)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}Le()}catch(w){throw t.removeEventListener("webglcontextlost",be,!1),t.removeEventListener("webglcontextrestored",Oe,!1),t.removeEventListener("webglcontextcreationerror",ge,!1),nt("WebGLRenderer: "+w.message),w}function Le(){ct=new Tp(B),ct.init(),le=new h0(B,ct),dt=new mp(B,ct,e,le),he=new u0(B,ct),dt.reversedDepthBuffer&&u&&he.buffers.depth.setReversed(!0),q=B.createFramebuffer(),C=B.createFramebuffer(),D=B.createFramebuffer(),yt=new Cp(B),De=new Jm,Ue=new f0(B,ct,he,De,dt,le,yt),P=new wp(R),b=new Pu(B),de=new hp(B,b),V=new Ap(B,b,yt,de),re=new Lp(B,V,b,de,yt),te=new Pp(B,dt,Ue),ee=new gp(De),ne=new Km(R,P,ct,dt,de,ee),oe=new x0(R,De),L=new jm,Z=new s0(ct),I=new fp(R,P,he,re,m,l),fe=new d0(R,re,dt),Ce=new M0(B,yt,dt,he),J=new pp(B,ct,yt),ue=new Rp(B,ct,yt),yt.programs=ne.programs,R.capabilities=dt,R.extensions=ct,R.properties=De,R.renderLists=L,R.shadowMap=fe,R.state=he,R.info=yt}x!==en&&(T=new Ip(x,t.width,t.height,d,r,s));const se=new _0(R,B);this.xr=se,this.getContext=function(){return B},this.getContextAttributes=function(){return B.getContextAttributes()},this.forceContextLoss=function(){const w=ct.get("WEBGL_lose_context");w&&w.loseContext()},this.forceContextRestore=function(){const w=ct.get("WEBGL_lose_context");w&&w.restoreContext()},this.getPixelRatio=function(){return ae},this.setPixelRatio=function(w){w!==void 0&&(ae=w,this.setSize(_e,we,!1))},this.getSize=function(w){return w.set(_e,we)},this.setSize=function(w,U,Y=!0){if(se.isPresenting){Fe("WebGLRenderer: Can't change size while VR device is presenting.");return}_e=w,we=U,t.width=Math.floor(w*ae),t.height=Math.floor(U*ae),Y===!0&&(t.style.width=w+"px",t.style.height=U+"px"),T!==null&&T.setSize(t.width,t.height),this.setViewport(0,0,w,U)},this.getDrawingBufferSize=function(w){return w.set(_e*ae,we*ae).floor()},this.setDrawingBufferSize=function(w,U,Y){_e=w,we=U,ae=Y,t.width=Math.floor(w*Y),t.height=Math.floor(U*Y),this.setViewport(0,0,w,U)},this.setEffects=function(w){if(x===en){nt("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(w){for(let U=0;U<w.length;U++)if(w[U].isOutputPass===!0){Fe("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}T.setEffects(w||[])},this.getCurrentViewport=function(w){return w.copy(j)},this.getViewport=function(w){return w.copy(ye)},this.setViewport=function(w,U,Y,W){w.isVector4?ye.set(w.x,w.y,w.z,w.w):ye.set(w,U,Y,W),he.viewport(j.copy(ye).multiplyScalar(Vt()).round())},this.getScissor=function(w){return w.copy(He)},this.setScissor=function(w,U,Y,W){w.isVector4?He.set(w.x,w.y,w.z,w.w):He.set(w,U,Y,W),he.scissor(ce.copy(He).multiplyScalar(Vt()).round())},this.getScissorTest=function(){return Xe},this.setScissorTest=function(w){he.setScissorTest(Xe=w)},this.setOpaqueSort=function(w){Ne=w},this.setTransparentSort=function(w){ot=w},this.getClearColor=function(w){return w.copy(I.getClearColor())},this.setClearColor=function(){I.setClearColor(...arguments)},this.getClearAlpha=function(){return I.getClearAlpha()},this.setClearAlpha=function(){I.setClearAlpha(...arguments)},this.clear=function(w=!0,U=!0,Y=!0){let W=0;if(w){let X=!1;if(Q!==null){const me=Q.texture.format;X=_.has(me)}if(X){const me=Q.texture.type,Te=c.has(me),pe=I.getClearColor(),Me=I.getClearAlpha(),Pe=pe.r,ze=pe.g,Ye=pe.b;Te?(g[0]=Pe,g[1]=ze,g[2]=Ye,g[3]=Me,B.clearBufferuiv(B.COLOR,0,g)):(S[0]=Pe,S[1]=ze,S[2]=Ye,S[3]=Me,B.clearBufferiv(B.COLOR,0,S))}else W|=B.COLOR_BUFFER_BIT}U&&(W|=B.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),Y&&(W|=B.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),W!==0&&B.clear(W)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(w){w.setRenderer(this),z=w},this.dispose=function(){t.removeEventListener("webglcontextlost",be,!1),t.removeEventListener("webglcontextrestored",Oe,!1),t.removeEventListener("webglcontextcreationerror",ge,!1),I.dispose(),L.dispose(),Z.dispose(),Ue.dispose(),De.dispose(),P.dispose(),re.dispose(),V.dispose(),de.dispose(),Ce.dispose(),ne.dispose(),se.dispose(),se.removeEventListener("sessionstart",Ee),se.removeEventListener("sessionend",Ie),Se.stop()};function be(w){w.preventDefault(),_o("WebGLRenderer: Context Lost."),N=!0}function Oe(){_o("WebGLRenderer: Context Restored."),N=!1;const w=yt.autoReset,U=fe.enabled,Y=fe.autoUpdate,W=fe.needsUpdate,X=fe.type;Le(),yt.autoReset=w,fe.enabled=U,fe.autoUpdate=Y,fe.needsUpdate=W,fe.type=X}function ge(w){nt("WebGLRenderer: A WebGL context could not be created. Reason: ",w.statusMessage)}function et(w){const U=w.target;U.removeEventListener("dispose",et),Et(U)}function Et(w){on(w),De.remove(w)}function on(w){const U=De.get(w).programs;U!==void 0&&(U.forEach(function(Y){ne.releaseProgram(Y)}),w.isShaderMaterial&&ne.releaseShaderCache(w))}this.renderBufferDirect=function(w,U,Y,W,X,me){U===null&&(U=Ht);const Te=X.isMesh&&X.matrixWorld.determinantAffine()<0,pe=Cc(w,U,Y,W,X);he.setMaterial(W,Te);let Me=Y.index,Pe=1;if(W.wireframe===!0){if(Me=V.getWireframeAttribute(Y),Me===void 0)return;Pe=2}const ze=Y.drawRange,Ye=Y.attributes.position;let Ae=ze.start*Pe,$e=(ze.start+ze.count)*Pe;me!==null&&(Ae=Math.max(Ae,me.start*Pe),$e=Math.min($e,(me.start+me.count)*Pe)),Me!==null?(Ae=Math.max(Ae,0),$e=Math.min($e,Me.count)):Ye!=null&&(Ae=Math.max(Ae,0),$e=Math.min($e,Ye.count));const Rt=$e-Ae;if(Rt<0||Rt===1/0)return;de.setup(X,W,pe,Y,Me);let ht,ut=J;if(Me!==null&&(ht=b.get(Me),ut=ue,ut.setIndex(ht)),X.isMesh)W.wireframe===!0?(he.setLineWidth(W.wireframeLinewidth*Vt()),ut.setMode(B.LINES)):ut.setMode(B.TRIANGLES);else if(X.isLine){let Bt=W.linewidth;Bt===void 0&&(Bt=1),he.setLineWidth(Bt*Vt()),X.isLineSegments?ut.setMode(B.LINES):X.isLineLoop?ut.setMode(B.LINE_LOOP):ut.setMode(B.LINE_STRIP)}else X.isPoints?ut.setMode(B.POINTS):X.isSprite&&ut.setMode(B.TRIANGLES);if(X.isBatchedMesh)if(ct.get("WEBGL_multi_draw"))ut.renderMultiDraw(X._multiDrawStarts,X._multiDrawCounts,X._multiDrawCount);else{const Bt=X._multiDrawStarts,Re=X._multiDrawCounts,Wt=X._multiDrawCount,it=Me?b.get(Me).bytesPerElement:1,Qn=De.get(W).currentProgram.getUniforms();for(let zt=0;zt<Wt;zt++)Qn.setValue(B,"_gl_DrawID",zt),ut.render(Bt[zt]/it,Re[zt])}else if(X.isInstancedMesh)ut.renderInstances(Ae,Rt,X.count);else if(Y.isInstancedBufferGeometry){const Bt=Y._maxInstanceCount!==void 0?Y._maxInstanceCount:1/0,Re=Math.min(Y.instanceCount,Bt);ut.renderInstances(Ae,Rt,Re)}else ut.render(Ae,Rt)};function mt(w,U,Y,W){z!==null&&w.isNodeMaterial&&z.setObject(W,w),lt===!0&&ee.setState(w,Y,!1),w.transparent===!0&&w.side===vn&&w.forceSinglePass===!1?(w.side=Zt,w.needsUpdate=!0,vt(w,U,W),w.side=ai,w.needsUpdate=!0,vt(w,U,W),w.side=vn):vt(w,U,W)}this.compile=function(w,U,Y=null){Y===null&&(Y=w),z!==null&&z.renderStart(w,U,Y),E=Z.get(Y),E.init(U),y.push(E),Y.traverseVisible(function(X){X.isLight&&X.layers.test(U.layers)&&(E.pushLight(X),X.castShadow&&E.pushShadow(X))}),w!==Y&&w.traverseVisible(function(X){X.isLight&&X.layers.test(U.layers)&&(E.pushLight(X),X.castShadow&&E.pushShadow(X))}),E.setupLights(),z!==null&&z.updateLights(E.state.lightsArray),Je=this.localClippingEnabled,lt=ee.init(this.clippingPlanes,Je),lt===!0&&ee.setGlobalState(this.clippingPlanes,U),z!==null&&fe.render(E.state.shadowsArray,Y,U);const W=new Set;return w.traverse(function(X){if(!(X.isMesh||X.isPoints||X.isLine||X.isSprite))return;const me=X.material;if(me)if(Array.isArray(me))for(let Te=0;Te<me.length;Te++){const pe=me[Te];mt(pe,Y,U,X),W.add(pe)}else mt(me,Y,U,X),W.add(me)}),E=y.pop(),z!==null&&z.renderEnd(),W},this.compileAsync=function(w,U,Y=null){const W=this.compile(w,U,Y);return new Promise(X=>{function me(){if(W.forEach(function(Te){const Me=De.get(Te).currentProgram;(Me===void 0||Me.isReady())&&W.delete(Te)}),W.size===0){X(w);return}setTimeout(me,10)}ct.get("KHR_parallel_shader_compile")!==null?me():setTimeout(me,10)})};let di=null;function H(w){di&&di(w)}function Ee(){Se.stop()}function Ie(){Se.start()}const Se=new dc;Se.setAnimationLoop(H),typeof self<"u"&&Se.setContext(self),this.setAnimationLoop=function(w){di=w,se.setAnimationLoop(w),w===null?Se.stop():Se.start()},se.addEventListener("sessionstart",Ee),se.addEventListener("sessionend",Ie),this.render=function(w,U){if(U!==void 0&&U.isCamera!==!0){nt("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(N===!0)return;z!==null&&z.renderStart(w,U);const Y=se.enabled===!0&&se.isPresenting===!0,W=T!==null&&(Q===null||Y)&&T.begin(R,Q);if(w.matrixWorldAutoUpdate===!0&&w.updateMatrixWorld(),U.parent===null&&U.matrixWorldAutoUpdate===!0&&U.updateMatrixWorld(),se.enabled===!0&&se.isPresenting===!0&&(T===null||T.isCompositing()===!1)&&(se.cameraAutoUpdate===!0&&se.updateCamera(U),U=se.getCamera()),w.isScene===!0&&w.onBeforeRender(R,w,U,Q),E=Z.get(w,y.length),E.init(U),E.state.textureUnits=Ue.getTextureUnits(),y.push(E),Qe.multiplyMatrices(U.projectionMatrix,U.matrixWorldInverse),U.isArrayCamera?Tt.setFromArrayCamera(U):Ve.setFromProjectionMatrix(Qe,hn,U.reversedDepth),Je=this.localClippingEnabled,lt=ee.init(this.clippingPlanes,Je),A=L.get(w,v.length),A.init(),v.push(A),this.info.render.frame++,se.enabled===!0&&se.isPresenting===!0){const Te=R.xr.getDepthSensingMesh();Te!==null&&tt(Te,U,-1/0,R.sortObjects)}tt(w,U,0,R.sortObjects),A.finish(),z!==null&&z.updateLights(E.state.lightsArray),R.sortObjects===!0&&A.sort(Ne,ot),_t=se.enabled===!1||se.isPresenting===!1||se.hasDepthSensing()===!1,_t&&I.addToRenderList(A,w),this.info.autoReset===!0&&this.info.reset(),lt===!0&&ee.beginShadows();const X=E.state.shadowsArray;if(fe.render(X,w,U),lt===!0&&ee.endShadows(),(W&&T.hasRenderPass())===!1){const Te=A.opaque,pe=A.transmissive;if(E.setupLights(),U.isArrayCamera){const Me=U.cameras;if(pe.length>0)for(let Pe=0,ze=Me.length;Pe<ze;Pe++){const Ye=Me[Pe];Bi(Te,pe,w,Ye)}_t&&I.render(w);for(let Pe=0,ze=Me.length;Pe<ze;Pe++){const Ye=Me[Pe];ln(A,w,Ye,Ye.viewport)}}else pe.length>0&&Bi(Te,pe,w,U),_t&&I.render(w),ln(A,w,U)}Q!==null&&k===0&&(Ue.updateMultisampleRenderTarget(Q),Ue.updateRenderTargetMipmap(Q)),W&&T.end(R),w.isScene===!0&&w.onAfterRender(R,w,U),de.resetDefaultState(),G=-1,K=null,y.pop(),y.length>0?(E=y[y.length-1],Ue.setTextureUnits(E.state.textureUnits),lt===!0&&ee.setGlobalState(R.clippingPlanes,E.state.camera)):E=null,v.pop(),v.length>0?A=v[v.length-1]:A=null,z!==null&&z.renderEnd()};function tt(w,U,Y,W){if(w.visible===!1)return;if(w.layers.test(U.layers)){if(w.isGroup)Y=w.renderOrder;else if(w.isLOD)w.autoUpdate===!0&&w.update(U);else if(w.isLight)E.pushLight(w),w.castShadow&&E.pushShadow(w);else if(w.isSprite){const Te=U.isArrayCamera?Tt:Ve;if(!w.frustumCulled||w.intersectsFrustum(Te)){W&&bt.setFromMatrixPosition(w.matrixWorld).applyMatrix4(Qe);const pe=re.update(w),Me=w.material;Me.visible&&A.push(w,pe,Me,Y,bt.z,null,U)}}else if(w.isMesh||w.isLine||w.isPoints){const Te=U.isArrayCamera?Tt:Ve;if(!w.frustumCulled||w.intersectsFrustum(Te)){const pe=re.update(w),Me=w.material;if(W&&(w.boundingSphere!==void 0?(w.boundingSphere===null&&w.computeBoundingSphere(),bt.copy(w.boundingSphere.center)):(pe.boundingSphere===null&&pe.computeBoundingSphere(),bt.copy(pe.boundingSphere.center)),bt.applyMatrix4(w.matrixWorld).applyMatrix4(Qe)),Array.isArray(Me)){const Pe=pe.groups;for(let ze=0,Ye=Pe.length;ze<Ye;ze++){const Ae=Pe[ze],$e=Me[Ae.materialIndex];$e&&$e.visible&&A.push(w,pe,$e,Y,bt.z,Ae,U)}}else Me.visible&&A.push(w,pe,Me,Y,bt.z,null,U)}}}const me=w.children;for(let Te=0,pe=me.length;Te<pe;Te++)tt(me[Te],U,Y,W)}function ln(w,U,Y,W){const{opaque:X,transmissive:me,transparent:Te}=w;E.setupLightsView(Y),lt===!0&&ee.setGlobalState(R.clippingPlanes,Y),W&&he.viewport(j.copy(W)),X.length>0&&Kn(X,U,Y),me.length>0&&Kn(me,U,Y),Te.length>0&&Kn(Te,U,Y),he.buffers.depth.setTest(!0),he.buffers.depth.setMask(!0),he.buffers.color.setMask(!0),he.setPolygonOffset(!1)}function Bi(w,U,Y,W){if((Y.isScene===!0?Y.overrideMaterial:null)!==null)return;if(E.state.transmissionRenderTarget[W.id]===void 0){const Ae=ct.has("EXT_color_buffer_half_float")||ct.has("EXT_color_buffer_float");E.state.transmissionRenderTarget[W.id]=new yn(1,1,{generateMipmaps:!0,type:Ae?wn:en,minFilter:Xn,samples:Math.max(4,dt.samples),stencilBuffer:s,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:Ke.workingColorSpace})}const me=E.state.transmissionRenderTarget[W.id],Te=W.viewport||j;me.setSize(Te.z*R.transmissionResolutionScale,Te.w*R.transmissionResolutionScale);const pe=R.getRenderTarget(),Me=R.getActiveCubeFace(),Pe=R.getActiveMipmapLevel();R.setRenderTarget(me),R.getClearColor($),ie=R.getClearAlpha(),ie<1&&R.setClearColor(16777215,.5),R.clear(),_t&&I.render(Y);const ze=R.toneMapping;R.toneMapping=Un;const Ye=W.viewport;if(W.viewport!==void 0&&(W.viewport=void 0),E.setupLightsView(W),lt===!0&&ee.setGlobalState(R.clippingPlanes,W),Kn(w,Y,W),Ue.updateMultisampleRenderTarget(me),Ue.updateRenderTargetMipmap(me),ct.has("WEBGL_multisampled_render_to_texture")===!1){let Ae=!1;for(let $e=0,Rt=U.length;$e<Rt;$e++){const ht=U[$e],{object:ut,geometry:Bt,material:Re,group:Wt}=ht;if(Re.side===vn&&ut.layers.test(W.layers)){const it=Re.side;Re.side=Zt,Re.needsUpdate=!0,zi(ut,Y,W,Bt,Re,Wt),Re.side=it,Re.needsUpdate=!0,Ae=!0}}Ae===!0&&(Ue.updateMultisampleRenderTarget(me),Ue.updateRenderTargetMipmap(me))}R.setRenderTarget(pe,Me,Pe),R.setClearColor($,ie),Ye!==void 0&&(W.viewport=Ye),R.toneMapping=ze}function Kn(w,U,Y){const W=U.isScene===!0?U.overrideMaterial:null;for(let X=0,me=w.length;X<me;X++){const Te=w[X],{object:pe,geometry:Me,group:Pe}=Te;let ze=Te.material;ze.allowOverride===!0&&W!==null&&(ze=W),pe.layers.test(Y.layers)&&zi(pe,U,Y,Me,ze,Pe)}}function zi(w,U,Y,W,X,me){z!==null&&X.isNodeMaterial&&z.setObject(w,X),w.onBeforeRender(R,U,Y,W,X,me),w.modelViewMatrix.multiplyMatrices(Y.matrixWorldInverse,w.matrixWorld),w.normalMatrix.getNormalMatrix(w.modelViewMatrix),X.onBeforeRender(R,U,Y,W,w,me),X.transparent===!0&&X.side===vn&&X.forceSinglePass===!1?(X.side=Zt,X.needsUpdate=!0,R.renderBufferDirect(Y,U,W,X,w,me),X.side=ai,X.needsUpdate=!0,R.renderBufferDirect(Y,U,W,X,w,me),X.side=vn):R.renderBufferDirect(Y,U,W,X,w,me),w.onAfterRender(R,U,Y,W,X,me)}function Jn(w){let U=0;for(const Y of w)Y.texture!==null&&U++;return U}function vt(w,U,Y){U.isScene!==!0&&(U=Ht);const W=De.get(w),X=E.state.lights,me=E.state.shadowsArray,Te=X.state.version,pe=ne.getParameters(w,X.state,me,U,Y,E.state.lightProbeGridArray),Me=ne.getProgramCacheKey(pe);let Pe=W.programs;W.environment=w.isMeshStandardMaterial||w.isMeshLambertMaterial||w.isMeshPhongMaterial?U.environment:null,W.fog=U.fog;const ze=w.isMeshStandardMaterial||w.isMeshLambertMaterial&&!w.envMap||w.isMeshPhongMaterial&&!w.envMap;W.envMap=P.get(w.envMap||W.environment,ze),W.envMapRotation=W.environment!==null&&w.envMap===null?U.environmentRotation:w.envMapRotation,Pe===void 0&&(w.addEventListener("dispose",et),Pe=new Map,W.programs=Pe,W.programVariants=new Map);let Ye=Pe.get(Me);if(Ye!==void 0){if(W.currentProgram===Ye&&W.lightsStateVersion===Te)return ro(w,pe),Ye}else pe.uniforms=ne.getUniforms(w),z!==null&&w.isNodeMaterial&&z.build(w,Y,pe),w.onBeforeCompile(pe,R),Ye=ne.acquireProgram(pe,Me),Pe.set(Me,Ye),W.uniforms=pe.uniforms;const Ae=W.uniforms;return(!w.isShaderMaterial&&!w.isRawShaderMaterial||w.clipping===!0)&&(Ae.clippingPlanes=ee.uniform),ro(w,pe),W.needsLights=Lc(w),W.lightsStateVersion=Te,W.needsLights&&(Ae.ambientLightColor.value=X.state.ambient,Ae.lightProbe.value=X.state.probe,Ae.sunLights.value=X.state.sun,Ae.sunLightShadows.value=X.state.sunShadow,Ae.directionalLights.value=X.state.directional,Ae.directionalLightShadows.value=X.state.directionalShadow,Ae.spotLights.value=X.state.spot,Ae.spotLightShadows.value=X.state.spotShadow,Ae.rectAreaLights.value=X.state.rectArea,Ae.ltc_1.value=X.state.rectAreaLTC1,Ae.ltc_2.value=X.state.rectAreaLTC2,Ae.pointLights.value=X.state.point,Ae.pointLightShadows.value=X.state.pointShadow,Ae.hemisphereLights.value=X.state.hemi,Ae.sunShadowMatrix.value=X.state.sunShadowMatrix,Ae.sunShadowCascade.value=X.state.sunShadowCascade,Ae.directionalShadowMatrix.value=X.state.directionalShadowMatrix,Ae.spotLightMatrix.value=X.state.spotLightMatrix,Ae.spotLightMap.value=X.state.spotLightMap,Ae.pointShadowMatrix.value=X.state.pointShadowMatrix),W.numLightProbeGrids=Jn(E.state.lightProbeGridArray),W.currentProgram=Ye,W.uniformsList=null,Ye}function Rc(w,U,Y,W,X){const me=De.get(w),Te=me.currentProgram.id+","+W+","+X;let pe=me.programVariants.get(Te);return pe===void 0?(pe=vt(w,U,Y),me.programVariants.set(Te,pe)):(me.currentProgram=pe,me.uniformsList=null,me.outputColorSpace=W,me.toneMapping=X),pe}function io(w){if(w.uniformsList===null){const U=w.currentProgram.getUniforms();w.uniformsList=Zr.seqWithValue(U.seq,w.uniforms)}return w.uniformsList}function ro(w,U){const Y=De.get(w);Y.outputColorSpace=U.outputColorSpace,Y.batching=U.batching,Y.batchingColor=U.batchingColor,Y.instancing=U.instancing,Y.instancingColor=U.instancingColor,Y.instancingMorph=U.instancingMorph,Y.skinning=U.skinning,Y.morphTargets=U.morphTargets,Y.morphNormals=U.morphNormals,Y.morphColors=U.morphColors,Y.morphTargetsCount=U.morphTargetsCount,Y.numClippingPlanes=U.numClippingPlanes,Y.numIntersection=U.numClipIntersection,Y.vertexAlphas=U.vertexAlphas,Y.vertexTangents=U.vertexTangents,Y.toneMapping=U.toneMapping}function Cc(w,U,Y,W,X){U.isScene!==!0&&(U=Ht),Ue.resetTextureUnits();const me=U.fog,Te=W.isMeshStandardMaterial||W.isMeshLambertMaterial||W.isMeshPhongMaterial?U.environment:null,pe=Q===null?R.outputColorSpace:Q.isXRRenderTarget===!0?Q.texture.colorSpace:Ke.workingColorSpace,Me=W.isMeshStandardMaterial||W.isMeshLambertMaterial&&!W.envMap||W.isMeshPhongMaterial&&!W.envMap,Pe=P.get(W.envMap||Te,Me),ze=W.vertexColors===!0&&!!Y.attributes.color&&Y.attributes.color.itemSize===4,Ye=!!Y.attributes.tangent&&(!!W.normalMap||W.anisotropy>0),Ae=!!Y.morphAttributes.position,$e=!!Y.morphAttributes.normal,Rt=!!Y.morphAttributes.color;let ht=Un;W.toneMapped&&(Q===null||Q.isXRRenderTarget===!0)&&(ht=R.toneMapping);const ut=Y.morphAttributes.position||Y.morphAttributes.normal||Y.morphAttributes.color,Bt=ut!==void 0?ut.length:0,Re=De.get(W),Wt=E.state.lights;if(lt===!0&&(Je===!0||w!==K)){const xt=w===K&&W.id===G;ee.setState(W,w,xt)}let it=!1,Qn=!1;W.version===Re.__version?Re.needsLights&&Re.lightsStateVersion!==Wt.state.version||X.isBatchedMesh&&Re.batching===!1||!X.isBatchedMesh&&Re.batching===!0||X.isBatchedMesh&&Re.batchingColor===!0&&X._colorsTexture===null||X.isBatchedMesh&&Re.batchingColor===!1&&X._colorsTexture!==null||X.isInstancedMesh&&Re.instancing===!1||!X.isInstancedMesh&&Re.instancing===!0||X.isSkinnedMesh&&Re.skinning===!1||!X.isSkinnedMesh&&Re.skinning===!0||X.isInstancedMesh&&Re.instancingColor===!0&&X.instanceColor===null||X.isInstancedMesh&&Re.instancingColor===!1&&X.instanceColor!==null||X.isInstancedMesh&&Re.instancingMorph===!0&&X.morphTexture===null||X.isInstancedMesh&&Re.instancingMorph===!1&&X.morphTexture!==null||Re.envMap!==Pe||W.fog===!0&&Re.fog!==me||Re.numClippingPlanes!==void 0&&(Re.numClippingPlanes!==ee.numPlanes||Re.numIntersection!==ee.numIntersection)||Re.vertexAlphas!==ze||Re.vertexTangents!==Ye||Re.morphTargets!==Ae||Re.morphNormals!==$e||Re.morphColors!==Rt||Re.morphTargetsCount!==Bt||Re.numLightProbeGrids!==Jn(E.state.lightProbeGridArray)?it=!0:(Re.outputColorSpace!==pe||Re.toneMapping!==ht)&&(Qn=!0):(it=!0,Re.__version=W.version);let zt=Re.currentProgram;(it===!0||Qn===!0)&&(zt=Qn===!0?Rc(W,U,X,pe,ht):vt(W,U,X),z&&W.isNodeMaterial&&z.onUpdateProgram(W,zt,Re));let dr=!1,Bn=!1,jn=!1;const je=zt.getUniforms(),Ut=Re.uniforms;if(he.useProgram(zt.program)&&(dr=!0,Bn=!0,jn=!0),W.id!==G&&(G=W.id,Bn=!0),dr||K!==w){he.buffers.depth.getReversed()&&w.reversedDepth!==!0&&(w._reversedDepth=!0,w.updateProjectionMatrix()),je.setValue(B,"projectionMatrix",w.projectionMatrix),je.setValue(B,"viewMatrix",w.matrixWorldInverse);const It=je.map.cameraPosition;It!==void 0&&It.setValue(B,At.setFromMatrixPosition(w.matrixWorld)),dt.logarithmicDepthBuffer&&je.setValue(B,"logDepthBufFC",2/(Math.log(w.far+1)/Math.LN2)),(W.isMeshPhongMaterial||W.isMeshToonMaterial||W.isMeshLambertMaterial||W.isMeshBasicMaterial||W.isMeshStandardMaterial||W.isShaderMaterial)&&je.setValue(B,"isOrthographic",w.isOrthographicCamera===!0),K!==w&&(K=w,Bn=!0,jn=!0)}if(Re.needsLights&&(Wt.state.sunShadowMap.length>0&&je.setValue(B,"sunShadowMap",Wt.state.sunShadowMap,Ue),Wt.state.directionalShadowMap.length>0&&je.setValue(B,"directionalShadowMap",Wt.state.directionalShadowMap,Ue),Wt.state.spotShadowMap.length>0&&je.setValue(B,"spotShadowMap",Wt.state.spotShadowMap,Ue),Wt.state.pointShadowMap.length>0&&je.setValue(B,"pointShadowMap",Wt.state.pointShadowMap,Ue)),X.isSkinnedMesh){je.setOptional(B,X,"bindMatrix"),je.setOptional(B,X,"bindMatrixInverse");const xt=X.skeleton;xt&&(xt.boneTexture===null&&xt.computeBoneTexture(),je.setValue(B,"boneTexture",xt.boneTexture,Ue))}X.isBatchedMesh&&(je.setOptional(B,X,"batchingTexture"),je.setValue(B,"batchingTexture",X._matricesTexture,Ue),je.setOptional(B,X,"batchingIdTexture"),je.setValue(B,"batchingIdTexture",X._indirectTexture,Ue),je.setOptional(B,X,"batchingColorTexture"),X._colorsTexture!==null&&je.setValue(B,"batchingColorTexture",X._colorsTexture,Ue));const cn=Y.morphAttributes;if((cn.position!==void 0||cn.normal!==void 0||cn.color!==void 0)&&te.update(X,Y,zt),(Bn||Re.receiveShadow!==X.receiveShadow)&&(Re.receiveShadow=X.receiveShadow,je.setValue(B,"receiveShadow",X.receiveShadow)),(W.isMeshStandardMaterial||W.isMeshLambertMaterial||W.isMeshPhongMaterial)&&W.envMap===null&&U.environment!==null&&(Ut.envMapIntensity.value=U.environmentIntensity),Ut.dfgLUT!==void 0&&(Ut.dfgLUT.value=y0()),Bn){if(je.setValue(B,"toneMappingExposure",R.toneMappingExposure),Re.needsLights&&Pc(Ut,jn),me&&W.fog===!0&&oe.refreshFogUniforms(Ut,me),oe.refreshMaterialUniforms(Ut,W,ae,we,E.state.transmissionRenderTarget[w.id]),Re.needsLights&&Re.numLightProbeGrids>0){const xt=M;let It=0;for(const Tn of E.state.lightProbeGridArray)Tn.texture!==null&&(xt.textures[It]=Tn.texture,xt.min[It]=Tn.boundingBox.min,xt.max[It]=Tn.boundingBox.max,xt.resolution[It]=Tn.resolution,It++);for(const Tn in xt)xt[Tn].length=It;Ut.probesSH.value=xt.textures,Ut.probesMin.value=xt.min,Ut.probesMax.value=xt.max,Ut.probesResolution.value=xt.resolution}Zr.upload(B,io(Re),Ut,Ue)}if(W.isShaderMaterial&&W.uniformsNeedUpdate===!0&&(Zr.upload(B,io(Re),Ut,Ue),W.uniformsNeedUpdate=!1),W.isSpriteMaterial&&je.setValue(B,"center",X.center),je.setValue(B,"modelViewMatrix",X.modelViewMatrix),je.setValue(B,"normalMatrix",X.normalMatrix),je.setValue(B,"modelMatrix",X.matrixWorld),W.uniformsGroups!==void 0){const xt=W.uniformsGroups;for(let It=0,Tn=xt.length;It<Tn;It++){const ao=xt[It];Ce.update(ao,zt),Ce.bind(ao,zt)}}return zt}function Pc(w,U){w.ambientLightColor.needsUpdate=U,w.lightProbe.needsUpdate=U,w.sunLights.needsUpdate=U,w.sunLightShadows.needsUpdate=U,w.directionalLights.needsUpdate=U,w.directionalLightShadows.needsUpdate=U,w.pointLights.needsUpdate=U,w.pointLightShadows.needsUpdate=U,w.spotLights.needsUpdate=U,w.spotLightShadows.needsUpdate=U,w.rectAreaLights.needsUpdate=U,w.hemisphereLights.needsUpdate=U}function Lc(w){return w.isMeshLambertMaterial||w.isMeshToonMaterial||w.isMeshPhongMaterial||w.isMeshStandardMaterial||w.isShadowMaterial||w.isShaderMaterial&&w.lights===!0}this.getActiveCubeFace=function(){return O},this.getActiveMipmapLevel=function(){return k},this.getRenderTarget=function(){return Q},this.setRenderTargetTextures=function(w,U,Y){const W=De.get(w);W.__autoAllocateDepthBuffer=w.resolveDepthBuffer===!1,W.__autoAllocateDepthBuffer===!1&&(W.__useRenderToTexture=!1),De.get(w.texture).__webglTexture=U,De.get(w.depthTexture).__webglTexture=W.__autoAllocateDepthBuffer?void 0:Y,W.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(w,U){const Y=De.get(w);Y.__webglFramebuffer=U,Y.__useDefaultFramebuffer=U===void 0},this.setRenderTarget=function(w,U=0,Y=0){Q=w,O=U,k=Y;let W=null,X=!1,me=!1;if(w){const pe=De.get(w);if(pe.__useDefaultFramebuffer!==void 0){he.bindFramebuffer(B.FRAMEBUFFER,pe.__webglFramebuffer),j.copy(w.viewport),ce.copy(w.scissor),ve=w.scissorTest,he.viewport(j),he.scissor(ce),he.setScissorTest(ve),G=-1;return}else if(pe.__webglFramebuffer===void 0)Ue.setupRenderTarget(w);else if(pe.__hasExternalTextures)Ue.rebindTextures(w,De.get(w.texture).__webglTexture,De.get(w.depthTexture).__webglTexture);else if(w.depthBuffer){const ze=w.depthTexture;if(pe.__boundDepthTexture!==ze){if(ze!==null&&De.has(ze)&&(w.width!==ze.image.width||w.height!==ze.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");Ue.setupDepthRenderbuffer(w)}}const Me=w.texture;(Me.isData3DTexture||Me.isDataArrayTexture||Me.isCompressedArrayTexture)&&(me=!0);const Pe=De.get(w).__webglFramebuffer;w.isWebGLCubeRenderTarget?(Array.isArray(Pe[U])?W=Pe[U][Y]:W=Pe[U],X=!0):w.samples>0&&Ue.useMultisampledRTT(w)===!1?W=De.get(w).__webglMultisampledFramebuffer:Array.isArray(Pe)?W=Pe[Y]:W=Pe,j.copy(w.viewport),ce.copy(w.scissor),ve=w.scissorTest}else j.copy(ye).multiplyScalar(ae).floor(),ce.copy(He).multiplyScalar(ae).floor(),ve=Xe;if(Y!==0&&(W=q),he.bindFramebuffer(B.FRAMEBUFFER,W)&&he.drawBuffers(w,W),he.viewport(j),he.scissor(ce),he.setScissorTest(ve),X){const pe=De.get(w.texture);B.framebufferTexture2D(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_CUBE_MAP_POSITIVE_X+U,pe.__webglTexture,Y)}else if(me){const pe=U;for(let Me=0;Me<w.textures.length;Me++){const Pe=De.get(w.textures[Me]);B.framebufferTextureLayer(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0+Me,Pe.__webglTexture,Y,pe)}}else if(w!==null&&Y!==0){const pe=De.get(w.texture);B.framebufferTexture2D(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_2D,pe.__webglTexture,Y)}G=-1};function so(w){const U=De.get(w);return(U.__readFormat!==w.format||U.__readType!==w.type)&&(U.__readFormat=w.format,U.__readType=w.type,U.__formatReadable=dt.textureFormatReadable(w.format),U.__typeReadable=dt.textureTypeReadable(w.type)),U}this.readRenderTargetPixels=function(w,U,Y,W,X,me,Te,pe=0){if(!(w&&w.isWebGLRenderTarget)){nt("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Me=De.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&Te!==void 0&&(Me=Me[Te],Array.isArray(Me)&&(Me=Me[0])),Me){he.bindFramebuffer(B.FRAMEBUFFER,Me);try{const Pe=w.textures[pe],ze=Pe.format,Ye=Pe.type;w.textures.length>1&&B.readBuffer(B.COLOR_ATTACHMENT0+pe);const Ae=so(Pe);if(Ae.__formatReadable===!1){nt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(Ae.__typeReadable===!1){nt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}U>=0&&U<=w.width-W&&Y>=0&&Y<=w.height-X&&B.readPixels(U,Y,W,X,le.convert(ze),le.convert(Ye),me)}finally{const Pe=Q!==null?De.get(Q).__webglFramebuffer:null;he.bindFramebuffer(B.FRAMEBUFFER,Pe)}}},this.readRenderTargetPixelsAsync=async function(w,U,Y,W,X,me,Te,pe=0){if(!(w&&w.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Me=De.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&Te!==void 0&&(Me=Me[Te],Array.isArray(Me)&&(Me=Me[0])),Me)if(U>=0&&U<=w.width-W&&Y>=0&&Y<=w.height-X){he.bindFramebuffer(B.FRAMEBUFFER,Me);const Pe=w.textures[pe],ze=Pe.format,Ye=Pe.type;w.textures.length>1&&B.readBuffer(B.COLOR_ATTACHMENT0+pe);const Ae=so(Pe);if(Ae.__formatReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(Ae.__typeReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const $e=B.createBuffer();B.bindBuffer(B.PIXEL_PACK_BUFFER,$e),B.bufferData(B.PIXEL_PACK_BUFFER,me.byteLength,B.STREAM_READ),B.readPixels(U,Y,W,X,le.convert(ze),le.convert(Ye),0),B.bindBuffer(B.PIXEL_PACK_BUFFER,null);const Rt=Q!==null?De.get(Q).__webglFramebuffer:null;he.bindFramebuffer(B.FRAMEBUFFER,Rt);const ht=B.fenceSync(B.SYNC_GPU_COMMANDS_COMPLETE,0);return B.flush(),await zd(B,ht,4),B.bindBuffer(B.PIXEL_PACK_BUFFER,$e),B.getBufferSubData(B.PIXEL_PACK_BUFFER,0,me),B.bindBuffer(B.PIXEL_PACK_BUFFER,null),B.deleteBuffer($e),B.deleteSync(ht),me}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(w,U=null,Y=0){const W=Math.pow(2,-Y),X=Math.floor(w.image.width*W),me=Math.floor(w.image.height*W),Te=U!==null?U.x:0,pe=U!==null?U.y:0;Ue.setTexture2D(w,0),B.copyTexSubImage2D(B.TEXTURE_2D,Y,0,0,Te,pe,X,me),he.unbindTexture()},this.copyTextureToTexture=function(w,U,Y=null,W=null,X=0,me=0){let Te,pe,Me,Pe,ze,Ye,Ae,$e,Rt;const ht=w.isCompressedTexture?w.mipmaps[me]:w.image;if(Y!==null)Te=Y.max.x-Y.min.x,pe=Y.max.y-Y.min.y,Me=Y.isBox3?Y.max.z-Y.min.z:1,Pe=Y.min.x,ze=Y.min.y,Ye=Y.isBox3?Y.min.z:0;else{const je=Math.pow(2,-X);Te=Math.floor(ht.width*je),pe=Math.floor(ht.height*je),w.isDataArrayTexture?Me=ht.depth:w.isData3DTexture?Me=Math.floor(ht.depth*je):Me=1,Pe=0,ze=0,Ye=0}W!==null?(Ae=W.x,$e=W.y,Rt=W.z):(Ae=0,$e=0,Rt=0);const ut=le.convert(U.format),Bt=le.convert(U.type);let Re;U.isData3DTexture?(Ue.setTexture3D(U,0),Re=B.TEXTURE_3D):U.isDataArrayTexture||U.isCompressedArrayTexture?(Ue.setTexture2DArray(U,0),Re=B.TEXTURE_2D_ARRAY):(Ue.setTexture2D(U,0),Re=B.TEXTURE_2D),he.activeTexture(B.TEXTURE0),he.pixelStorei(B.UNPACK_FLIP_Y_WEBGL,U.flipY),he.pixelStorei(B.UNPACK_PREMULTIPLY_ALPHA_WEBGL,U.premultiplyAlpha),he.pixelStorei(B.UNPACK_ALIGNMENT,U.unpackAlignment);const Wt=he.getParameter(B.UNPACK_ROW_LENGTH),it=he.getParameter(B.UNPACK_IMAGE_HEIGHT),Qn=he.getParameter(B.UNPACK_SKIP_PIXELS),zt=he.getParameter(B.UNPACK_SKIP_ROWS),dr=he.getParameter(B.UNPACK_SKIP_IMAGES);he.pixelStorei(B.UNPACK_ROW_LENGTH,ht.width),he.pixelStorei(B.UNPACK_IMAGE_HEIGHT,ht.height),he.pixelStorei(B.UNPACK_SKIP_PIXELS,Pe),he.pixelStorei(B.UNPACK_SKIP_ROWS,ze),he.pixelStorei(B.UNPACK_SKIP_IMAGES,Ye);const Bn=w.isDataArrayTexture||w.isData3DTexture,jn=U.isDataArrayTexture||U.isData3DTexture;if(w.isDepthTexture){const je=De.get(w),Ut=De.get(U),cn=De.get(je.__renderTarget),xt=De.get(Ut.__renderTarget);he.bindFramebuffer(B.READ_FRAMEBUFFER,cn.__webglFramebuffer),he.bindFramebuffer(B.DRAW_FRAMEBUFFER,xt.__webglFramebuffer);for(let It=0;It<Me;It++)Bn&&(B.framebufferTextureLayer(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,De.get(w).__webglTexture,X,Ye+It),B.framebufferTextureLayer(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,De.get(U).__webglTexture,me,Rt+It)),B.blitFramebuffer(Pe,ze,Pe+Te,ze+pe,Ae,$e,Ae+Te,$e+pe,B.DEPTH_BUFFER_BIT,B.NEAREST);he.bindFramebuffer(B.READ_FRAMEBUFFER,null),he.bindFramebuffer(B.DRAW_FRAMEBUFFER,null)}else if(X!==0||w.isRenderTargetTexture||De.has(w)){const je=De.get(w),Ut=De.get(U);he.bindFramebuffer(B.READ_FRAMEBUFFER,C),he.bindFramebuffer(B.DRAW_FRAMEBUFFER,D);for(let cn=0;cn<Me;cn++)Bn?B.framebufferTextureLayer(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,je.__webglTexture,X,Ye+cn):B.framebufferTexture2D(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_2D,je.__webglTexture,X),jn?B.framebufferTextureLayer(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,Ut.__webglTexture,me,Rt+cn):B.framebufferTexture2D(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_2D,Ut.__webglTexture,me),X!==0?B.blitFramebuffer(Pe,ze,Pe+Te,ze+pe,Ae,$e,Ae+Te,$e+pe,B.COLOR_BUFFER_BIT,B.NEAREST):jn?B.copyTexSubImage3D(Re,me,Ae,$e,Rt+cn,Pe,ze,Te,pe):B.copyTexSubImage2D(Re,me,Ae,$e,Pe,ze,Te,pe);he.bindFramebuffer(B.READ_FRAMEBUFFER,null),he.bindFramebuffer(B.DRAW_FRAMEBUFFER,null)}else jn?w.isDataTexture||w.isData3DTexture?B.texSubImage3D(Re,me,Ae,$e,Rt,Te,pe,Me,ut,Bt,ht.data):U.isCompressedArrayTexture?B.compressedTexSubImage3D(Re,me,Ae,$e,Rt,Te,pe,Me,ut,ht.data):B.texSubImage3D(Re,me,Ae,$e,Rt,Te,pe,Me,ut,Bt,ht):w.isDataTexture?B.texSubImage2D(B.TEXTURE_2D,me,Ae,$e,Te,pe,ut,Bt,ht.data):w.isCompressedTexture?B.compressedTexSubImage2D(B.TEXTURE_2D,me,Ae,$e,ht.width,ht.height,ut,ht.data):B.texSubImage2D(B.TEXTURE_2D,me,Ae,$e,Te,pe,ut,Bt,ht);he.pixelStorei(B.UNPACK_ROW_LENGTH,Wt),he.pixelStorei(B.UNPACK_IMAGE_HEIGHT,it),he.pixelStorei(B.UNPACK_SKIP_PIXELS,Qn),he.pixelStorei(B.UNPACK_SKIP_ROWS,zt),he.pixelStorei(B.UNPACK_SKIP_IMAGES,dr),me===0&&U.generateMipmaps===!0&&U.mipmapsAutoUpdate===!0&&B.generateMipmap(Re),he.unbindTexture()},this.initRenderTarget=function(w){De.get(w).__webglFramebuffer===void 0&&Ue.setupRenderTarget(w)},this.initTexture=function(w){w.isCubeTexture?Ue.setTextureCube(w,0):w.isData3DTexture?Ue.setTexture3D(w,0):w.isDataArrayTexture||w.isCompressedArrayTexture?Ue.setTexture2DArray(w,0):Ue.setTexture2D(w,0),he.unbindTexture()},this.resetState=function(){O=0,k=0,Q=null,he.reset(),de.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return hn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=Ke._getDrawingBufferColorSpace(e),t.unpackColorSpace=Ke._getUnpackColorSpace()}}class Yt{positions=[];normals=[];colors=[];owner=null;ranges=[];add(e,t,n,r=[1,1,1],s=0){const a=e.index?e.toNonIndexed():e.clone(),d=new ft().compose(new F(...n),new Zn().setFromAxisAngle(new F(0,1,0),s),new F(...r));a.applyMatrix4(d);const l=a.getAttribute("position"),o=a.getAttribute("normal"),f=new We(t);this.ranges.push({first:this.positions.length/9,count:l.count/3,id:this.owner});for(let h=0;h<l.count;h++)this.positions.push(l.getX(h),l.getY(h),l.getZ(h)),this.normals.push(o.getX(h),o.getY(h),o.getZ(h)),this.colors.push(f.r,f.g,f.b);a.dispose(),e.dispose()}triangle(e,t){const n=new Mt;n.setAttribute("position",new qe(e.flat(),3)),n.computeVertexNormals(),this.add(n,t,[0,0,0])}geometry(){const e=new Mt;return e.setAttribute("position",new qe(this.positions,3)),e.setAttribute("normal",new qe(this.normals,3)),e.setAttribute("color",new qe(this.colors,3)),e.computeBoundingBox(),e.computeBoundingSphere(),e}}function E0(i){const e=new rt;e.name="Tropical Creek Sanctuary";const t=[],n=[],r=new Yt,s=new Yt,a=new Yt,d=new Yt,l=new Yt,o=new Yt,f={identities:new Map,bounds:new Map,batches:[]},h=[r,s,a,d];function u(C,D,O,k,Q){const G=`${C}-${D}`,K=h.map(ve=>ve.positions.length),j=h.map(ve=>ve.owner);h.forEach(ve=>ve.owner=G),Q(),h.forEach((ve,$)=>ve.owner=j[$]);const ce=new bn;h.forEach((ve,$)=>{for(let ie=K[$];ie<ve.positions.length;ie+=3)ce.expandByPoint(new F(ve.positions[ie],ve.positions[ie+1],ve.positions[ie+2]))}),f.identities.set(G,{id:G,category:"object",kind:C,ordinal:D,cell:{x:Math.floor(O+i.width/2),z:Math.floor(k+i.height/2)}}),f.bounds.set(G,ce)}const p=(C,D)=>[C+.5-i.width/2,D+.5-i.height/2],m=(C,D,O,k,Q=0)=>C.add(new Pt(1,1,1),D,O,k,Q),x=(C,D,O=.35)=>a.add(new an(1,0),"#a3ad91",[C,.12,D],[O,O*.65,O*.8],C),_=(C,D,O)=>o.add(new gt(1,1,.003,12),"#294f3d",[C,.011,D],[O,1,O*.65]);m(r,"#a98258",[0,-.37,0],[i.width,.68,i.height]),m(r,"#c7a575",[0,-.08,0],[i.width+.04,.16,i.height+.04]);for(const C of i.tiles){const[D,O]=p(C.cell.x,C.cell.z),k=`tile-${C.cell.x}-${C.cell.z}`;f.identities.set(k,{id:k,category:"tile",kind:C.path?"path":C.terrain,ordinal:0,cell:{...C.cell}}),f.bounds.set(k,new bn(new F(D-.5,0,O-.5),new F(D+.5,.055,O+.5))),h.forEach(Q=>Q.owner=k),C.terrain==="land"?(m(r,["#9abf73","#9fc478","#a5c97e","#98bd70"][(C.cell.x*7+C.cell.z*3)%4],[D,-.018,O],[1,.08,1]),C.path&&C.cell.x===i.gate.x&&C.cell.z===i.gate.z&&m(a,"#edcd91",[D,.04,O],[.94,.06,.94])):(m(r,"#d0bd89",[D,-.025,O],[1,.06,1]),m(d,"#52b6b7",[D,.018,O],[.84,.026,1]),m(l,"#a9e6d3",[D-.12,.036,O],[.3,.005,.025]),m(l,"#87d7cf",[D+.16,.036,O+.27],[.18,.005,.018]))}h.forEach(C=>C.owner=null);function c(C,D,O,k){_(C+.22,D+.15,.65);for(let j=0;j<5;j++)s.add(new gt(.085-j*.006,.1-j*.006,O/5,6),"#96734e",[C+j*.035,O*(j+.5)/5,D+j*.016]);const Q=C+.17,G=O,K=D+.08;for(let j=0;j<7;j++){const ce=k+j*Math.PI*2/7,ve=Math.cos(ce),$=Math.sin(ce),ie=-$*.19,_e=ve*.19,we=[Q,G,K],ae=[Q+ve*.65,G+.2,K+$*.65],Ne=[Q+ve*1.18,G-.17,K+$*1.18];s.triangle([we,[ae[0]+ie,ae[1]-.07,ae[2]+_e],ae],j%2?"#478957":"#387650"),s.triangle([we,ae,[ae[0]-ie,ae[1]-.07,ae[2]-_e]],"#53985d"),s.triangle([ae,[ae[0]+ie,ae[1]-.07,ae[2]+_e],Ne],"#3f8052"),s.triangle([ae,Ne,[ae[0]-ie,ae[1]-.07,ae[2]-_e]],"#589e63")}s.add(new an(.16,0),"#c9b366",[Q,G-.1,K])}function g(C,D,O){_(C+.2,D+.15,.8),s.add(new gt(.1,.16,O*.7,6),"#866847",[C,O*.35,D]);for(let k=0;k<3;k++)s.add(new an(1,0),["#4d875a","#669b60","#7aa969"][k],[C+(k-1)*.36,O-.3+(k+1)%2*.26,D+k%2*.25],[.72,.65,.72],k)}[[-4.8,-3.8,1.9,.2],[-2.8,-3.9,2.15,1.2],[.7,-3.9,1.8,0],[4.6,-3.4,1.95,.6],[4.8,2.6,1.75,1],[-5.1,.4,1.8,2]].forEach((C,D)=>u("palm",D+1,C[0],C[1],()=>c(C[0],C[1],C[2],C[3]))),[[-4.8,-2.1,1.7],[-.8,-4,1.6],[4.8,.2,1.65],[1.7,3.9,1.5]].forEach((C,D)=>u("tree",D+1,C[0],C[1],()=>g(C[0],C[1],C[2]))),[[2.8,-3.8,.4],[3,-2.5,.25],[4.2,-.5,.32],[2.8,1.4,.3],[4.2,3.7,.45],[-4.7,-3.2,.4],[-1.8,-3.9,.3]].forEach(([C,D,O],k)=>u("rock",k+1,C,D,()=>x(C,D,O))),[[2.9,-3.3],[4.15,-1.5],[2.85,.3],[4.15,2.3]].forEach(([C,D],O)=>u("reeds",O+1,C,D,()=>{for(let k=0;k<4;k++)s.add(new gt(.018,.028,.36+k*.05,4),"#67916a",[C+k%2*.1,.2+k*.025,D+Math.floor(k/2)*.09])}));const[S,M]=p(i.gate.x,i.gate.z);u("gate",1,S,M,()=>{for(const C of[-.68,.68])m(a,"#c2aa7d",[S+C,.12,M],[.3,.25,.38]),m(a,"#76583d",[S+C,.72,M],[.14,1.1,.16]);m(a,"#795c40",[S,1.25,M],[1.65,.15,.26]);for(const C of[-1,1]){const D=[S-.98,1.34,M+C*.5],O=[S+.98,1.34,M+C*.5],k=[S+.98,1.65,M],Q=[S-.98,1.65,M];a.triangle(C===1?[D,O,k]:[O,D,Q],C===1?"#d38a5b":"#bd744e"),a.triangle(C===1?[D,k,Q]:[O,Q,k],C===1?"#d38a5b":"#bd744e")}m(a,"#f0ddab",[S,1.02,M+.18],[.75,.28,.05]),s.add(new an(.11,0),"#4c8558",[S,1.03,M+.22],[1,.65,.2],-.4),_(S,M,.9)});function A(C,D,O){const k=C.geometry();t.push(k),n.push(O);const Q=new at(k,O);return Q.name=D,e.add(Q),h.includes(C)&&f.batches.push({mesh:Q,ranges:C.ranges}),Q}const E=()=>new Kt({vertexColors:!0,roughness:.95,metalness:0,flatShading:!0});A(r,"land and creek banks",E());const v=E(),y=A(s,"tropical canopy and reeds",v);A(a,"gate and rocks",E()),A(d,"creek water",new Kt({vertexColors:!0,roughness:.45,metalness:0}));const T=A(l,"water glints",new Li({vertexColors:!0})),R=A(o,"soft contact shade",new Li({vertexColors:!0,transparent:!0,opacity:.13,depthWrite:!1}));e.updateMatrixWorld(!0);const N=new bn().setFromObject(e);let z=0,q=0;return{group:e,bounds:N,geometries:t,materials:n,catalog:f,setLowGraphics(C){T.visible=!C,R.visible=!C,y.material=C?T.material:v},update(C,D){z=C,q=D?0:Math.sin(C*6e-4)*.06,T.position.z=q},inspect:()=>({sceneryGlintsVisible:T.visible,sceneryShadeVisible:R.visible,scenerySimpleLighting:y.material===T.material,visualGameTimeMs:z,waterFlowOffset:q,terrainTiles:i.tiles.length,creekTiles:i.tiles.filter(C=>C.terrain==="creek").length,palmTrees:6,broadleafTrees:4,entranceGates:1})}}function w0(){const i=new rt;i.name="Thriving sanctuary celebration",i.visible=!1;let e,t,n=!1;function r(){i.clear(),e?.dispose(),t?.dispose(),e=void 0,t=void 0}function s(a,d){if(!n){if(i.visible=d,!d){r();return}if(!e){const l=new Yt;for(const o of[-1.08,1.08])l.add(new gt(.026,.032,1.95,6),"#886645",[o,.975,.55]),l.add(new an(.07,1),"#e8be57",[o,1.99,.55]);l.add(new Pt(2.16,.022,.022),"#e8d4a2",[0,1.91,.55]);for(let o=0;o<7;o++){const f=-.87+o*.29,h=["#4c9778","#efc75d","#d98765"][o%3],u=[f-.11,1.9,.55],p=[f+.11,1.9,.55],m=[f,1.62,.55];l.triangle([u,p,m],h),l.triangle([p,u,m],h)}e=l.geometry(),t=new Kt({vertexColors:!0,roughness:1}),i.add(new at(e,t))}i.position.set(a.gate.x+.5-a.width/2,0,a.gate.z+.5-a.height/2),i.updateMatrixWorld(!0)}}return{group:i,sync:s,dispose(){n||(n=!0,i.visible=!1,r())},inspect:()=>({thrivingBannerVisible:!n&&i.visible&&!!e,thrivingBannerMaterials:t?1:0,thrivingBannerTriangles:e?e.getAttribute("position").count/3:0})}}function T0(){const i=new rt;i.name="Unlocked aviary blossoms";let e,t,n=!1;function r(){i.clear(),e?.dispose(),t?.dispose(),e=void 0,t=void 0}function s(a,d){if(n)return;const l=a.habitats[0];if(i.visible=!!(d&&l),!i.visible){r();return}if(!e){const o=new Yt;for(const f of[-.8,-.55,.55,.8])for(const h of[-1.045,1.045]){o.add(new gt(.009,.009,.14,5),"#598447",[f,.15,h]);for(let u=0;u<5;u++){const p=u*Math.PI*2/5;o.add(new an(1,0),f<0?"#eead73":"#dc87a1",[f+Math.cos(p)*.035,.235,h+Math.sin(p)*.035],[.032,.014,.024],p)}o.add(new an(1,0),"#f6d766",[f,.249,h],[.02,.012,.02])}e=o.geometry(),t=new Kt({vertexColors:!0,roughness:1}),i.add(new at(e,t))}i.position.set(Math.min(...l.cells.map(o=>o.x))+1-a.width/2,0,Math.min(...l.cells.map(o=>o.z))+1-a.height/2),i.updateMatrixWorld(!0)}return{group:i,sync:s,dispose(){n||(n=!0,r())},inspect:()=>({rewardDecorationVisible:!n&&i.visible&&!!e,rewardDecorationMaterials:t?1:0,rewardDecorationTriangles:e?e.getAttribute("position").count/3:0})}}function A0(i,e=!1){const t=i[0].index!==null,n=new Set(Object.keys(i[0].attributes)),r=new Set(Object.keys(i[0].morphAttributes)),s={},a={},d=i[0].morphTargetsRelative,l=new Mt;l.morphTargetsRelative=d;let o=0;for(let f=0;f<i.length;++f){const h=i[f];let u=0,p=0;if(t!==(h.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+f+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const m in h.attributes){if(!n.has(m))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+f+'. All geometries must have compatible attributes; make sure "'+m+'" attribute exists among all geometries, or in none of them.'),null;s[m]===void 0&&(s[m]=[]),s[m].push(h.attributes[m]),u++}if(u!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+f+". Make sure all geometries have the same number of attributes."),null;if(d!==h.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+f+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const m in h.morphAttributes){if(!r.has(m))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+f+".  .morphAttributes must be consistent throughout all geometries."),null;if(h.morphAttributes[m].length!==i[0].morphAttributes[m].length)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+f+'. All geometries must have the same number of morph targets for the "'+m+'" morph attribute.'),null;a[m]===void 0&&(a[m]=[]),a[m].push(h.morphAttributes[m]),p++}if(p!==r.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+f+". Make sure all geometries have the same number of morph attributes."),null;if(e){let m;if(t)m=h.index.count;else if(h.attributes.position!==void 0)m=h.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+f+". The geometry must have either an index or a position attribute"),null;l.addGroup(o,m,f),o+=m}}if(t){let f=0;const h=[];for(let u=0;u<i.length;++u){const p=i[u].index;for(let m=0;m<p.count;++m)h.push(p.getX(m)+f);f+=i[u].attributes.position.count}l.setIndex(h)}for(const f in s){const h=fl(s[f]);if(!h)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+f+" attribute."),null;l.setAttribute(f,h)}for(const f in a){const h=a[f][0].length;if(h!==0){l.morphAttributes=l.morphAttributes||{},l.morphAttributes[f]=[];for(let u=0;u<h;++u){const p=[];for(let x=0;x<a[f].length;++x)p.push(a[f][x][u]);const m=fl(p);if(!m)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+f+" morphAttribute."),null;l.morphAttributes[f].push(m)}}}return l}function fl(i){let e,t,n,r=-1,s=0;for(let o=0;o<i.length;++o){const f=i[o];if(e===void 0&&(e=f.array.constructor),e!==f.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(t===void 0&&(t=f.itemSize),t!==f.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=f.normalized),n!==f.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(r===-1&&(r=f.gpuType),r!==f.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;s+=f.count*t}const a=new e(s),d=new On(a,t,n);let l=0;for(let o=0;o<i.length;++o){const f=i[o];if(f.isInterleavedBufferAttribute){const h=l/t;for(let u=0,p=f.count;u<p;u++)for(let m=0;m<t;m++){const x=f.getComponent(u,m);d.setComponent(u+h,m,x)}}else a.set(f.array,l);l+=f.count*t}return r!==void 0&&(d.gpuType=r),d}function R0(){const i=new rt;i.name="Entrance visitors";let e=3,t=!1,n=-1,r;const s=new Map;function a(){const l=[],o=new Kt({vertexColors:!0,roughness:.95,flatShading:!0}),f=new Li({color:"#314b38",transparent:!0,opacity:.13,depthWrite:!1});function h(S,M,A,E,v){const y=S.index?S.toNonIndexed():S,T=new We(M),R=y.getAttribute("position");return y.setAttribute("color",new qe(Array.from({length:R.count},()=>[T.r,T.g,T.b]).flat(),3)),y.applyMatrix4(new ft().makeTranslation(A,E,v)),y!==S&&S.dispose(),y}function u(S){const M=A0(S,!1);if(S.forEach(A=>A.dispose()),!M)throw Error("Visitor geometry merge failed");return l.push(M),M}const p=["#a96f4a","#e0ae82","#79533f"],m=["#e49c4b","#578b9d","#a86b89"],x=p.map((S,M)=>u([h(new Pt(.14,.25,.1),m[M],0,.4,0),h(new gt(.025,.025,.04,6),S,0,.535,0),h(new an(.065,1),S,0,.6,0),h(new gt(.071,.071,.045,8),"#53614d",0,.66,0),h(new gt(.095,.095,.009,8),"#dcc38a",0,.638,0),h(new Pt(.082,.12,.04),"#8d7751",0,.41,-.067),h(new Pt(.012,.012,.008),"#243e38",-.025,.605,.059),h(new Pt(.012,.012,.008),"#243e38",.025,.605,.059)])),_=p.map((S,M)=>u([h(new Pt(.038,.1,.043),m[M],0,-.05,0),h(new Pt(.03,.085,.032),S,0,-.142,0),h(new an(.022,0),S,0,-.19,0)])),c=u([h(new Pt(.042,.22,.048),"#526b6c",0,-.11,0),h(new Pt(.057,.05,.086),"#504b40",0,-.235,.015)]),g=new Ii(.12,10);return l.push(g),{bodies:x,arms:_,leg:c,shadow:g,material:o,shade:f,geometries:l}}function d(l,o){r??=a();const f=r,h=(o-1)%3,u=new rt;u.name=l;const p=new at(f.bodies[h],f.material);u.add(p);const m=[-1,1].map(c=>{const g=new at(f.arms[h],f.material);return g.position.set(c*.092,.49,0),u.add(g),g}),x=[-1,1].map(c=>{const g=new at(f.leg,f.material);return g.position.set(c*.042,.26,0),u.add(g),g}),_=new at(f.shadow,f.shade);return _.rotation.x=-Math.PI/2,_.position.y=.001,u.add(_),i.add(u),{root:u,body:p,arms:m,legs:x,previous:new F,current:new F,age:0,heading:Math.PI,walking:!1}}return{group:i,sync(l,o,f,h,u={x:1,z:8}){if(t||h===n)return;n=h;const p=new Set(l.filter(m=>m.arrival).map(m=>m.id));for(const[m,x]of s)p.has(m)||(i.remove(x.root),x.root.clear(),s.delete(m));for(const m of l){if(!m.arrival)continue;let x=s.get(m.id);const _=new F(m.position.x-o/2,Math.floor(m.position.x)===u.x&&Math.floor(m.position.z)===u.z?.073:.0945,m.position.z-f/2);x?x.previous.copy(x.current):(x=d(m.id,m.arrival.serial),x.previous.copy(_),s.set(m.id,x)),x.current.copy(_),x.age=Dc(m,h),x.heading=m.journey?.heading??(x.age<Ic.leaveAt?Math.PI:0),x.walking=x.previous.distanceToSquared(x.current)>1e-12}},update(l,o,f=!1){if(t)return;let h=0;for(const u of s.values()){u.root.visible=h++<e;const p=u.walking,m=o*.01+u.age*.03,x=p&&!f?Math.sin(m)*.12:0;u.root.position.lerpVectors(u.previous,u.current,Math.min(1,Math.max(0,l))),u.root.position.y+=Math.abs(x)*.06,u.root.rotation.y=u.heading,u.legs.forEach((_,c)=>_.rotation.x=x*(c?1:-1)),u.arms.forEach((_,c)=>_.rotation.x=-x*2*(c?1:-1))}},setVisibleCap(l){e=l;let o=0;for(const f of s.values())f.root.visible=o++<e},inspect:()=>({visibleVisitorModels:[...s.values()].filter(l=>l.root.visible).length,visitorModels:s.size,visitorGeometries:t?0:r?.geometries.length??0,visitorOwnedMaterials:t||!r?0:2,visitorModelTriangles:!t&&r?r.bodies[0].getAttribute("position").count/3+2*r.arms[0].getAttribute("position").count/3+2*r.leg.getAttribute("position").count/3+10:0,visitorTextures:0,visitorSceneDisposed:t}),dispose(){t||(t=!0,i.clear(),s.clear(),r?.geometries.forEach(l=>l.dispose()),r?.material.dispose(),r?.shade.dispose(),r=void 0)}}}function C0(){const i=new rt,e=new rt;i.name="Leafy rest perches",e.name="Rest foliage";let t,n,r,s,a=!1,d=!1;function l(){const u=new Yt,p=new Yt,m=.079+Kr-.035*.62,x=.5-.025*.62;for(const _ of[-.5,.5]){u.add(new gt(.035*.62,.035*.62,.34,8).rotateZ(Math.PI/2),"#99754e",[_,m,x]);for(const c of[-.15,.15])u.add(new gt(.014,.014,m-.079,8),"#99754e",[_+c,.079+(m-.079)/2,x]),u.add(new gt(.026,.026,.018,8).rotateZ(Math.PI/2),"#9eb577",[_+c,m,x])}u.add(new gt(.1,.08,.12,8),"#bf8662",[0,.139,.22]),u.add(new gt(.089,.089,.01,8),"#735d44",[0,.204,.22]),u.add(new gt(.014,.02,.3,7),"#8f7651",[0,.355,.22]);for(const[_,c,g,S]of[[-.055,.48,.2,.09],[.05,.52,.24,.09],[0,.6,.21,.08],[-.04,.57,.19,.07],[.045,.59,.23,.065]])p.add(new an(1,0),_<0?"#6c9e61":"#8ab371",[_,c,g],[S,S*.7,S*.65],_*4);t=u.geometry(),n=p.geometry(),r=new Kt({vertexColors:!0,roughness:1}),s=new at(t,r),e.add(new at(n,r)),i.add(s,e)}function o(){i.clear(),e.clear(),t?.dispose(),n?.dispose(),r?.dispose(),t=void 0,n=void 0,r=void 0,s=void 0}function f(u,p,m=!0){if(d)return;const x=u.habitats[0];if(a=!!((x?Nc(u,x):void 0)||p&&x),i.visible=a,!a){s&&o();return}s||l();const c=Uc(x);i.position.set(c.x+1-u.width/2,0,c.z-u.height/2),r.transparent=p,r.opacity=p?.42:1,r.depthWrite=!p,r.color.set(p?m?"#8bd5a1":"#e58c79":"#ffffff"),i.updateMatrixWorld(!0)}function h(u,p,m){d||!a||(e.rotation.z=!m&&p>0?.018*Math.sin(u/600):0)}return{group:i,sync:f,update:h,dispose(){d||(d=!0,a=!1,o())},inspect:()=>({restKitVisible:a,perchSceneDisposed:d,perchOwnedMaterials:s?1:0,perchGeometries:s?2:0,perchTriangles:t&&n?(t.getAttribute("position").count+n.getAttribute("position").count)/3:0,leafSway:e.rotation.z})}}const hl=.235;function P0(){const i=new rt;i.name="Two macaw water bowls";let e,t,n,r,s,a=[],d=!1,l=!1;function o(){const u=new Yt,p=.62,m=.025;for(const x of[-.8344,.8344])u.add(new or([[0,.01],[.09,.01],[.13,.06],[.13,.085],[.103,.085],[.08,.03],[0,.03]].map(_=>new Be(..._)),12),"#609aa0",[x,.079+.15*p+m,.85],[p,p,p]),u.add(new gt(.055,.075,.16+m/p,8),"#99754e",[x,.079+.08*p+m/2,.85],[p,p,p]);e=u.geometry(),t=new Kt({vertexColors:!0,roughness:1}),s=new at(e,t),i.add(s),n=new Ii(.089*p,16),r=new Kt({color:"#63bfe0",roughness:.45}),a=[-.8344,.8344].map(x=>{const _=new at(n,r);return _.rotation.x=-Math.PI/2,_.position.set(x,hl,.85),i.add(_),_})}function f(){i.clear(),e?.dispose(),t?.dispose(),n?.dispose(),r?.dispose(),e=void 0,t=void 0,n=void 0,r=void 0,s=void 0,a=[]}function h(u,p,m=!0){if(l)return;const x=u.habitats[0],_=x?Fc(u,x):void 0;if(d=!!(_||p&&x),i.visible=d,!d){s&&f();return}s||o();const c=Oc(x);i.position.set(c.x-u.width/2,0,c.z-u.height/2),t.transparent=p,t.opacity=p?.42:1,t.depthWrite=!p,t.color.set(p?m?"#8bd5a1":"#e58c79":"#ffffff"),a.forEach((g,S)=>{const M=_?.portions?.[S]??0;g.visible=!p&&M>0,g.position.y=hl-.012*(1-M/4)}),i.updateMatrixWorld(!0)}return{group:i,sync:h,dispose(){l||(l=!0,d=!1,f())},inspect:()=>({waterVisible:d,waterSceneDisposed:l,waterOwnedMaterials:s?2:0,waterGeometries:s?2:0,waterTriangles:e?e.getAttribute("position").count/3:0,waterSurface1:a[0]?.visible??!1,waterSurface2:a[1]?.visible??!1})}}const kr=.04;function L0(){const i=new rt;i.name="Two-port macaw feeder";let e,t,n,r,s,a=[];function d(){const u=new Yt,p=.62,m=(x,_,c,g)=>u.add(x,_,c,g);for(const x of[-.5,.5])m(new or([[0,.01],[.09,.01],[.13,.06],[.13,.085],[.103,.085],[.08,.03],[0,.03]].map(_=>new Be(..._)),12),"#bf8662",[x,.079+.15*p+kr,.7844],[p,p,p]),m(new gt(.055,.075,.16+kr/p,8),"#99754e",[x,.079+.08*p+kr/2,.7844],[p,p,p]);m(new Pt(1,1,1),"#b99a66",[0,.1,.7844],[1.35,.035,.08]),e=u.geometry(),t=new Kt({vertexColors:!0,roughness:1}),n=new at(e,t),i.add(n),r=new lr(.021,7,5),s=new Kt({color:"#e9a53b",flatShading:!0,roughness:1}),a=Array.from({length:8},(x,_)=>{const c=new at(r,s),g=_%2,S=Math.floor(_/2);return c.position.set((g===0?-.5:.5)+(S===0?0:S%2?-.024:.024),.079+.213*p+kr+(S>1?.018:0),.7844+(S<2?-.016:.022)),i.add(c),c})}function l(){i.clear(),e?.dispose(),t?.dispose(),r?.dispose(),s?.dispose(),e=void 0,t=void 0,n=void 0,r=void 0,s=void 0,a=[]}let o=!1,f=!1;function h(u,p,m=!0){if(o)return;const x=u.habitats[0],_=u.resources.find(g=>g.kind==="food");if(f=!!(_||p&&x),i.visible=f,!f){n&&l();return}n||d();const c=_?.cell??Bc(x);i.position.set(c.x+1-u.width/2,0,c.z-u.height/2),t.transparent=p,t.opacity=p?.42:1,t.depthWrite=!p,t.color.set(p?m?"#8bd5a1":"#e58c79":"#ffffff"),a.forEach((g,S)=>{g.visible=!p&&Math.floor(S/2)<(_?.portions?.[S%2]??0)}),i.updateMatrixWorld(!0)}return{group:i,sync:h,dispose(){o||(o=!0,l(),f=!1)},inspect:()=>({feederVisible:f,feederSceneDisposed:o,feederOwnedMaterials:n?2:0,feederGeometries:n?2:0,feederTriangles:e?e.getAttribute("position").count/3:0,feederBowl1Fruit:a.filter((u,p)=>u.visible&&p%2===0).length,feederBowl2Fruit:a.filter((u,p)=>u.visible&&p%2===1).length,feederFruitCount:o?0:a.filter(u=>u.visible).length})}}const wi=.62,Gr=["body","head","jaw","wingLeft","wingRight","foreLeft","foreRight","tail","flatFoot","gripFoot","eyelids"],D0={blue:"#1587c3",deep:"#17679e",sky:"#37a3d2",gold:"#f6bf3c",warm:"#dba02e",green:"#41955a",ivory:"#fff2d9",charcoal:"#24333b",feet:"#565b61",iris:"#f4cf6a",shine:"#ffffff"};class I0{p=[];c=[];triangle(e,t,n,r){if(new F().subVectors(new F(...t),new F(...e)).cross(new F().subVectors(new F(...n),new F(...e))).lengthSq()<1e-14)return;const a=new We(D0[r]);for(const d of[e,t,n])this.p.push(...d),this.c.push(a.r,a.g,a.b)}sphere(e,t,n,r=12,s=8){const a=new lr(1,r,s),d=a.toNonIndexed();a.dispose(),d.scale(...t),d.translate(...e);const l=d.getAttribute("position");for(let o=0;o<l.count;o+=3){const f=[0,1,2].map(u=>[l.getX(o+u),l.getY(o+u),l.getZ(o+u)]),h=f.reduce((u,p)=>u.map((m,x)=>m+p[x]/3),[0,0,0]);this.triangle(f[0],f[1],f[2],typeof n=="string"?n:n(h))}d.dispose()}tube(e,t,n,r,s=5){const a=new F(...e),d=new F(...t),l=d.clone().sub(a),o=new gt(n,n,l.length(),s,1,!1),f=o.toNonIndexed();o.dispose(),f.applyQuaternion(new Zn().setFromUnitVectors(new F(0,1,0),l.clone().normalize())),f.translate(...a.add(d).multiplyScalar(.5).toArray());const h=f.getAttribute("position");for(let u=0;u<h.count;u+=3)this.triangle([h.getX(u),h.getY(u),h.getZ(u)],[h.getX(u+1),h.getY(u+1),h.getZ(u+1)],[h.getX(u+2),h.getY(u+2),h.getZ(u+2)],r);f.dispose()}feather(e,t,n,r,s,a,d){const l=new F(...e),o=new F(...t),f=new F(...s).normalize(),h=o.clone().sub(l),u=new F().crossVectors(h,f).normalize().multiplyScalar(n),p=l.clone().lerp(o,.52);let m=[l.clone().addScaledVector(u,-.38),l.clone().addScaledVector(u,.38),p.clone().addScaledVector(u,.5),o,p.clone().addScaledVector(u,-.5)];m[1].clone().sub(m[0]).cross(m[2].clone().sub(m[0])).dot(f)<0&&(m=m.reverse());const x=m.map(c=>c.clone().addScaledVector(f,r).toArray()),_=m.map(c=>c.clone().addScaledVector(f,-r).toArray());for(let c=1;c<4;c++)this.triangle(x[0],x[c],x[c+1],a),this.triangle(_[0],_[c+1],_[c],d);for(let c=0;c<5;c++){const g=(c+1)%5;this.triangle(x[c],_[c],_[g],a),this.triangle(x[c],_[g],x[g],a)}}geometry(e=[0,0,0]){const t=new Mt;return t.setAttribute("position",new qe(this.p,3)),t.setAttribute("color",new qe(this.c,3)),t.translate(-e[0],-e[1],-e[2]),t.computeVertexNormals(),t.computeBoundingBox(),t.computeBoundingSphere(),t}}const Dn={body:[0,.16,0],head:[0,.66,.09],jaw:[0,.729,.249],wingLeft:[-.14,.58,.005],wingRight:[.14,.58,.005],tail:[0,.22,-.1]};function Sc(){const i=Object.fromEntries(Gr.map(l=>[l,new I0])),e=i.body;e.sphere([0,.4,0],[.162,.3,.15],l=>l[2]>-.015?"gold":"blue"),e.sphere([0,.65,.055],[.112,.13,.112],l=>l[2]>.025?"gold":"blue",12,7);const t=i.head;t.sphere([0,.783,.125],[.134,.137,.137],l=>l[1]>.863&&l[2]>.09?"green":"blue",14,8),t.sphere([0,.685,.198],[.085,.048,.036],"charcoal",10,5);for(const l of[-1,1]){t.sphere([l*.124,.788,.176],[.023,.076,.075],"ivory",12,7),t.sphere([l*.148,.822,.208],[.008,.018,.018],"iris",10,6),t.sphere([l*.155,.822,.21],[.004,.01,.01],"charcoal",8,5),t.sphere([l*.158,.827,.215],[.0025,.0035,.0035],"shine",6,4);for(let o=0;o<3;o++)t.tube([l*.146,.778-o*.014,.137],[l*.148,.77-o*.014,.175],.0023,"charcoal",4);i.eyelids.sphere([l*.16,.822,.208],[.006,.02,.021],"ivory",10,6),i.eyelids.tube([l*.166,.821,.194],[l*.166,.819,.223],.0023,"charcoal",4)}const n=[[.209,.797,.06,.056],[.255,.795,.066,.06],[.302,.774,.052,.055],[.329,.733,.029,.038],[.322,.686,.004,.007]],r=n.map(([l,o,f,h])=>Array.from({length:10},(u,p)=>[f*Math.cos(p*Math.PI/5),o+h*Math.sin(p*Math.PI/5),l]));for(let l=0;l<r.length-1;l++)for(let o=0;o<10;o++){const f=(o+1)%10;t.triangle(r[l][o],r[l+1][f],r[l+1][o],"charcoal"),t.triangle(r[l][o],r[l][f],r[l+1][f],"charcoal")}for(let l=0;l<10;l++){const o=(l+1)%10;t.triangle([0,n[0][1],n[0][0]],r[0][o],r[0][l],"charcoal"),t.triangle([0,n.at(-1)[1],n.at(-1)[0]],r.at(-1)[l],r.at(-1)[o],"charcoal")}i.jaw.sphere([0,.719,.263],[.043,.026,.056],"charcoal",10,6);for(const[l,o,f]of[[-1,"wingLeft","foreLeft"],[1,"wingRight","foreRight"]]){const h=i[o],u=i[f];h.sphere([l*.1,-.012,-.022],[.14,.029,.094],"blue",10,6),u.sphere([l*.1,-.005,-.025],[.145,.024,.084],p=>p[1]>-.005?"blue":"gold",10,6);for(let p=0;p<4;p++)h.feather([l*.015,0,.063-p*.041],[l*(.25-p*.009),-.004,.02-p*.05],.052,.008,[0,1,0],p===0?"sky":"blue","gold");for(let p=0;p<6;p++)u.feather([0,0,.035-p*.023],[l*(.32-Math.abs(p-2)*.017),-.013,-.025-p*.016],.044,.007,[0,1,0],p===0||p===5?"deep":p===2?"sky":"blue",p<3?"gold":"warm")}for(let l=-2;l<=2;l++)i.tail.feather([l*.027,0,0],[l*.015,-.6+Math.abs(l)*.035,-.16-Math.abs(l)*.012],.052,.007,[0,0,-1],l===0?"sky":"blue","warm");for(const l of[!1,!0]){const o=i[l?"gripFoot":"flatFoot"];o.tube([0,.215,-.018],[0,.075,0],.015,"feet",6),o.tube([0,.075,0],[0,.018,0],.011,"feet",6);for(const f of[-1,1])for(const h of[-1,1]){const u=[f*.012,.018,0],p=[f*.02,l?-.01:.009,h*.026],m=[f*.023,l?-.035:.008,h*(l?.039:.058)],x=[f*.022,l?-.057:.004,h*(l?.026:.071)];o.tube(u,p,.0055,"feet",5),o.tube(p,m,.0045,"feet",5),o.tube(m,x,.0035,"charcoal",5)}}const s=Object.fromEntries(Gr.map(l=>[l,i[l].geometry(["body","head","jaw"].includes(l)?[...Dn[l]]:l==="eyelids"?[...Dn.head]:void 0)])),a=new Kt({vertexColors:!0,flatShading:!0,roughness:.88,metalness:0});a.name="Original macaw palette";let d=!1;return{geometries:s,material:a,dispose(){d||(d=!0,Object.values(s).forEach(l=>l.dispose()),a.dispose())},inspect:()=>({macawAssetsDisposed:d,macawAssetGeometries:d?0:Gr.length,macawMaterials:d?0:1,macawTextures:0,macawTriangles:Gr.filter(l=>l!=="flatFoot"&&l!=="gripFoot"&&l!=="eyelids").reduce((l,o)=>l+s[o].getAttribute("position").count/3,0)+2*s.gripFoot.getAttribute("position").count/3+s.eyelids.getAttribute("position").count/3})}}function yc(i){const e=new rt,t=new rt,n=new rt;e.name="Ara ararauna",e.add(t),t.add(n);const r=g=>{const S=new at(i.geometries[g],i.material);return S.name=g,S};n.position.set(...Dn.body),n.add(r("body"));const s=g=>{const S=new rt,M=Dn[g];return S.name=g,S.position.set(M[0],M[1]-Dn.body[1],M[2]),n.add(S),S},a=s("head");a.add(r("head"));const d=r("eyelids");a.add(d);const l=new rt;l.position.set(0,Dn.jaw[1]-Dn.head[1],Dn.jaw[2]-Dn.head[2]),l.add(r("jaw")),a.add(l);const o=s("wingLeft"),f=s("wingRight");o.add(r("wingLeft")),f.add(r("wingRight"));const h=new rt,u=new rt;h.position.set(-.22,-.012,-.035),u.position.set(.22,-.012,-.035),h.add(r("foreLeft")),u.add(r("foreRight")),o.add(h),f.add(u);const p=s("tail");p.add(r("tail"));const m=[new rt,new rt],x=m.map((g,S)=>{g.position.set(S===0?-.075:.075,0,.025);const M=r("gripFoot");return g.add(M),t.add(g),M});let _=!1;function c(g){if(!_){t.position.y=g.lift,n.position.y=.16+g.bob,n.rotation.x=g.bodyPitch,a.rotation.set(g.headPitch,g.headYaw,0),l.rotation.x=g.jaw,p.rotation.x=g.tailPitch,o.rotation.z=g.wingLeft,f.rotation.z=g.wingRight,h.rotation.y=g.elbowLeft,u.rotation.y=g.elbowRight,m[0].position.y=g.leftLift,m[1].position.y=g.rightLift,m[0].position.z=.025+g.leftStep,m[1].position.z=.025+g.rightStep;for(const[S,M]of m.entries())M.rotation.x=g.footPitch,x[S].geometry=i.geometries[g.grip>=.5?"gripFoot":"flatFoot"];d.visible=g.eyesClosed>.5,e.updateMatrixWorld(!0)}}return{root:e,apply:c,dispose(){_||(_=!0,e.clear())},inspect:()=>({macawRigDisposed:_,macawRigMeshes:_?0:10+(d.visible?1:0),macawFootGrip:x[0].geometry===i.geometries.gripFoot})}}const N0=["perch","walk","hop","fly","eat","drink","rest"],to=i=>N0.includes(i);function ji(i,e){if(!to(i)||!Number.isFinite(e)||e<0)throw new RangeError("Invalid macaw animation sample");const t=e/1e3,n={bodyPitch:0,bob:0,headPitch:0,headYaw:.12*Math.sin(t*1.3),jaw:0,tailPitch:0,wingLeft:1.4,wingRight:-1.4,elbowLeft:-.35,elbowRight:.35,leftStep:0,rightStep:0,leftLift:0,rightLift:0,footPitch:0,grip:1,lift:0,eyesClosed:t%5>4.83?1:0};if(i==="perch"&&(n.headPitch=.025*Math.sin(t*1.8),n.bob=.002*Math.sin(t*2)),i==="walk"){const r=t*Math.PI*2/.8;n.grip=0,n.bodyPitch=.1,n.tailPitch=1.15,n.headPitch=-.1,n.headYaw=.025*Math.sin(r),n.bob=.012*(1-Math.cos(r*2)),n.leftStep=.052*Math.cos(r),n.rightStep=-n.leftStep,n.leftLift=.06*Math.max(0,Math.sin(r)),n.rightLift=.06*Math.max(0,-Math.sin(r))}if(i==="hop"){const r=Math.max(0,Math.sin(t*Math.PI*2/1.4));n.grip=0,n.bodyPitch=.13,n.tailPitch=1.15,n.lift=.15*r,n.footPitch=.22*r,n.headPitch=-.08}if(i==="fly"){const r=Math.sin(t*Math.PI*2*2.8);n.grip=0,n.bodyPitch=.75,n.headPitch=-.5,n.headYaw=0,n.tailPitch=1.15,n.lift=.54+.028*Math.sin(t*4),n.wingLeft=-.57*r,n.wingRight=.57*r,n.elbowLeft=-.1-.08*Math.sin(t*Math.PI*2*2.8+.5),n.elbowRight=-n.elbowLeft,n.leftLift=n.rightLift=.15,n.footPitch=.9}if(i==="eat"||i==="drink"){const r=Math.sin(t*Math.PI*2/(i==="eat"?1.1:1.8));n.grip=0,n.bodyPitch=(i==="eat"?.76:.86)+.035*r,n.headPitch=.12+.06*r,n.headYaw=.025*Math.sin(t*2),n.tailPitch=1.15,n.jaw=i==="eat"?.19*Math.max(0,Math.sin(t*13)):.025}return i==="rest"&&(n.headPitch=.25,n.headYaw=-.52,n.eyesClosed=1),n}function bc(i,e,t){if(!Number.isFinite(t))throw new RangeError("Invalid pose blend");const n=Math.max(0,Math.min(1,t));return Object.fromEntries(Object.keys(i).map(r=>[r,i[r]+(e[r]-i[r])*n]))}function U0(i="perch"){let e=i,t=0,n=0,r=ji(e,0),s=!1;const a=()=>bc(r,ji(e,t-n),Math.min(1,(t-n)/280));return{setClip(d,l=!1){s||!to(d)||d===e||(r=l?ji(d,0):a(),n=t,e=d)},advance(d){if(!Number.isFinite(d)||d<0)throw new RangeError("Invalid animation delta");s||(t+=Math.min(d,250))},pose:()=>structuredClone(a()),dispose(){s=!0},inspect:()=>({clip:e,timeMs:t,transitioning:t-n<280,disposed:s})}}function pl(i,e){const t=i.motion,n=t.phase==="walk-out"||t.phase==="walk-home"||t.phase==="seek-food"||t.phase==="leave-food"||["seek-rest","seek-water","water-back","leave-water","water-home","water-abort"].includes(t.phase),r=t.phase==="ascend"||t.phase==="descend",s=ji(t.phase==="rest"?"rest":t.phase==="drink"?"drink":t.phase==="water-hop"?"hop":t.phase==="eat"?"eat":n?"walk":"perch",t.phase==="eat"||t.phase==="drink"?(20-t.ticksLeft)*100:t.phase==="water-hop"?(8-t.ticksLeft)*100:e);if(t.phase==="enrich"&&(s.headYaw=(i.id==="macaw-1"?-.55:.55)+.1*Math.sin(e/600),s.headPitch=.08*Math.sin(e/700),s.eyesClosed=0),["perch","rest","enrich"].includes(t.phase)||(s.grip=0,s.tailPitch=1.15*(1-t.elevation/Kr)),r){const a=ji("fly",e),d=Math.min((24-t.ticksLeft)/4,t.ticksLeft/4,1);for(const l of["wingLeft","wingRight","elbowLeft","elbowRight"])s[l]+=(a[l]-s[l])*Math.max(0,d);s.leftStep=s.rightStep=s.leftLift=s.rightLift=0,s.grip=t.elevation===Kr&&t.ticksLeft<3?1:0}return s.lift=0,s}function F0(){const i=new rt;i.name="Two sanctuary macaws";let e=!1,t,n,r,s="";const a=new Map,d=[];let l=!0;function o(){for(const u of a.values())u.rig.dispose();a.clear(),d.length=0,i.clear(),t?.dispose(),t=void 0,n?.dispose(),n=void 0,r?.dispose(),r=void 0,s=""}function f(u,p,m,x,_){if(e)return;const c=u.filter(S=>S.habitatId&&S.position).sort((S,M)=>S.id.localeCompare(M.id)),g=c.map(S=>`${S.id}:${S.habitatId}`).join("|");g!==s&&(o(),s=g,c.length&&(t=Sc(),n=new gt(1,1,1,8),r=new Kt({color:"#99754e",roughness:1})));for(const[S,M]of c.entries()){let A=a.get(M.id);if(!A&&t){const E=yc(t);E.root.name=M.id,E.root.scale.setScalar(wi),i.add(E.root);const v=pl(M,_);A={rig:E,previous:structuredClone(M),current:structuredClone(M),pose:v,from:v,changedAt:_},a.set(M.id,A);const y=p.find(C=>C.id===M.habitatId),T=zc(y,S).perch,R=T.x-m/2,N=T.z-x/2-.025*wi,z=.079+Kr-.035*wi,q=new at(n,r);q.rotation.z=Math.PI/2,q.scale.set(.035*wi,.34,.035*wi),q.position.set(R,z,N),q.visible=l,d.push(q),i.add(q);for(const C of[-.15,.15]){const D=new at(n,r);D.scale.set(.014,z-.079,.014),D.position.set(R+C,.079+(z-.079)/2,N),D.visible=l,d.push(D),i.add(D)}}A&&(A.current.motion.phase!==M.motion.phase&&(A.from={...A.pose},A.changedAt=_),A.previous=A.current,A.current=structuredClone(M))}i.userData.worldWidth=m,i.userData.worldHeight=x}function h(u,p){if(e)return;const m=Math.max(0,Math.min(1,u));for(const x of a.values()){const _=x.current,c=x.previous;if(!_.position||!c.position)continue;const g=c.motion.heading+Math.atan2(Math.sin(_.motion.heading-c.motion.heading),Math.cos(_.motion.heading-c.motion.heading))*m;x.rig.root.position.set(c.position.x+(_.position.x-c.position.x)*m-i.userData.worldWidth/2,.079+c.motion.elevation+(_.motion.elevation-c.motion.elevation)*m,c.position.z+(_.position.z-c.position.z)*m-i.userData.worldHeight/2),x.rig.root.rotation.y=g;const S=pl(_,p+(_.id==="macaw-1"?0:1300));x.pose=bc(x.from,S,Math.min(1,Math.max(0,p-x.changedAt)/280)),x.rig.apply(x.pose)}}return{group:i,sync:f,update:h,setPerchesVisible(u){l=u;for(const p of d)p.visible=u},setVisible:u=>{i.visible=u},dispose(){e||(e=!0,o())},inspect:()=>({liveBirdModels:a.size,birdAssetsGeometries:t?.inspect().macawAssetGeometries??0,birdOwnedMaterials:t?2:0,birdModelTriangles:t?t.inspect().macawTriangles*a.size:0,birdPerchTriangles:t&&l?96*a.size:0,birdPerchesVisible:l&&a.size>0,birdSceneDisposed:e})}}const ml=["quarter","front","side","back"];function O0(i,e,t){const n=new rt,r=new os;n.name="Macaw model and animation preview",n.visible=!1;let s={active:!1,habitat:!1,clip:"perch",angle:"quarter",motionPaused:!1,canHabitat:!1},a,d,l,o,f,h=[],u,p,m=[],x,_,c,g=!1,S=null,M=1,A=0,E=0;const v=[];function y(){s.canHabitat=i().habitats.length>0,e({...s})}function T(D,O){const k=new We(O),Q=D.getAttribute("position"),G=[];for(let K=0;K<Q.count;K++)G.push(k.r,k.g,k.b);return D.setAttribute("color",new qe(G,3)),v.push(D),D}function R(){a=Sc(),d=yc(a),l=U0(),o=new rt,o.add(d.root),n.add(o);const D=G=>new at(G,a.material);x=D(T(new gt(.78,.82,.035,24),"#dce8c2")),x.position.y=-.0175,o.add(x),_=D(T(new Ii(.16,20),"#bacd9e")),_.rotation.x=-Math.PI/2,_.scale.y=.6,_.position.set(0,.002,.025),o.add(_);const O=T(new gt(.035,.035,.48,10),"#9a7951");f=D(O),f.rotation.z=Math.PI/2,f.position.z=.025,o.add(f);const k=T(new gt(.022,.028,1,7),"#a88456");h=[D(k),D(k)],h.forEach((G,K)=>{G.position.x=K===0?-.2:.2,G.position.z=.025,o.add(G)}),u=D(T(new or([[0,.01],[.09,.01],[.13,.06],[.13,.085],[.103,.085],[.08,.03],[0,.03]].map(G=>new Be(...G)),14),"#bf8662")),u.position.set(0,.15,.62),o.add(u),c=D(T(new gt(.055,.075,.16,9),"#a88456")),c.position.set(0,.08,.62),o.add(c),p=D(T(new Ii(.089,16),"#53b4ce")),p.rotation.x=-Math.PI/2,p.position.set(0,.209,.62),o.add(p);const Q=T(new lr(.025,7,5),"#eb9d39");m=[D(Q),D(Q),D(Q)],m.forEach((G,K)=>{G.position.set((K-1)*.035,.213,.62+K%2*.025),o.add(G)}),E=a.inspect().macawTriangles,A=[...Object.values(a.geometries),...v].reduce((G,K)=>G+Object.values(K.attributes).reduce((j,ce)=>j+ce.array.byteLength,0)+(K.index?.array.byteLength??0),0)}function N(){const D={quarter:-.68,front:0,side:-Math.PI/2,back:Math.PI}[s.angle],O=Math.max(.9,.9/M);r.left=-O*M,r.right=O*M,r.top=O,r.bottom=-O,r.near=.01,r.far=20,r.position.set(Math.sin(D)*3,1.65,Math.cos(D)*3),r.lookAt(0,.62,.04),r.updateProjectionMatrix(),r.updateMatrixWorld(!0)}function z(D){if(!d||!o||!f||!u||!p||!x)return;d.apply(D);const O=l.inspect().timeMs/1e3,k=s.clip==="walk"?.22*Math.sin(O*.8):s.clip==="fly"?.12*Math.sin(O*.6):0;d.root.position.set(k,D.grip*.42,0),_&&(_.position.x=k),d.root.rotation.y=s.clip==="walk"?.2*Math.cos(O*.8):0;const Q=D.grip*.42;f.position.y=Q-.035,f.visible=Q>.09;for(const ce of h)ce.visible=Q>.09,ce.scale.y=Math.max(.001,Q-.035),ce.position.y=(Q-.035)/2;const G=s.clip==="eat"||s.clip==="drink";u.visible=G,c&&(c.visible=G),p.visible=s.clip==="drink",m.forEach(ce=>{ce.visible=s.clip==="eat"});const K=i(),j=K.habitats[0];if(s.habitat&&j){const ce=Math.min(...j.cells.map($=>$.x))+1-K.width/2,ve=Math.min(...j.cells.map($=>$.z))+1-K.height/2;o.scale.setScalar(wi),o.position.set(ce,.079,ve),x.visible=!1}else o.scale.setScalar(1),o.position.set(0,0,0),x.visible=!0;n.updateMatrixWorld(!0)}function q(){d?.dispose(),l?.dispose(),a?.dispose();for(const D of v)D.dispose();v.length=0,n.clear(),d=void 0,l=void 0,a=void 0,o=void 0,f=void 0,h=[],m=[],x=void 0,_=void 0,c=void 0,u=void 0,p=void 0,S=null}function C(D,O){if(!g){if(D==="close"){if(!s.active)return;q(),s={...s,active:!1,habitat:!1},n.visible=!1,y();return}if(D==="open"){if(s.active)return;R(),s={active:!0,habitat:!1,clip:"perch",angle:"quarter",motionPaused:t(),canHabitat:i().habitats.length>0},n.visible=!0}else if(s.active)if(D==="clip"){if(!to(O))return;s.clip=O,l.setClip(O,s.motionPaused)}else if(D==="angle"){if(!ml.includes(O))return;s.angle=O}else if(D==="pause")s.motionPaused=!s.motionPaused,S=null;else if(D==="habitat"){if(!i().habitats.length)return;s.habitat=!0}else D==="detail"&&(s.habitat=!1);else return;N(),z(l.pose()),y()}}return{group:n,camera:r,command:C,view:()=>({...s}),resize(D,O){D>0&&O>0&&(M=D/O,N())},setRunning(D){D||(S=null)},pauseForReducedMotion(){s.active&&!s.motionPaused&&(s.motionPaused=!0,S=null,y())},frame(D){if(!s.active||s.motionPaused||g)return;if(!Number.isFinite(D)||D<0)throw new RangeError("Invalid studio timestamp");const O=S===null?0:Math.max(0,D-S);S=S===null?D:Math.max(D,S),l.advance(O),z(l.pose())},dispose(){g||(q(),g=!0,s.active=!1,n.visible=!1)},inspect:()=>({macawStudioActive:s.active,macawStudioInHabitat:s.habitat,macawStudioMotionPaused:s.motionPaused,macawStudioDisposed:g,macawClipIndex:["perch","walk","hop","fly","eat","drink","rest"].indexOf(s.clip),macawAngleIndex:ml.indexOf(s.angle),macawAnimationTimeMs:l?.inspect().timeMs??0,macawStageGeometries:v.length,macawOwnedMaterialsLive:a?1:0,macawGeometryBytes:a?A:0,macawModelTriangles:E,...a?.inspect()??{macawAssetGeometries:0,macawMaterials:0,macawTextures:0},...d?.inspect()??{macawRigMeshes:0,macawRigDisposed:!0}})}}function B0(i){const e=new rt,t=new Mt,n=new Kt({vertexColors:!0,roughness:1}),r=new at(t,n),s={mesh:r,ranges:[]};e.name="Visitor path topology",r.name="Player paths",r.visible=!1,e.add(r),i.batches.push(s);let a=!1,d=0,l=0;return{group:e,geometry:t,material:n,sync(o){if(a)return;const f=Ws(o),h=new Set(f.reachable.map(ur)),u=new Yt;d=0;const p=(x,_,c,g,S)=>u.add(new Pt(1,1,1),x,[_,c,g],S);for(const x of o.tiles){const _=`tile-${x.cell.x}-${x.cell.z}`,c=i.identities.get(_);if(!c)continue;if(!x.path&&x.occupantId===null){c.kind=x.terrain,c.ordinal=0,delete c.connected;const M=i.bounds.get(_);M&&(M.max.y=.055)}if(x.path){c.kind="path",c.ordinal=0,c.connected=h.has(ur(x.cell));const M=i.bounds.get(_);M&&(M.max.y=.1)}if(!x.path||ur(x.cell)===ur(o.gate))continue;const g=x.cell.x+.5-o.width/2,S=x.cell.z+.5-o.height/2;u.owner=_,d++,p(c.connected?"#e3c78e":"#b9ac91",g,.055,S,[.95,.065,.95]);for(const M of[-.29,0,.29])p(c.connected?"#eed9ad":"#d1c5aa",g,.09,S+M,[.83,.008,.018])}for(const x of f.habitats){const _=i.identities.get(x.habitatId);if(_&&(_.connected=x.connected),!x.viewingCell)continue;const c=x.viewingCell,g=c.x+.5-o.width/2,S=c.z+.5-o.height/2;u.owner=`tile-${c.x}-${c.z}`,p("#497b69",g+.32,.22,S+.32,[.055,.27,.055]),p("#77ad87",g+.32,.35,S+.32,[.27,.13,.04])}const m=u.geometry();t.dispose(),t.copy(m),m.dispose(),s.ranges=u.ranges,r.visible=u.positions.length>0,e.updateMatrixWorld(!0),l++},dispose(){a||(a=!0,i.batches=i.batches.filter(o=>o!==s),e.clear())},inspect:()=>({pathSceneDisposed:a,pathMeshes:a||!r.visible?0:1,renderedPathTiles:a?0:d,pathSceneRevision:l})}}function gl(i,e){i&&!i.isContextLost()&&e()}function z0(i,e){const t=new rt;t.name="Constructed macaw habitat";let n=[],r=!1;const s=new at(new Mt,new Kt({vertexColors:!0,roughness:1})),a=new rs(new Mt,new sr({color:"#57735e",transparent:!0,opacity:.34,depthWrite:!1}));e(s.geometry,s.material),e(a.geometry,a.material);function d(){for(const o of n)i.identities.delete(o),i.bounds.delete(o);i.batches=i.batches.filter(o=>o.mesh!==s),n=[],t.clear(),s.geometry.dispose(),a.geometry.dispose()}function l(o){if(!r){n.length&&(!o.habitats.length||o.habitats[0].id!==n[0])&&d();for(const f of o.habitats){if(n.includes(f.id))continue;const h=n.length+1,u=Math.min(...f.cells.map(T=>T.x)),p=Math.min(...f.cells.map(T=>T.z)),m=u-o.width/2+1,x=p-o.height/2+1,_=new Yt;_.owner=f.id;const c=(T,R,N)=>_.add(new Pt(1,1,1),T,R,N);c("#b8c68c",[m,.055,x],[1.96,.045,1.96]);for(const T of[-1,1])c("#8c724d",[m+T*.96,.12,x],[.075,.12,1.98]),c("#8c724d",[m,.12,x+T*.96],[1.98,.12,.075]),c("#725c3e",[m+T*.96,1.12,x],[.065,.07,1.98]),c("#725c3e",[m,1.12,x+T*.96],[1.98,.07,.065]);for(const T of[-.96,0,.96])for(const R of[-.96,.96])c("#a17c4c",[m+T,.6,x+R],[.075,1.12,.075]);for(const T of[0])for(const R of[-.96,.96])c("#a17c4c",[m+R,.6,x+T],[.075,1.12,.075]);for(const T of[-.27,.27])c("#654c32",[m+T,.59,x+.96],[.04,1,.035]);for(const T of[.19,1.02])c("#654c32",[m,T,x+.96],[.58,.04,.035]);c("#e5bc65",[m+.18,.59,x+.982],[.07,.045,.025]);const g=s,S=_.geometry();g.geometry.dispose(),g.geometry.copy(S),S.dispose(),g.name=f.id,t.add(g),i.batches.push({mesh:g,ranges:_.ranges});const M=new bn(new F(m-1,.035,x-1),new F(m+1,1.18,x+1));i.identities.set(f.id,{id:f.id,category:"object",kind:"habitat",ordinal:h,cell:{x:u,z:p}}),i.bounds.set(f.id,M);for(const T of f.cells){const R=i.identities.get(`tile-${T.x}-${T.z}`);R&&(R.kind="habitat",R.ordinal=h)}const A=[],E=(T,R)=>A.push(...T,...R);for(let T=0;T<=8;T++){const R=-.94+T*1.88/8;for(const N of[-.94,.94])E([m+R,.19,x+N],[m+R,1.09,x+N]),E([m+N,.19,x+R],[m+N,1.09,x+R]);E([m+R,1.12,x-.94],[m+R,1.12,x+.94]),E([m-.94,1.12,x+R],[m+.94,1.12,x+R])}for(let T=0;T<=4;T++){const R=.19+T*.225;for(const N of[-.94,.94])E([m-.94,R,x+N],[m+.94,R,x+N]),E([m+N,R,x-.94],[m+N,R,x+.94])}const v=new Mt;v.setAttribute("position",new qe(A,3));const y=a;y.geometry.dispose(),y.geometry.copy(v),v.dispose(),y.name="Enclosing wire and roof",t.add(y),n.push(f.id),t.updateMatrixWorld(!0)}}}return{group:t,sync:l,dispose(){r||(r=!0,d())},inspect:()=>({habitatMeshes:r?0:n.length,habitatSceneDisposed:r})}}function Ec(i,e,t,n,r=new ja){if(![t.x,t.y,n.left,n.top,n.width,n.height].every(Number.isFinite)||n.width<=0||n.height<=0||t.x<n.left||t.x>n.left+n.width||t.y<n.top||t.y>n.top+n.height)return null;e.updateMatrixWorld(!0),r.setFromCamera(new Be((t.x-n.left)/n.width*2-1,1-(t.y-n.top)/n.height*2),e);const s=r.intersectObjects(i.batches.map(l=>l.mesh),!1)[0];if(!s||s.faceIndex===void 0)return null;const a=i.batches.find(l=>l.mesh===s.object)?.ranges.find(l=>s.faceIndex>=l.first&&s.faceIndex<l.first+l.count),d=a?.id?i.identities.get(a.id):void 0;return d?{...d,cell:{...d.cell}}:null}function k0(i,e,t,n){const r=new rt;r.name="Selection indicator",r.visible=!1;const s=new Ru(new bn,"#284d42"),a=Array.isArray(s.material)?s.material:[s.material];for(const m of a)m.depthTest=!1;s.renderOrder=21;const d=new at(new Fi(1,1),new Li({color:"#ffe4a0",transparent:!0,opacity:.28,side:vn,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-1,polygonOffsetUnits:-1}));d.rotation.x=-Math.PI/2,d.renderOrder=20,r.add(d,s);const l=new ja;let o=null,f=!0,h=!1,u=0;function p(m,x=!1){if(h||!x&&o?.id===m?.id&&o?.kind===m?.kind&&o?.connected===m?.connected)return;o=m,u++,r.visible=!!m;const _=m?i.bounds.get(m.id):void 0;if(_){s.box.copy(_).expandByScalar(.035),s.box.min.y=Math.max(.025,s.box.min.y);const c=_.getCenter(new F),g=_.getSize(new F);d.position.set(c.x,.07,c.z),d.scale.set(g.x+.07,g.z+.07,1),r.updateMatrixWorld(!0)}n(m?{...m,cell:{...m.cell}}:null)}return{group:r,geometries:[s.geometry,d.geometry],materials:[...a,d.material],pick(m){f&&!h&&p(Ec(i,e,m,t(),l))},selection:()=>o?structuredClone(o):null,clear(){p(null)},refresh(){if(o){const m=i.identities.get(o.id);p(m?{...m,cell:{...m.cell}}:null,!0)}},setEnabled(m){f=m},dispose(){h||(p(null),h=!0,r.visible=!1)},inspect:()=>({selectionActive:!!o,selectionRevision:u,selectionMarkerVisible:r.visible,selectionDisposed:h,selectableTiles:[...i.identities.values()].filter(m=>m.category==="tile").length,selectableObjects:[...i.identities.values()].filter(m=>m.category==="object").length})}}function G0(i,e,t,n,r,s,a){const d=i(),l=kc(),o=new rt;o.name="Habitat footprint planning";const f=new Pt(2,.22,2),h=new mu(f);f.dispose();const u=new Fi(.93,.93),p=new Li({color:"#23774e",transparent:!0,opacity:.34,depthWrite:!1}),m=new sr({color:"#176541",depthTest:!1}),x=new sr({color:"#226ca0",depthTest:!1}),_=new rt,c=new rs(h,m),g=new rs(h,x);c.renderOrder=24,g.renderOrder=23;const S=[];_.add(c);for(const[T,R]of[[-.5,-.5],[.5,-.5],[-.5,.5],[.5,.5]]){const N=new at(u,p);N.rotation.x=-Math.PI/2,N.position.set(T,-.07,R),N.renderOrder=22,S.push(N),_.add(N)}o.add(_,g),_.visible=!1,g.visible=!1;function M(T,R){T.position.set(R.anchor.x-d.width/2+R.width/2,.17,R.anchor.z-d.height/2+R.height/2)}const A=Gc(i,l,T=>{_.visible=T.active&&!!T.proposal,g.visible=!s&&!!T.confirmed,T.proposal&&(M(_,T.proposal),c.scale.set(T.proposal.width/2,1,T.proposal.height/2),S.forEach((R,N)=>{R.visible=T.kind!=="path"||N===0,T.kind==="path"?R.position.set(0,-.07,0):R.position.set(N%2===0?-.5:.5,-.07,N<2?-.5:.5)}),p.color.set(T.reason==="ready"?"#23774e":"#b32e33"),m.color.set(T.reason==="ready"?"#176541":"#a5222b")),T.confirmed&&(M(g,T.confirmed),g.scale.set(T.confirmed.width/2,1,T.confirmed.height/2)),o.updateMatrixWorld(!0),r(T)},s?{validate:(T,R,N)=>{const z=N==="path"?Oa(T,R):Sl(T,R);return z.reason==="ready"?{...z,reason:a?.(N)??"ready"}:z},commit:s}:{}),E=new ja,v=new In(new F(0,1,0),0),y=new F;return{group:o,geometries:[h,u],materials:[p,m,x],guide(T,R){A.cancel(),A.begin(T),A.choose(R)},command(T,R){T==="begin"?A.begin():T==="begin-path"?A.begin("path"):T==="confirm"?A.confirm(R??-1):T==="cancel"?A.cancel():A.move(T==="left"?-1:T==="right"?1:0,T==="up"?-1:T==="down"?1:0)},pick(T){const R=n();if(R.width<=0||R.height<=0)return;const N=Ec(e,t,T,R,E);if(N){A.choose(N.cell);return}t.updateMatrixWorld(!0),E.setFromCamera(new Be((T.x-R.left)/R.width*2-1,1-(T.y-R.top)/R.height*2),t),A.choose(E.ray.intersectPlane(v,y)?{x:Math.floor(y.x+d.width/2),z:Math.floor(y.z+d.height/2)}:null)},refresh:()=>A.refresh(),active:()=>A.snapshot().active,setEnabled:A.setEnabled,dispose:A.dispose,inspect:()=>({...A.inspect(),placementGhostVisible:_.visible,placementPlanVisible:g.visible,placementBlockedCells:l.size})}}function H0(i,e,t){const n=e.getCenter(new F);i.position.copy(n).add(new F(14,13,16)),i.lookAt(n),i.updateMatrixWorld(!0);let r=0,s=0;for(const a of[e.min.x,e.max.x])for(const d of[e.min.y,e.max.y])for(const l of[e.min.z,e.max.z]){const o=new F(a,d,l).applyMatrix4(i.matrixWorldInverse);r=Math.max(r,Math.abs(o.x)),s=Math.max(s,Math.abs(o.y))}return s=Math.max(s,r/Math.max(.01,t))*1.09,i.left=-s*t,i.right=s*t,i.top=s,i.bottom=-s,i.near=.1,i.far=100,i.updateProjectionMatrix(),{halfWidth:s*t,halfHeight:s}}const Yi=(i,e,t)=>Math.max(e,Math.min(t,i));function V0(i=()=>{}){let e,t=1,n=0,r=0;function s(){if(!e)return{minX:0,maxX:0,minZ:0,maxZ:0};const o=1-1/t,f=e;return{minX:(-f.mapWidth/2+.6-f.originX)*o,maxX:(f.mapWidth/2-.6-f.originX)*o,minZ:(-f.mapHeight/2+.6-f.originZ)*o,maxZ:(f.mapHeight/2-.6-f.originZ)*o}}function a(){const o=s();n=Yi(n,o.minX,o.maxX),r=Yi(r,o.minZ,o.maxZ),i()}function d(o,f){const h=e,u=h.rightX*h.upZ-h.rightZ*h.upX;return{x:(o*h.upZ-h.rightZ*f)/u,z:(h.rightX*f-o*h.upX)/u}}function l(o,f=0,h=0){if(!e||!Number.isFinite(o)||o<=0||![f,h].every(Number.isFinite))return;const u=Yi(t*o,1,3),p=1/t-1/u,m=d(Yi(f,-1,1)*e.halfWidth*p,Yi(h,-1,1)*e.halfHeight*p);n+=m.x,r+=m.z,t=u,a()}return{configure(o){if(!Object.values(o).every(Number.isFinite)||o.width<=0||o.height<=0||o.halfWidth<=0||o.halfHeight<=0||o.mapWidth<=2||o.mapHeight<=2||Math.abs(o.originX)>o.mapWidth/2-.6||Math.abs(o.originZ)>o.mapHeight/2-.6||Math.abs(o.rightX*o.upZ-o.rightZ*o.upX)<.01)throw new RangeError("Invalid camera frame");e={...o},a()},panPixels(o,f){if(!e||![o,f].every(Number.isFinite))return;const h=d(-o*2*e.halfWidth/(t*e.width),f*2*e.halfHeight/(t*e.height));n+=h.x,r+=h.z,a()},focus(o){!e||![o.x,o.z].every(Number.isFinite)||(t=2.5,n=o.x-e.originX,r=o.z-e.originZ,a())},zoomBy:l,command(o){o==="reset"?(t=1,n=r=0,a()):l(o==="zoom-in"?1.25:.8)},inspect:()=>({zoom:t,x:n,z:r,focusX:(e?.originX??0)+n,focusZ:(e?.originZ??0)+r,...s()})}}function W0(i,e,t){const n=new Map;let r;const s=l=>Number.isInteger(l.id)&&l.id>=0&&Number.isFinite(l.x)&&Number.isFinite(l.y);function a(){const[l,o]=[...n.values()];return{x:(l.x+o.x)/2,y:(l.y+o.y)/2,distance:Math.hypot(l.x-o.x,l.y-o.y)}}function d(l,o){const f=n.get(l);if(f&&(n.delete(l),!o&&!f.dragged&&t?.({id:f.id,x:f.x,y:f.y}),r)){r=void 0;for(const h of n.values())h.dragged=!0,h.startX=h.x,h.startY=h.y}}return{down(l){if(!s(l)||n.has(l.id)||n.size>=2)return!1;if(n.set(l.id,{...l,startX:l.x,startY:l.y,dragged:!1}),n.size===2){for(const o of n.values())o.dragged=!0;r=a()}return!0},move(l){const o=n.get(l.id);if(!o||!s(l))return;const f={x:o.x,y:o.y};if(o.x=l.x,o.y=l.y,n.size===2){const h=a(),u=r;r=h;const p=e();i.panPixels(h.x-u.x,h.y-u.y),u.distance>6&&h.distance>6&&p.width>0&&p.height>0&&i.zoomBy(h.distance/u.distance,(h.x-p.left)/p.width*2-1,1-(h.y-p.top)/p.height*2)}else{if(!o.dragged&&Math.hypot(l.x-o.startX,l.y-o.startY)<6)return;i.panPixels(l.x-(o.dragged?f.x:o.startX),l.y-(o.dragged?f.y:o.startY)),o.dragged=!0}},up(l){s(l)&&(this.move(l),d(l.id,!1))},cancel:l=>d(l,!0),cancelAll(){n.clear(),r=void 0},ids:()=>[...n.keys()],inspect:()=>({pointers:n.size,pinching:n.size===2})}}function X0(i,e,t,n,r,s,a){let d=!1,l=!0;const o=new AbortController;let f=new F;const h=V0(()=>{if(d)return;const c=h.inspect();t.position.copy(f).add(new F(c.x,0,c.z)),t.zoom=c.zoom,t.updateProjectionMatrix(),t.updateMatrixWorld(!0),i.dataset.cameraZoom=String(c.zoom),i.dataset.cameraPanX=String(c.x),i.dataset.cameraPanZ=String(c.z),i.dispatchEvent(new CustomEvent("camera-view-change",{detail:{zoom:c.zoom},bubbles:!1}))}),u=W0(h,()=>e.getBoundingClientRect(),s);function p(c){try{e.hasPointerCapture(c)&&e.releasePointerCapture(c)}catch{}}function m(){const c=u.ids();u.cancelAll();for(const g of c)p(g);e.style.cursor="grab"}const x=c=>({id:c.pointerId,x:c.clientX,y:c.clientY});e.style.touchAction="none",e.style.cursor="grab",e.addEventListener("pointerdown",c=>{if(!(!l||d||c.button!==0||!u.down(x(c)))){c.preventDefault(),i.focus({preventScroll:!0}),e.style.cursor="grabbing";try{e.setPointerCapture(c.pointerId)}catch{}}},{signal:o.signal}),e.addEventListener("pointermove",c=>{if(!(!l||d||!u.ids().includes(c.pointerId))){if(c.pointerType==="mouse"&&(c.buttons&1)===0){m();return}c.preventDefault(),u.move(x(c))}},{signal:o.signal});function _(c){d||(u.up(x(c)),p(c.pointerId),u.inspect().pointers||(e.style.cursor="grab"))}e.addEventListener("pointerup",_,{signal:o.signal}),window.addEventListener("pointerup",_,{signal:o.signal});for(const c of["pointercancel","lostpointercapture"])e.addEventListener(c,g=>{u.cancel(g.pointerId),p(g.pointerId),u.inspect().pointers||(e.style.cursor="grab")},{signal:o.signal});return e.addEventListener("wheel",c=>{if(!l||d||!Number.isFinite(c.deltaY))return;c.preventDefault(),m();const g=e.getBoundingClientRect(),S=c.deltaY*(c.deltaMode===1?16:c.deltaMode===2?g.height:1);h.zoomBy(Math.exp(-Math.max(-300,Math.min(300,S))*.0025),(c.clientX-g.left)/g.width*2-1,1-(c.clientY-g.top)/g.height*2)},{signal:o.signal,passive:!1}),i.addEventListener("keydown",c=>{if(!l||d||c.target!==i||c.ctrlKey||c.metaKey||c.altKey)return;const g=c.key;if(!["ArrowLeft","ArrowRight","ArrowUp","ArrowDown","+","=","-","_","Home","Escape","Enter"," "].includes(g))return;c.preventDefault(),m();const S=c.shiftKey?80:40;if(g.startsWith("Arrow"))h.panPixels(g==="ArrowLeft"?S:g==="ArrowRight"?-S:0,g==="ArrowUp"?S:g==="ArrowDown"?-S:0);else if(g==="Home")h.command("reset");else if(g==="Escape")a?.();else if(g==="Enter"||g===" "){if(!c.repeat){const M=e.getBoundingClientRect();s?.({id:0,x:M.left+M.width/2,y:M.top+M.height/2})}}else h.command(g==="+"||g==="="?"zoom-in":"zoom-out")},{signal:o.signal}),window.addEventListener("blur",m,{signal:o.signal}),{resize(c,g){if(d)return;m();const S=H0(t,n,c/g);f=t.position.clone();const M=new F(1,0,0).applyQuaternion(t.quaternion),A=new F(0,1,0).applyQuaternion(t.quaternion),E=n.getCenter(new F);h.configure({width:c,height:g,halfWidth:S.halfWidth,halfHeight:S.halfHeight,rightX:M.x,rightZ:M.z,upX:A.x,upZ:A.z,originX:E.x-14*E.y/13,originZ:E.z-16*E.y/13,mapWidth:r.width,mapHeight:r.height})},focus(c){l&&!d&&(m(),h.focus(c))},command(c){l&&!d&&(m(),h.command(c))},setEnabled(c){l=c,l||m()},dispose(){d||(m(),d=!0,o.abort(),delete i.dataset.cameraZoom,delete i.dataset.cameraPanX,delete i.dataset.cameraPanZ)},inspect:()=>{const c=h.inspect();return{cameraControlsDisposed:d,cameraInputEnabled:l&&!d,cameraZoom:c.zoom,cameraPanX:c.x,cameraPanZ:c.z,cameraFocusX:c.focusX,cameraFocusZ:c.focusZ,cameraMinPanX:c.minX,cameraMaxPanX:c.maxX,cameraMinPanZ:c.minZ,cameraMaxPanZ:c.maxZ,cameraPointers:u.inspect().pointers,cameraPinching:u.inspect().pinching}}}}function q0(i){const e=Ws(i.world),t=i.world.habitats.length>0,n=e.habitats.some(h=>h.connected),r=yl.Q01.coins;let s="habitat",a="habitat",d=null,l=0,o=pt.habitat,f="none";if(i.missions.completedIds.includes("Q01")){s="done",a=null,o=0;const h=i.world.habitats[0];d=h?{x:h.cells.reduce((u,p)=>u+p.x,0)/h.cells.length,z:h.cells.reduce((u,p)=>u+p.z,0)/h.cells.length}:null}else if(n)s="claim",a=null,o=0;else if(t){s="path",a="path",o=pt.path;const h=structuredClone(i.world);for(const m of h.tiles)Oa(h,m.cell).reason==="ready"&&(m.path=!0);const u=Ws(h).habitats.find(m=>m.connected)?.route??[],p=u.filter(m=>!i.world.tiles.find(x=>x.cell.x===m.x&&x.cell.z===m.z)?.path);l=p.length,d=p[0]??null,d||(s="blocked",a=null,o=0,f="access")}else{const h={x:Math.floor(i.world.width/2)-2,z:Math.floor(i.world.height/2)-1};d=i.world.tiles.map(u=>u.cell).filter(u=>Sl(i.world,u).reason==="ready").sort((u,p)=>Math.abs(u.x-h.x)+Math.abs(u.z-h.z)-Math.abs(p.x-h.x)-Math.abs(p.z-h.z)||u.z-p.z||u.x-p.x)[0]??null,d||(s="blocked",a=null,o=0,f="space")}return{stage:s,kind:a,target:d?{...d}:null,remaining:l,cost:o,coins:i.currency,affordable:i.currency>=o,reward:r,habitat:t,connected:n,reason:f}}function Y0(i,e){return bl(i,e)!==null}function xn(i,e){const t=bl(i.ledger,i.economy.checkpoint);return t?[...t.purchases.values()].filter(n=>n.entry.relatedId===e&&-n.entry.amount>n.refunded).map(n=>({paidId:n.entry.id,amount:-n.entry.amount-n.refunded})):[]}function $i(i,e,t){if(!/^(edit-[a-f0-9]{32}|care-remove-(food|water|perch)-[0-9]+)$/.test(e))return null;let n=i.currency;const r=[];for(const[a,d]of t.entries()){n+=d.amount;const l=`cmd-${i.economy.nextCommand}-${a}`;if(!Number.isSafeInteger(n)||n<0||i.ledger.some(o=>o.id===l||o.operationId===l))return null;r.push({id:l,operationId:l,...d,balanceAfter:n,tick:i.tick})}const s=[...i.ledger,...r];return Y0(s,i.economy.checkpoint)?{currency:n,ledger:s,entries:r}:null}const wc=i=>i.kind==="habitat"?i.id:`path-${i.cell.x}-${i.cell.z}`;function Fa(i,e,t){if(e.kind==="habitat"){if(!i.world.habitats.some(n=>n.id===e.id))return{ok:!1,reason:"missing"};if(i.animals.some(n=>n.habitatId===e.id)||i.world.resources.some(n=>n.habitatId===e.id)||i.visitors.some(n=>!n.arrival))return{ok:!1,reason:"in-use"}}else{const n=e.cell,r=i.world.tiles.find(a=>a.cell.x===n.x&&a.cell.z===n.z);if(n.x===i.world.gate.x&&n.z===i.world.gate.z)return{ok:!1,reason:"protected"};if(!r?.path)return{ok:!1,reason:"missing"};const s=Hc(i,Tc(i.world,e),n);if(s)return{ok:!1,reason:s}}return{ok:!0,quote:{revision:t,command:i.economy.nextCommand,target:structuredClone(e),refund:xn(i,wc(e)).reduce((n,r)=>n+r.amount,0)}}}function Tc(i,e){const t=structuredClone(i);if(e.kind==="habitat"){t.habitats=t.habitats.filter(n=>n.id!==e.id);for(const n of t.tiles)n.occupantId===e.id&&(n.occupantId=null)}else{const n=t.tiles.find(r=>r.cell.x===e.cell.x&&r.cell.z===e.cell.z);n&&(n.path=!1)}return t}const _l=(i,e)=>JSON.stringify(i)===JSON.stringify(e),si=Object.freeze({lowCoins:100,rationBudget:12,urgentAt:60,rationCooldownTicks:300,portionsPerBird:2}),Vs=new WeakMap;function $0(i){if(Vs.has(i.world))return structuredClone(Vs.get(i.world));let e=null;for(let t=0;t<i.world.height-1;t++)for(let n=0;n<i.world.width-1;n++){const r=structuredClone(i.world),s=[];for(const a of r.tiles)a.path&&a.cell.x>=n&&a.cell.x<=n+1&&a.cell.z>=t&&a.cell.z<=t+1&&(s.push({...a.cell}),a.path=!1);s.some(a=>a.x===r.gate.x&&a.z===r.gate.z)||Ba(r,{x:n,z:t},"habitat-support-plan").ok&&(s.some(a=>!Fa(i,{kind:"path",cell:a},0).ok)||(!e||s.length<e.remove.length)&&(e={anchor:{x:n,z:t},remove:s}))}return Vs.set(i.world,structuredClone(e)),e}const vl=new WeakMap;function xl(i){const e=vl.get(i.world);if(e)return e;const t=structuredClone(i.world);for(const s of t.tiles)Oa(t,s.cell).reason==="ready"&&(s.path=!0);const n=Al(t)?.route??[],r=n.filter(s=>!i.world.tiles.find(a=>a.cell.x===s.x&&a.cell.z===s.z)?.path).map(s=>({...s}));return vl.set(i.world,r),r}function Ml(i){let e="steady",t=0,n=!1,r=null,s=0,a=0,d=!0;const l=i.world.habitats[0],o=i.economy.recovery,f=El(i),h=wl(i),u=Tl(i),p=i.animals.filter(S=>S.habitatId===l?.id&&S.position),m=S=>{const M=S==="food"?f:h;return p.some(A=>(S==="food"?A.hunger:A.thirst)>=si.urgentAt&&M.portions[[...i.animals].sort((E,v)=>E.id.localeCompare(v.id)).findIndex(E=>E.id===A.id)]===0)},x=o.lastRationTick===null?0:Math.max(0,si.rationCooldownTicks-(i.tick-o.lastRationTick));if(l)if(f.exists&&!f.reachable)e="repair-food";else if(h.exists&&!h.reachable)e="repair-water";else if(!f.exists)e="food",t=pt.food,d=f.canPlace;else if(!h.exists)e="water",t=pt.water,d=h.canPlace;else if(i.currency<si.rationBudget&&(m("food")||m("water")))e="rations",a=x,d=x===0;else if(f.stock<4&&i.currency>=pt.foodRefill)e="food-refill",t=pt.foodRefill;else if(h.stock<4&&i.currency>=pt.waterRefill)e="water-refill",t=pt.waterRefill;else if(!u.exists)e="perch",t=pt.perch,d=u.canPlace;else if(!u.reachable)e="repair-perch";else if(Al(i.world))p.length<2?e="welcome":i.visitorFlow.open?(e="steady",d=!1):e="open";else{const S=xl(i)[0];S?(e="path",r={...S},t=pt.path):(e="wait",d=!1)}else{const S=$0(i);S?S.remove.length?(e="reclaim",r=S.remove[0],s=xn(i,`path-${r.x}-${r.z}`).reduce((M,A)=>M+A.amount,0)):(e="habitat",r=S.anchor,t=pt.habitat):(e="wait",d=!1)}if(["repair-food","repair-water","repair-perch"].includes(e)){const S=e.slice(7),M=i.world.resources.find(A=>A.kind===S);s=M?xn(i,M.id).reduce((A,E)=>A+E.amount,0):0}n=["habitat","path","food","water","perch"].includes(e)&&i.currency<t;const _=(l?0:pt.habitat)+(f.exists?0:pt.food)+(h.exists?0:pt.water)+(u.exists?0:pt.perch)+(l?xl(i).length:5)*pt.path+si.rationBudget,c=i.currency<Math.max(si.lowCoins,_,t+si.rationBudget),g=[e,r?.x??"-",r?.z??"-",t,n?1:0].join(":");return{command:i.economy.nextCommand,key:g,kind:e,low:c,available:d&&e!=="steady",cost:n?0:t,gift:n,refund:s,cell:r,waitTicks:a,grants:o.equipmentGrants,rations:o.rationBatches}}function Z0(i,e){const t=i.economy.nextCommand;if(e.kind==="habitat"&&e.cell&&e.gift){const n=Ba(i.world,e.cell,`habitat-support-${t}`);if(!n.ok||n.duplicate)return!1;i.world=n.world,i.economy.recovery.habitatGrant={id:n.habitatId,tick:i.tick}}else if(["food","water","perch"].includes(e.kind)&&e.gift){const n=e.kind;if((n==="food"?Cl:n==="water"?Pl:Ll)(i,"place",0,t)!=="ok")return!1;const s=i.world.resources.find(a=>a.kind===n);if(xn(i,s.id).length)return!1}else if(e.kind==="rations"){for(const n of["food","water"]){const r=i.world.resources.find(s=>s.kind===n);if(!r?.portions)return!1;r.portions=r.portions.map(s=>Math.max(s,si.portionsPerBird)),r.stock=r.portions[0]+r.portions[1],r.revision=t}return i.economy.recovery.lastRationTick=i.tick,i.economy.recovery.rationBatches++,i.economy.nextCommand++,!0}else return e.kind==="welcome"?Rl(i)?(i.economy.nextCommand++,!0):!1:e.kind==="open"?(i.visitorFlow.open=!0,i.visitorFlow.cooldownTicks=0,i.economy.nextCommand++,!0):!1;return i.economy.recovery.equipmentGrants++,i.economy.nextCommand++,!0}function no(i,e){return!Number.isSafeInteger(e)||e<0||i.currency<e?"funds":null}function Ti(i,e,t,n,r){t!=="maintenance"&&(n=`cmd-${i.economy.nextCommand}`);const s=i.ledger.find(l=>l.operationId===n);if(s)return s.kind===t&&s.amount===-e&&s.relatedId===r?"duplicate":"capacity";const a=no(i,e);if(a)return a;if(!Number.isSafeInteger(e)||e<=0||!/^[a-z][a-z0-9-]{0,47}$/.test(n))return"funds";const d={id:n,operationId:n,kind:t,amount:-e,balanceAfter:i.currency-e,tick:i.tick,relatedId:r};return i.currency=d.balanceAfter,i.ledger.push(d),null}function Ac(i){return Math.max(0,Math.floor(i.tick/za.maintenanceTicks)-i.economy.maintenancePeriod)*i.world.habitats.length*pt.maintenance}function K0(i){const e=Math.floor(i.tick/za.maintenanceTicks);if(e<=i.economy.maintenancePeriod)return!1;const t=Ac(i);return t&&Ti(i,t,"maintenance",`maintenance-${e}`,null)!==null?!1:(i.economy.maintenancePeriod=e,!0)}function Zi(i){const e=Ac(i),t=Xs(i),n=t.amounts;return{resourceRefunds:Object.fromEntries(["food","water","perch"].map(r=>{const s=i.world.resources.find(a=>a.kind===r);return[r,s?xn(i,s.id).reduce((a,d)=>a+d.amount,0):0]})),grants:n.starter+n.reward,balance:i.currency,prices:pt,journalRetained:i.ledger.length,journalCompactions:i.economy.checkpoint.compactions,transactions:t.entries,maintenanceDue:e,maintenanceReason:e?no(i,e):null,maintenancePeriod:i.economy.maintenancePeriod,spent:-n.build-n.supplies-n.maintenance-n.restore,refunds:n.refund,construction:0-n.build,supplies:0-n.supplies,upkeep:0-n.maintenance,undo:0-n.restore,ticketIncome:n.ticket,rewards:n.reward,net:n.ticket+n.reward+n.refund+n.build+n.supplies+n.maintenance+n.restore,operatingNet:n.ticket+n.supplies+n.maintenance}}function J0(){const i=new Set;let e=!1,t=0;return{subscribe(n){return e||i.add(n),()=>{i.delete(n)}},emit(n){if(!e){for(const r of[...i])if(i.has(r))try{r(n)}catch{t++}}},dispose(){e=!0,i.clear()},inspect:()=>({subscribers:i.size,listenerErrors:t,disposed:e})}}const Q0=250,j0=3,eg=25;function tg(i,e=1){if(e!==1&&e!==10)throw new RangeError("Invalid simulation speed");let t=0,n=!1,r=!1,s=0,a=0,d=e,l=0;const o=(f,h)=>{s=Math.min(Number.MAX_SAFE_INTEGER,s+f),a=Math.min(Number.MAX_SAFE_INTEGER,a+h)};return{advance(f){if(!Number.isFinite(f)||f<0||f>Number.MAX_SAFE_INTEGER)throw new RangeError("Invalid frame duration");if(l=0,r||n)return 0;const h=Math.min(f,Q0);o(f-h,(f-h)*d),t+=h*d;const u=d===10?eg:j0;for(;t+1e-7>=bi&&l<u;)i(),t=Math.max(0,t-bi),l++;if(t>=bi){const p=Math.floor(t/bi)*bi;t-=p,o(p/d,p)}return l},setSpeed(f){if(f!==1&&f!==10)throw new RangeError("Invalid simulation speed");return r||d===f?!1:(d=f,!0)},setPaused(f){n!==f&&(t=0),n=f},reset(){t=0,s=0,a=0,l=0},dispose(){r=!0,t=0,l=0},inspect:()=>({accumulatorMs:t,paused:n,disposed:r,droppedMs:s,droppedSimulationMs:a,speed:d,lastAdvanceSteps:l})}}function ng(i){if(!Number.isInteger(i)||i<1||i>4294967295)throw new RangeError("Invalid RNG state");let e=i|0;e^=e<<13,e^=e>>>17,e^=e<<5;const t=e>>>0;return{state:t,value:t/4294967296}}function ig(i=Yc(),e){const t=tn(i);if(!t.ok)throw new Error(`Invalid initial state at ${t.path}`);const n=ei(t.value.world),r={...t.value,world:n.world};let s=n.topology,a=nn(structuredClone(r));ds(a);let d={revision:0,undo:null};e&&Number.isSafeInteger(e.revision)&&e.revision>=0&&e.revision<Number.MAX_SAFE_INTEGER&&(d=structuredClone(e),d.undo&&!_l(d.undo.after,a.world)&&(d.undo=null));const l=()=>{d={revision:d.revision+1,undo:null}},o=c=>Number.isSafeInteger(a.economy.nextCommand)&&a.economy.nextCommand<Number.MAX_SAFE_INTEGER&&(c===a.economy.nextCommand||c===void 0&&a.economy.checkpoint.entries===0),f=()=>{if(a.ledger.length<za.journalEntries)return;const c=structuredClone(a);$c(c,d.undo?.refundIds??[]);const g=tn(c);if(!g.ok)throw new Error(`Invalid financial checkpoint at ${g.path}`);a=g.value};f();let h=!1,u=null;const p=J0(),m=c=>{ds(a,c.type==="tick"),p.emit(c)},x=tg(()=>{if(a.tick>=Vc)throw new RangeError("Simulation tick limit reached");a.tick++,a.gameTimeMs=a.tick*bi,K0(a)&&(f(),m(Object.freeze({type:"economy-changed",tick:a.tick,gameTimeMs:a.gameTimeMs})));const c=ng(a.randomState);a.randomState=c.state;const{fed:g,watered:S}=Wc(a);nn(a);for(const v of S)m(Object.freeze({type:"animal-drank",...v,tick:a.tick,gameTimeMs:a.gameTimeMs}));for(const v of g)m(Object.freeze({type:"animal-fed",...v,tick:a.tick,gameTimeMs:a.gameTimeMs}));const M=a.admissions.length,A=Xc(a),E=a.admissions.slice(M).map(v=>({visitorId:v.visitorId,admissionId:v.id,amount:us(a,v.ledgerEntryId).amount}));ds(a),qc(a),f();for(const v of A)m(Object.freeze({type:"visitor-viewed",...v,tick:a.tick,gameTimeMs:a.gameTimeMs}));for(const v of E)m(Object.freeze({type:"visitor-admitted",...v,tick:a.tick,gameTimeMs:a.gameTimeMs}));m(Object.freeze({type:"tick",tick:a.tick,gameTimeMs:a.gameTimeMs,randomSample:c.value}))},a.preferences.speed),_={advance:c=>x.advance(c),frame(c){if(!Number.isFinite(c)||c<0)throw new RangeError("Invalid frame timestamp");if(h||x.inspect().paused)return 0;const g=u;return u=g===null?c:Math.max(g,c),x.advance(g===null?0:Math.max(0,c-g))},setSpeed(c){return h||c!==1&&c!==10||x.inspect().speed===c?!1:(a.preferences.speed=c,x.setSpeed(c),u=null,m(Object.freeze({type:"speed-changed",speed:c,tick:a.tick,gameTimeMs:a.gameTimeMs})),!0)},setMuted(c){return h||typeof c!="boolean"||a.preferences.muted===c?!1:(a.preferences.muted=c,m(Object.freeze({type:"preferences-changed",tick:a.tick,gameTimeMs:a.gameTimeMs})),!0)},visualSettings:()=>({graphics:a.preferences.graphics,reducedMotion:a.preferences.reducedMotion}),setVisualSettings(c){return h||!nd(c)||a.preferences.graphics===c.graphics&&a.preferences.reducedMotion===c.reducedMotion?!1:(a.preferences.graphics=c.graphics,a.preferences.reducedMotion=c.reducedMotion,m(Object.freeze({type:"preferences-changed",tick:a.tick,gameTimeMs:a.gameTimeMs})),!0)},setLocale(c){return h||c!=="en"&&c!=="id"||a.preferences.locale===c?!1:(a.preferences.locale=c,m(Object.freeze({type:"preferences-changed",tick:a.tick,gameTimeMs:a.gameTimeMs})),!0)},onboardingView:()=>q0(a),missionView:()=>td(a),claimMission(c){if(h||x.inspect().paused||!o(c?.command))return{ok:!1,reason:"stale"};const g=structuredClone(a),S=ed(g,c);if(S)return{ok:!1,reason:S};const M=tn(g);return M.ok?(a=M.value,f(),m(Object.freeze({type:"mission-claimed",missionId:c.id,amount:yl[c.id].coins,tick:a.tick,gameTimeMs:a.gameTimeMs})),{ok:!0}):{ok:!1,reason:"stale"}},recoveryView:()=>Ml(a),recover(c){if(h||x.inspect().paused||!o(c.command))return!1;const g=Ml(a);if(!g.low||!g.available||g.key!==c.key)return!1;if(g.kind==="reclaim"&&g.cell){const E=_.quoteRemoval({kind:"path",cell:g.cell});return E.ok&&_.remove(E.quote,`edit-${a.economy.nextCommand.toString(16).padStart(32,"0")}`).ok}if(g.kind.startsWith("repair-")){const E=g.kind.slice(7),v=a.world.resources.find(y=>y.kind===E);return!!(v&&_[E]("remove",v.revision,g.command).ok)}if(!g.gift&&g.kind!=="rations"&&g.kind!=="open"&&g.kind!=="welcome"){if(g.kind==="habitat"&&g.cell)return _.buildHabitat(g.cell,`habitat-guided-${g.command}`,g.command).ok;if(g.kind==="path"&&g.cell)return _.buildPath(g.cell,g.command).ok;if(g.kind==="food-refill"||g.kind==="water-refill"){const E=g.kind==="food-refill"?"food":"water";return _[E]("refill",_[E+"View"]().revision,g.command).ok}return g.kind==="food"||g.kind==="water"||g.kind==="perch"?_[g.kind]("place",0,g.command).ok:!1}const S=structuredClone(a);if(g.kind==="path"&&g.cell&&g.gift){const E=co(S.world,g.cell);if(!E.ok||E.duplicate||xn(S,`path-${g.cell.x}-${g.cell.z}`).length)return!1;S.world=E.world,S.economy.nextCommand++,S.economy.recovery.equipmentGrants++}else if(!Z0(S,g))return!1;const M=ei(S.world),A=tn(nn(ki({...S,world:M.world})));return A.ok?(a=A.value,s=M.topology,l(),f(),m(Object.freeze({type:"recovery-changed",tick:a.tick,gameTimeMs:a.gameTimeMs})),!0):!1},commandRevision:()=>a.economy.nextCommand,buildHabitat(c,g,S){if(h||x.inspect().paused||!o(S))return{ok:!1,reason:"command"};const M=Ba(a.world,c,g);if(!M.ok)return M;if(!M.duplicate){const A=structuredClone(a),E=Ti(A,pt.habitat,"build",`buy-${g.slice(8)}`,M.habitatId);if(E)return{ok:!1,reason:E==="duplicate"?"command":E};A.economy.nextCommand++;const v=ei(M.world),y=tn(ki({...A,world:v.world}));if(!y.ok)return{ok:!1,reason:"command"};a=nn(y.value),s=v.topology,l(),f(),m(Object.freeze({type:"habitat-built",habitatId:M.habitatId,tick:a.tick,gameTimeMs:a.gameTimeMs}))}return{ok:!0,habitatId:M.habitatId,duplicate:M.duplicate}},buildPath(c,g){if(h||x.inspect().paused||!o(g))return{ok:!1,reason:"command"};const S=co(a.world,c);if(!S.ok)return S;if(!S.duplicate){const M=structuredClone(a),A=Ti(M,pt.path,"build",`buy-path-${c.x}-${c.z}-${a.ledger.length}`,`path-${c.x}-${c.z}`);if(A)return{ok:!1,reason:A==="duplicate"?"command":A};M.economy.nextCommand++;const E=ei(S.world),v=tn(ki({...M,world:E.world}));if(!v.ok)return{ok:!1,reason:"command"};a=nn(v.value),s=E.topology,l(),f(),m(Object.freeze({type:"path-built",cell:{...c},tick:a.tick,gameTimeMs:a.gameTimeMs}))}return{ok:!0,duplicate:S.duplicate}},visitors(c){return h||x.inspect().paused||typeof c!="boolean"||a.visitorFlow.open===c||c&&jc(a)!==null?!1:(a.visitorFlow.open=c,a.visitorFlow.cooldownTicks=0,m(Object.freeze({type:"visitor-entrance-changed",tick:a.tick,gameTimeMs:a.gameTimeMs})),!0)},visitorView:()=>Qc(a),visitorInspect:()=>({...(()=>{const c=a.visitors.find(g=>g.journey?.startedTick!==null&&g.journey?.startedTick!==void 0);return{attractionWelfare:fs(a).welfare??-1,attractionInterval:fs(a).intervalTicks,attractionReady:fs(a).ready?1:0,visitorWalkerSerial:c?.arrival?.serial??0,visitorWalkerX:c?.position.x??-1,visitorWalkerZ:c?.position.z??-1,visitorWalkerHeading:c?.journey?.heading??0,visitorWalkerRouteIndex:c?.routeIndex??-1,visitorEvaluated:a.visitorFlow.feedback.evaluated,visitorScored:a.visitorFlow.feedback.scored,visitorScoreSum:a.visitorFlow.feedback.scoreSum,visitorPositive:a.visitorFlow.feedback.positive,visitorNegative:a.visitorFlow.feedback.negative,visitorInterrupted:a.visitorFlow.feedback.interrupted,visitorObservationSamples:c?.experience?.samples??0,visitorObservationOccupied:c?.experience?.occupiedSamples??0,visitorObservationSum:c?.experience?.welfareHundredths??0,ticketAdmissions:lo(a).admissions,ticketRevenue:lo(a).revenue,ticketLedgerEntries:Xs(a).counts.ticket,ticketPrice:Jc.price,ticketWalkerPaid:c?.entry?.status==="paid"?1:0,ticketWalkerEntryTick:c?.entry?.tick??-1}})(),...Object.fromEntries([0,1,2].flatMap(c=>{const g=a.visitors.find(A=>A.arrival?.slot===c),S=g?.arrival,M=`visitor${c+1}`;return[[`${M}Serial`,S?.serial??0],[`${M}Age`,S?a.tick-S.spawnTick:0],[`${M}X`,g?.position.x??-1],[`${M}Z`,g?.position.z??-1]]}))}),visitorFocus:()=>{const c=a.visitors.find(g=>g.journey?.startedTick!==null&&g.journey?.startedTick!==void 0)??a.visitors[0];return c?{...c.position}:null},visitorSnapshot:()=>({visitors:structuredClone(a.visitors),width:a.world.width,height:a.world.height,tick:a.tick,gate:{...a.world.gate}}),birdInspect:()=>Object.fromEntries([...a.animals].sort((c,g)=>c.id.localeCompare(g.id)).flatMap((c,g)=>{const S=`bird${g+1}`;return[[`${S}X`,c.position?.x??-1],[`${S}Z`,c.position?.z??-1],[`${S}Height`,c.motion.elevation],[`${S}Phase`,["idle","walk-out","look","walk-home","ascend","perch","descend","seek-food","eat","leave-food","seek-water","drink","water-back","water-hop","leave-water","water-home","water-abort","seek-rest","rest","enrich"].indexOf(c.motion.phase)],[`${S}Sequence`,c.motion.sequence],[`${S}Welfare`,c.welfare],[`${S}HabitatFit`,c.habitatFit],[`${S}WelfareLow`,c.care.low?1:0],[`${S}Hunger`,c.hunger],[`${S}FoodEaten`,c.foodEaten],[`${S}Thirst`,c.thirst],[`${S}WaterDrunk`,c.waterDrunk],[`${S}Energy`,c.energy],[`${S}Enrichment`,c.enrichment],[`${S}RestedTicks`,c.restedTicks],[`${S}EnrichedTicks`,c.enrichedTicks]]})),birdSnapshot:()=>({animals:structuredClone(a.animals),habitats:structuredClone(a.world.habitats),width:a.world.width,height:a.world.height}),perchView:()=>Tl(a),perch(c,g,S){if(h||x.inspect().paused||!o(S)||!Number.isSafeInteger(g)||g<0)return{ok:!1,reason:"invalid"};const M=structuredClone(a),A=Ll(M,c,g,a.economy.nextCommand);if(A!=="ok")return{ok:!1,reason:A};const E=c==="remove"?a.world.resources.find(y=>y.kind==="perch"):M.world.resources.find(y=>y.kind==="perch");if(!E)return{ok:!1,reason:"invalid"};if(c==="remove"){const y=xn(a,E.id).map(R=>({kind:"refund",relatedId:R.paidId,amount:R.amount})),T=$i(a,`care-remove-${E.kind}-${a.ledger.length}`,y);if(!T)return{ok:!1,reason:"invalid"};M.currency=T.currency,M.ledger=T.ledger}else{const y=pt.perch,T=Ti(M,y,c==="place"?"build":"supplies",`care-perch-${a.ledger.length}-${c}`,E.id);if(T)return{ok:!1,reason:T==="duplicate"?"stale":T}}M.economy.nextCommand++;const v=tn(M);return v.ok?(a=nn(v.value),l(),f(),m(Object.freeze({type:"perch-changed",tick:a.tick,gameTimeMs:a.gameTimeMs})),{ok:!0}):{ok:!1,reason:"invalid"}},waterView:()=>wl(a),water(c,g,S){if(h||x.inspect().paused||!o(S)||!Number.isSafeInteger(g)||g<0)return{ok:!1,reason:"invalid"};const M=structuredClone(a),A=Pl(M,c,g,a.economy.nextCommand);if(A!=="ok")return{ok:!1,reason:A};const E=c==="remove"?a.world.resources.find(y=>y.kind==="water"):M.world.resources.find(y=>y.kind==="water");if(!E)return{ok:!1,reason:"invalid"};if(c==="remove"){const y=xn(a,E.id).map(R=>({kind:"refund",relatedId:R.paidId,amount:R.amount})),T=$i(a,`care-remove-${E.kind}-${a.ledger.length}`,y);if(!T)return{ok:!1,reason:"invalid"};M.currency=T.currency,M.ledger=T.ledger}else{const y=c==="place"?pt.water:pt.waterRefill,T=Ti(M,y,c==="place"?"build":"supplies",`care-water-${a.ledger.length}-${c}`,E.id);if(T)return{ok:!1,reason:T==="duplicate"?"stale":T}}M.economy.nextCommand++;const v=tn(M);return v.ok?(a=nn(v.value),l(),f(),m(Object.freeze({type:"water-changed",tick:a.tick,gameTimeMs:a.gameTimeMs})),{ok:!0}):{ok:!1,reason:"invalid"}},foodView:()=>El(a),food(c,g,S){if(h||x.inspect().paused||!o(S)||!Number.isSafeInteger(g)||g<0)return{ok:!1,reason:"invalid"};const M=structuredClone(a),A=Cl(M,c,g,a.economy.nextCommand);if(A!=="ok")return{ok:!1,reason:A};const E=c==="remove"?a.world.resources.find(y=>y.kind==="food"):M.world.resources.find(y=>y.kind==="food");if(!E)return{ok:!1,reason:"invalid"};if(c==="remove"){const y=xn(a,E.id).map(R=>({kind:"refund",relatedId:R.paidId,amount:R.amount})),T=$i(a,`care-remove-${E.kind}-${a.ledger.length}`,y);if(!T)return{ok:!1,reason:"invalid"};M.currency=T.currency,M.ledger=T.ledger}else{const y=c==="place"?pt.food:pt.foodRefill,T=Ti(M,y,c==="place"?"build":"supplies",`care-food-${a.ledger.length}-${c}`,E.id);if(T)return{ok:!1,reason:T==="duplicate"?"stale":T}}M.economy.nextCommand++;const v=tn(M);return v.ok?(a=nn(v.value),l(),f(),m(Object.freeze({type:"food-changed",tick:a.tick,gameTimeMs:a.gameTimeMs})),{ok:!0}):{ok:!1,reason:"invalid"}},birdsView:()=>Kc(a),birds(c){if(h||x.inspect().paused)return!1;const g=structuredClone(a);if(c==="welcome"){if(!Rl(g))return!1}else if(c==="reserve"){if(!g.animals.some(M=>M.habitatId))return!1;g.animals.forEach(Zc)}else return!1;const S=tn(g);return S.ok?(a=nn(S.value),l(),m(Object.freeze({type:"birds-changed",tick:a.tick,gameTimeMs:a.gameTimeMs})),!0):!1},editorSnapshot:()=>structuredClone(d),quoteRemoval:c=>Fa(a,c,d.revision),remove(c,g){if(h||x.inspect().paused)return{ok:!1,reason:"command"};if(c.revision!==d.revision||!o(c.command))return{ok:!1,reason:"stale"};const S=Fa(a,c.target,d.revision);if(!S.ok)return S;const M=$i(a,g,xn(a,wc(c.target)).map(v=>({kind:"refund",relatedId:v.paidId,amount:v.amount})));if(!M)return{ok:!1,reason:"funds"};const A=ei(Tc(a.world,c.target)),E=tn(ki({...structuredClone(a),world:A.world,currency:M.currency,ledger:M.ledger,economy:{...structuredClone(a.economy),nextCommand:a.economy.nextCommand+1}}));return E.ok?(d={revision:d.revision+1,undo:{before:structuredClone(a.world),after:structuredClone(A.world),refundIds:M.entries.map(v=>v.id)}},a=nn(E.value),s=A.topology,f(),m(Object.freeze({type:"world-edited",tick:a.tick,gameTimeMs:a.gameTimeMs})),{ok:!0}):{ok:!1,reason:"command"}},undo(c,g){if(h||x.inspect().paused)return{ok:!1,reason:"command"};const S=d.undo;if(!o(g)||!S||!_l(S.after,a.world))return{ok:!1,reason:"stale"};const M=S.refundIds.map(T=>us(a,T));if(M.some(T=>!T||T.kind!=="refund"))return{ok:!1,reason:"command"};const A=$i(a,c,M.map(T=>({kind:"restore",relatedId:T.id,amount:-T.amount})));if(!A)return{ok:!1,reason:"funds"};const E=ei(S.before),v=structuredClone(a);v.economy.recovery.habitatGrant&&E.world.habitats.some(T=>T.id===v.economy.recovery.habitatGrant.id)&&(v.economy.recovery.habitatGrant.tick=a.tick);const y=tn(ki({...v,world:E.world,currency:A.currency,ledger:A.ledger,economy:{...v.economy,nextCommand:a.economy.nextCommand+1}}));return y.ok?(a=nn(y.value),s=E.topology,l(),f(),m(Object.freeze({type:"world-edited",tick:a.tick,gameTimeMs:a.gameTimeMs})),{ok:!0}):{ok:!1,reason:"command"}},economyView:()=>Zi(a),purchaseReason:c=>no(a,pt[c]),pathTopology:()=>structuredClone(s),access:()=>oo(s),subscribe:p.subscribe,snapshot:()=>structuredClone(a),setPaused(c){x.inspect().paused!==c&&(u=null,x.setPaused(c))},reset(){h||(a=nn(structuredClone(r)),l(),s=ei(a.world).topology,u=null,x.setSpeed(a.preferences.speed),x.reset(),f(),m(Object.freeze({type:"reset",tick:a.tick,gameTimeMs:a.gameTimeMs})))},dispose(){h||(h=!0,u=null,x.dispose(),p.dispose())},inspect:()=>({editorRevision:d.revision,canUndo:!!d.undo,undoCost:d.undo?.refundIds.reduce((c,g)=>c+(us(a,g)?.amount??0),0)??0,tick:a.tick,gameTimeMs:a.gameTimeMs,randomState:a.randomState,currency:a.currency,maintenancePeriod:a.economy.maintenancePeriod,maintenanceDue:Zi(a).maintenanceDue,economyGrants:Zi(a).grants,economySpent:Zi(a).spent,economyRefunds:Zi(a).refunds,ledgerEntries:Xs(a).entries,journalRetained:a.ledger.length,journalArchived:a.economy.checkpoint.entries,journalCompactions:a.economy.checkpoint.compactions,commandRevision:a.economy.nextCommand,retiredVisitorThrough:a.economy.checkpoint.visitorThrough,retiredOpenCount:a.economy.checkpoint.openSerials.length,recoveryHabitatTick:a.economy.recovery.habitatGrant?.tick??-1,recoveryHabitatNonce:Number(a.economy.recovery.habitatGrant?.id.split("-").at(-1)??0),recoveryGrants:a.economy.recovery.equipmentGrants,recoveryRations:a.economy.recovery.rationBatches,recoveryLastRation:a.economy.recovery.lastRationTick??-1,birdCount:a.animals.length,pathTiles:s.pathTiles,reachablePathTiles:s.reachable.length,connectedHabitats:s.habitats.filter(c=>c.connected).length,routeCells:oo(s).routeCells,habitatCount:a.world.habitats.length,occupiedTiles:a.world.tiles.filter(c=>c.occupantId!==null).length,...x.inspect(),subscribers:p.inspect().subscribers,listenerErrors:p.inspect().listenerErrors})};return _}function rg(i,e,t){let n=!1,r=!1,s,a=0;function d(){a++,n=!1,s!==void 0&&i.cancel(s),s=void 0}function l(o){if(!(!n||r||o!==a))try{s=i.request(f=>{if(!(!n||r||o!==a)){s=void 0;try{e(f)}catch{d(),r=!0,t();return}o===a&&l(o)}})}catch{d(),r=!0,t()}}return{start(){n||r||(n=!0,l(++a))},stop:d,dispose(){d(),r=!0},inspect:()=>({running:n,disposed:r,pendingFrames:s===void 0?0:1})}}function ag(i,e,t={}){const n=document.createElement("canvas");n.setAttribute("aria-hidden","true"),n.style.cssText="display:block;width:100%;height:100%";let r=null,s,a=!1,d=!1,l=!1,o=0,f=0,h=0,u;const p=[],m=[],x=new ru,_=new rt;x.add(_);let c;const g=new os,S=window.matchMedia("(prefers-reduced-motion: reduce)"),M=()=>id(L.visualSettings(),S.matches,window.innerWidth,window.matchMedia("(pointer:coarse)").matches,window.devicePixelRatio||1),A=t.frames??{request:H=>requestAnimationFrame(H),cancel:H=>cancelAnimationFrame(H)};let E,v,y,T,R,N,z,q=0,C=0,D=0,O=0,k=0,Q=!0,G=!0,K=!0,j=!0,ce=!0,ve=!0,$,ie=!1,_e=null,we=null,ae="";function Ne(){we==="funds"&&L.economyView().balance>=(L.foodView().exists?L.economyView().prices.foodRefill:L.economyView().prices.food)&&(we=null),we==="busy"&&L.foodView().canPlace&&(we=null);const H={...L.foodView(),preview:ie,reason:we},Ee=JSON.stringify(H);Ee!==ae&&(ae=Ee,i.dispatchEvent(new CustomEvent("scene-food-change",{detail:H}))),i.dataset.foodStock=String(H.stock),i.dataset.foodExists=String(H.exists)}let ot,ye=!1,He=null,Xe=null,Ve="";function Tt(){Xe==="funds"&&L.economyView().balance>=(L.waterView().exists?L.economyView().prices.waterRefill:L.economyView().prices.water)&&(Xe=null),Xe==="busy"&&L.waterView().canPlace&&(Xe=null);const H={...L.waterView(),preview:ye,reason:Xe},Ee=JSON.stringify(H);Ee!==Ve&&(Ve=Ee,i.dispatchEvent(new CustomEvent("scene-water-change",{detail:H}))),i.dataset.waterStock=String(H.stock),i.dataset.waterExists=String(H.exists)}let lt,Je=!1,Qe=null,At=null,bt="";function Ht(){At==="funds"&&L.economyView().balance>=(L.perchView().exists,L.economyView().prices.perch)&&(At=null),At==="busy"&&L.perchView().canPlace&&(At=null);const H={...L.perchView(),preview:Je,reason:At},Ee=JSON.stringify(H);Ee!==bt&&(bt=Ee,i.dispatchEvent(new CustomEvent("scene-perch-change",{detail:H}))),i.dataset.perchExists=String(H.exists)}let _t,Vt="";function B(){const H=L.birdsView(),Ee=JSON.stringify(H);Ee!==Vt&&(Vt=Ee,i.dispatchEvent(new CustomEvent("scene-birds-change",{detail:H}))),i.dataset.placedBirds=String(H.placed)}let St,ct="",dt="",he,yt="",De="",Ue="",P="",b="",V,re=!0;function ne(){const H=L.visitorView(),Ee=JSON.stringify(H);Ee!==ct&&(ct=Ee,i.dispatchEvent(new CustomEvent("scene-visitors-change",{detail:H}))),i.dataset.visitorCount=String(H.active),i.dataset.visitorWalking=String(H.walking),i.dataset.visitorViewing=String(H.viewing),i.dataset.visitorViewed=String(H.viewedTotal)}let oe;const L=ig(t.stateStore?.read(),t.stateStore?.readEditor());function Z(){t.stateStore?.write(L.snapshot()),t.stateStore?.writeEditor(L.editorSnapshot())}function ee(H=null,Ee=null){k=L.commandRevision(),i.dispatchEvent(new CustomEvent("scene-edit-change",{detail:{canUndo:L.inspect().canUndo,undoCost:L.inspect().undoCost,reason:H,result:Ee}}))}const fe=L.inspect().tick;let I=L.inspect().gameTimeMs,te=0;const J=L.subscribe(H=>{I=H.gameTimeMs,H.type==="tick"&&te++,t.stateStore?.checkpoint?.(()=>L.snapshot(),!["tick","animal-fed","animal-drank","visitor-viewed"].includes(H.type)),(H.type==="visitor-admitted"||H.type==="economy-changed"||H.type==="recovery-changed"||H.type==="mission-claimed"||H.type==="speed-changed"||H.type==="preferences-changed")&&Z(),K=!0,j=!0,ce=!0,ve=!0,re=!0,H.type==="habitat-built"&&(Q=!0,G=!0),H.type==="mission-claimed"&&(Q=!0),H.type==="path-built"&&(G=!0),(H.type==="world-edited"||H.type==="recovery-changed")&&(Q=!0,G=!0)});function ue(){a||d||(d=!0,L.setPaused(!0),se.stop(),e("context-lost"))}function le(){const H=L.inspect(),Ee=[H.commandRevision,H.currency,H.editorRevision].join(":");return(Ee!==yt||!he)&&(yt=Ee,he=L.onboardingView()),he}let de="";function Ce(H=!1){const Ee=L.inspect(),Ie={speed:Ee.speed,paused:Ee.paused},Se=JSON.stringify(Ie);(H||Se!==de)&&(de=Se,i.dataset.simulationRate=String(Ee.speed),i.dispatchEvent(new CustomEvent("scene-speed-change",{detail:Ie})))}function Le(){const H=M();E?.setLowGraphics(H.low),St?.setVisibleCap(H.low?1:3),Ce();const Ee=le(),Ie=JSON.stringify(Ee);Ie!==De&&(De=Ie,i.dispatchEvent(new CustomEvent("scene-onboarding-change",{detail:Ee})));const Se=L.missionView(),tt=JSON.stringify(Se);tt!==Ue&&(Ue=tt,i.dispatchEvent(new CustomEvent("scene-missions-change",{detail:Se})));const ln=[L.inspect().tick,L.commandRevision(),L.inspect().editorRevision,L.visitorView().open].join(":");ln!==b&&(b=ln,V=L.recoveryView());const Bi=JSON.stringify(V);Bi!==P&&(P=Bi,i.dispatchEvent(new CustomEvent("scene-recovery-change",{detail:V})));const Kn=L.economyView(),zi=JSON.stringify(Kn);if(zi!==dt&&(dt=zi,T?.refresh(),i.dispatchEvent(new CustomEvent("scene-economy-change",{detail:Kn}))),a||d)return;if(r?.isContextLost()){ue();return}if(Q&&z){const vt=L.snapshot().world;z.sync(vt),R?.sync(vt,L.missionView().care.unlocked),N?.sync(vt,L.missionView().thriving.unlocked),Q=!1}if(G&&oe&&(oe.sync(L.snapshot().world),y?.refresh(),G=!1),K&&_t){const vt=L.birdSnapshot();_t.sync(vt.animals,vt.habitats,vt.width,vt.height,I),K=!1,B()}if(j&&($?.sync(L.snapshot().world,ie,L.foodView().canPlace),Ne(),j=!1),ce&&(ot?.sync(L.snapshot().world,ye,L.waterView().canPlace),Tt(),ce=!1),ve){const vt=L.perchView();lt?.sync(L.snapshot().world,Je,vt.canPlace),_t?.setPerchesVisible(!vt.reachable&&!Je),Ht(),ve=!1}if(lt?.update(I,L.perchView().exploring,M().reducedMotion),re&&St){const vt=L.visitorSnapshot();St.sync(vt.visitors,vt.width,vt.height,vt.tick,vt.gate),re=!1,ne()}const Jn=L.inspect().accumulatorMs;St?.update(Jn/100,I+Jn,M().reducedMotion),_t?.update(Jn/100,I+Jn),E?.update(I,M().reducedMotion),s?.render(x,c?.view().active&&!c.view().habitat?c.camera:g),s&&f++}const se=rg(A,H=>{L.frame(H),c?.frame(H),Le()},()=>e("render"));function be(){const H=a||d||l||document.hidden,Ee=c?.view();L.setPaused(H||!!Ee?.active),Ce(),H&&(Z(),t.stateStore?.checkpoint?.(()=>L.snapshot(),!0),t.stateStore?.flush?.()),v?.setEnabled(!H&&(!Ee?.active||Ee.habitat)),y?.setEnabled(!H&&!Ee?.active&&!ie&&!ye&&!Je),T?.setEnabled(!H&&!Ee?.active&&!ie&&!ye&&!Je);const Ie=H||!!(Ee?.active&&Ee.motionPaused);c?.setRunning(!Ie),Ie?se.stop():se.start()}function Oe(){if(a||d||!s)return;const H=i.getBoundingClientRect(),Ee=Math.max(1,Math.round(H.width)),Ie=Math.max(1,Math.round(H.height));s.setPixelRatio(M().pixelRatio),s.setSize(Ee,Ie,!1),v?.resize(Ee,Ie),c?.resize(Ee,Ie),Le()}function ge(){try{Oe()}catch{e("render")}}function et(){M().reducedMotion&&c?.pauseForReducedMotion(),be()}function Et(H){if(H.key==="Escape"&&Je){H.preventDefault(),H.stopImmediatePropagation(),Je=!1,Qe=null,ve=!0,be(),Le();return}if(H.key==="Escape"&&ye){H.preventDefault(),H.stopImmediatePropagation(),ye=!1,He=null,ce=!0,be(),Le();return}if(H.key==="Escape"&&ie){H.preventDefault(),H.stopImmediatePropagation(),ie=!1,_e=null,j=!0,be(),Le();return}H.key==="Escape"&&!H.repeat&&c?.view().active&&(H.preventDefault(),H.stopImmediatePropagation(),c.command("close"))}function on(H){H.preventDefault(),ue()}function mt(H){try{H()}catch{o++}}function di(){if(!a){a=!0,mt(()=>se.dispose()),mt(()=>v?.dispose()),mt(()=>y?.dispose()),mt(()=>T?.dispose()),mt(()=>z?.dispose()),mt(()=>R?.dispose()),mt(()=>N?.dispose()),mt(()=>oe?.dispose()),mt(()=>$?.dispose()),mt(()=>ot?.dispose()),mt(()=>lt?.dispose()),mt(()=>_t?.dispose()),mt(()=>St?.dispose()),mt(()=>c?.dispose()),i.removeEventListener("keydown",Et,!0),mt(Z),mt(()=>t.stateStore?.checkpoint?.(()=>L.snapshot(),!0)),mt(()=>t.stateStore?.flush?.()),J(),L.dispose(),n.removeEventListener("webglcontextlost",on),document.removeEventListener("visibilitychange",be),window.removeEventListener("resize",ge),S.removeEventListener("change",et),u?.disconnect();for(const H of p)mt(()=>H.dispose());for(const H of m)mt(()=>{H.dispose(),h++});x.clear(),s?(mt(()=>s.dispose()),mt(()=>gl(r,()=>s.forceContextLoss()))):mt(()=>gl(r,()=>r?.getExtension("WEBGL_lose_context")?.loseContext())),n.remove()}}try{let H=function(){ee();const Se=L.access();i.dataset.worldPathCount=String(Se.pathTiles),i.dataset.worldConnected=String(Se.connected),i.dataset.worldRouteCells=String(Se.routeCells),i.dispatchEvent(new CustomEvent("scene-access-change",{detail:Se}));const tt=L.inspect();i.dataset.builtHabitats=String(tt.habitatCount),i.dataset.occupiedTiles=String(tt.occupiedTiles),i.dispatchEvent(new CustomEvent("scene-habitat-change",{detail:{count:tt.habitatCount,occupiedTiles:tt.occupiedTiles}}))};try{r=t.createContext?t.createContext(n):n.getContext("webgl2",{antialias:!0,alpha:!1,powerPreference:"low-power"})}catch{throw new fr("unsupported")}if(!r)throw new fr("unsupported");s=t.createRenderer?t.createRenderer(n,r):new b0({canvas:n,context:r,antialias:!0,alpha:!1}),s.debug.onShaderError=()=>{throw new fr("init")},s.outputColorSpace=jt,s.setPixelRatio(Math.min(window.devicePixelRatio||1,1.5)),x.background=new We("#edf3e5"),x.add(new Tu("#e5f1dc",1.7));const Ee=new wu("#fff1d6",2.5);Ee.position.set(-6,10,8),x.add(Ee);const Ie=L.snapshot().world;if($=L0(),_.add($.group),ot=P0(),_.add(ot.group),lt=C0(),_.add(lt.group),_t=F0(),_.add(_t.group),St=R0(),_.add(St.group),E=E0(Ie),p.push(...E.geometries),m.push(...E.materials),_.add(E.group),R=T0(),_.add(R.group),N=w0(),_.add(N.group),z=z0(E.catalog,(Se,tt)=>{p.push(Se),m.push(tt)}),_.add(z.group),oe=B0(E.catalog),p.push(oe.geometry),m.push(oe.material),_.add(oe.group),H(),y=k0(E.catalog,g,()=>n.getBoundingClientRect(),Se=>{Se?i.dataset.selectedId=Se.id:delete i.dataset.selectedId,i.dispatchEvent(new CustomEvent("scene-selection-change",{detail:Se}))}),p.push(...y.geometries),m.push(...y.materials),_.add(y.group),T=G0(()=>L.snapshot().world,E.catalog,g,()=>n.getBoundingClientRect(),Se=>{i.dataset.planActive=String(Se.active),i.dataset.planKind=Se.kind,i.dataset.planReason=Se.reason,i.dataset.planAnchor=Se.proposal?`${Se.proposal.anchor.x},${Se.proposal.anchor.z}`:"",i.dataset.planConfirmed=Se.confirmed?`${Se.confirmed.anchor.x},${Se.confirmed.anchor.z}`:"",i.dispatchEvent(new CustomEvent("scene-placement-change",{detail:Se}))},(Se,tt)=>(Se.kind==="path"?L.buildPath(Se.anchor,q):L.buildHabitat(Se.anchor,tt,q)).ok?(q=L.commandRevision(),Z(),H(),!0):!1,Se=>L.purchaseReason(Se)),p.push(...T.geometries),m.push(...T.materials),_.add(T.group),v=X0(i,n,g,E.bounds,Ie,Se=>{c?.view().active||(T?.active()?T.pick(Se):y?.pick(Se))},()=>T?.active()?T.command("cancel"):y?.clear()),c=O0(()=>L.snapshot().world,Se=>{_t?.setVisible(!Se.active),_.visible=!Se.active||Se.habitat,i.dispatchEvent(new CustomEvent("scene-studio-change",{detail:Se})),be(),Oe()},()=>M().reducedMotion),x.add(c.group),i.addEventListener("keydown",Et,!0),n.addEventListener("webglcontextlost",on),i.append(n),Oe(),d||r.isContextLost())throw new fr("context-lost");typeof ResizeObserver<"u"?(u=new ResizeObserver(ge),u.observe(i)):window.addEventListener("resize",ge),document.addEventListener("visibilitychange",be),S.addEventListener("change",et),be()}catch(H){throw di(),H}return{dispose:di,guide:(H,Ee)=>{if(!(a||l||d||document.hidden||c?.view().active||!T)){if(H==="cancel")T.command("cancel");else if(H==="confirm"){const Ie=T.inspect().placementConfirmations;T.command("confirm",Ee),T.inspect().placementConfirmations>Ie&&T.command("cancel")}else{const Ie=L.onboardingView();if(H==="focus")if(Ie.target){const Se=L.snapshot().world;v?.focus({x:Ie.target.x+.5-Se.width/2,z:Ie.target.z+.5-Se.height/2})}else v?.command("reset");else if(Ie.kind&&Ie.target&&Ie.affordable){v?.setEnabled(!1),v?.setEnabled(!0),ie=!1,ye=!1,Je=!1,j=!0,ce=!0,ve=!0,y?.clear(),q=L.commandRevision(),T.guide(Ie.kind,Ie.target);const Se=L.snapshot().world;v?.focus({x:Ie.target.x+(Ie.kind==="habitat"?1:.5)-Se.width/2,z:Ie.target.z+(Ie.kind==="habitat"?1:.5)-Se.height/2})}}Le()}},muted:H=>{!a&&!d&&L.setMuted(H)},visualSettings:H=>{a||d||L.setVisualSettings(H)&&(Z(),M().reducedMotion&&c?.pauseForReducedMotion(),Oe(),Le())},locale:H=>{L.setLocale(H)},speed:H=>{a||d||l||document.hidden||c?.view().active||(L.setSpeed(H),Ce(!0),Le())},claimMission:H=>{if(a||l||d||document.hidden||c?.view().active)return;const Ee=L.claimMission(H);Ue="",Le(),i.dispatchEvent(new CustomEvent("scene-mission-result",{detail:Ee}))},recoveryQuote:()=>{const H=L.recoveryView();return i.dispatchEvent(new CustomEvent("scene-recovery-change",{detail:H})),!a&&!l&&!d&&!document.hidden&&!c?.view().active&&H.low&&H.available?{command:H.command,key:H.key}:void 0},recover:H=>{a||l||d||document.hidden||c?.view().active||(v?.setEnabled(!1),v?.setEnabled(!0),T?.command("cancel"),y?.clear(),ie=!1,ye=!1,Je=!1,L.recover(H)&&(Q=!0,G=!0,K=!0,j=!0,ce=!0,ve=!0,re=!0,Z(),ee()),Le())},visitors:H=>{if(!(a||l||d||document.hidden||c?.view().active)){if(H==="focus"||H==="follow"){const Ee=L.snapshot().world,Ie=H==="follow"?M().low?L.snapshot().visitors.find(Se=>Se.arrival)?.position:L.visitorFocus():null;v?.focus({x:(Ie?.x??Ee.gate.x+.5)-Ee.width/2,z:(Ie?.z??Ee.gate.z+.7)-Ee.height/2})}else(H==="open"||H==="close")&&(L.visitors(H==="open"),Z());Le()}},perch:(H,Ee=0)=>{if(a||l||d||document.hidden||c?.view().active)return;v?.setEnabled(!1),v?.setEnabled(!0),T?.command("cancel"),y?.clear(),ie=!1,_e=null,j=!0,ye=!1,He=null,ce=!0;const Ie=L.snapshot().world.habitats[0];if(At=null,H==="preview")!Ie||L.perchView().exists?At=Ie?"exists":"missing":(Je=!0,Qe=Ie.id,O=L.commandRevision());else if(H==="cancel")Je=!1,Qe=null;else if(H==="confirm"&&(!Je||Ie?.id!==Qe))Je=!1,At="stale";else{const Se=H==="confirm"?"place":H==="remove"?"remove":null;if(Se){const tt=L.perch(Se,Ee,H==="confirm"?O:L.commandRevision());At=tt.ok?null:tt.reason,tt.ok&&(Je=!1,Qe=null,Z(),ee())}}ve=!0,be(),Le(),Ht()},water:(H,Ee=0)=>{if(a||l||d||document.hidden||c?.view().active)return;v?.setEnabled(!1),v?.setEnabled(!0),T?.command("cancel"),y?.clear(),Je=!1,Qe=null,ve=!0,ie=!1,_e=null,j=!0;const Ie=L.snapshot().world.habitats[0];if(Xe=null,H==="preview")!Ie||L.waterView().exists?Xe=Ie?"exists":"missing":(ye=!0,He=Ie.id,D=L.commandRevision());else if(H==="cancel")ye=!1,He=null;else if(H==="confirm"&&(!ye||Ie?.id!==He))ye=!1,Xe="stale";else{const Se=H==="confirm"?"place":H==="refill"?"refill":H==="remove"?"remove":null;if(Se){const tt=L.water(Se,Ee,H==="confirm"?D:L.commandRevision());Xe=tt.ok?null:tt.reason,tt.ok&&(ye=!1,He=null,Z(),ee())}}ce=!0,be(),Le(),Tt()},food:(H,Ee=0)=>{if(a||l||d||document.hidden||c?.view().active)return;v?.setEnabled(!1),v?.setEnabled(!0),T?.command("cancel"),y?.clear(),Je=!1,Qe=null,ve=!0,ye=!1,He=null,ce=!0;const Ie=L.snapshot().world.habitats[0];if(we=null,H==="preview")!Ie||L.foodView().exists?we=Ie?"exists":"missing":(ie=!0,_e=Ie.id,C=L.commandRevision());else if(H==="cancel")ie=!1,_e=null;else if(H==="confirm"&&(!ie||Ie?.id!==_e))ie=!1,we="stale";else{const Se=H==="confirm"?"place":H==="refill"?"refill":H==="remove"?"remove":null;if(Se){const tt=L.food(Se,Ee,H==="confirm"?C:L.commandRevision());we=tt.ok?null:tt.reason,tt.ok&&(ie=!1,_e=null,Z(),ee())}}j=!0,be(),Le(),Ne()},birds:H=>{a||l||d||document.hidden||c?.view().active||(v?.setEnabled(!1),v?.setEnabled(!0),T?.command("cancel"),L.birds(H)&&(y?.clear(),Z(),Le(),ee()))},studio:(H,Ee)=>{if(!(a||l||d||document.hidden))try{H==="open"&&(Je=!1,Qe=null,ve=!0,ye=!1,He=null,ce=!0,ie=!1,_e=null,j=!0,T?.command("cancel"),y?.clear()),c?.command(H,Ee)}catch{e("render")}},camera:H=>v?.command(H),clearSelection:()=>y?.clear(),placement:(H,Ee)=>{c?.view().active||(Je=!1,Qe=null,ve=!0,ie=!1,_e=null,j=!0,ye=!1,He=null,ce=!0,(H==="begin"||H==="begin-path")&&(q=L.commandRevision(),y?.clear()),T?.command(H,Ee))},quoteRemoval:H=>L.quoteRemoval(H),edit:(H,Ee)=>{if(a||l||d||document.hidden||c?.view().active)return;T?.command("cancel");const Ie=`edit-${crypto.randomUUID().replaceAll("-","")}`,Se=H==="undo"?L.undo(Ie,k):Ee?L.remove(Ee,Ie):{ok:!1,reason:"command"};if(Se.ok){y?.clear(),Z(),Le();const tt=L.access();i.dataset.worldPathCount=String(tt.pathTiles),i.dataset.worldConnected=String(tt.connected),i.dataset.worldRouteCells=String(tt.routeCells),i.dispatchEvent(new CustomEvent("scene-access-change",{detail:tt}));const ln=L.inspect();i.dataset.builtHabitats=String(ln.habitatCount),i.dataset.occupiedTiles=String(ln.occupiedTiles),i.dispatchEvent(new CustomEvent("scene-habitat-change",{detail:{count:ln.habitatCount,occupiedTiles:ln.occupiedTiles}}))}ee(Se.ok?null:Se.reason,Se.ok?H==="undo"?"restored":"removed":null)},cancelInput(){v?.setEnabled(!1),be()},setPaused(H){l=H,be()},inspect:()=>({graphicsLow:M().low,manualReducedMotion:L.snapshot().preferences.reducedMotion,effectiveReducedMotion:M().reducedMotion,graphicsPixelRatioCap:M().pixelRatio,canUndo:L.inspect().canUndo,editorRevision:L.inspect().editorRevision,disposed:a,lost:d,canvasAttached:n.isConnected,pendingFrames:se.inspect().pendingFrames,geometries:s?.info.memory.geometries??0,textures:s?.info.memory.textures??0,programs:s?.info.programs?.length??0,ownedMaterialsLive:m.length-h+(R?.inspect().rewardDecorationMaterials??0)+(N?.inspect().thrivingBannerMaterials??0)+(St?.inspect().visitorOwnedMaterials??0)+(c?.inspect().macawOwnedMaterialsLive??0)+(_t?.inspect().birdOwnedMaterials??0)+($?.inspect().feederOwnedMaterials??0)+(ot?.inspect().waterOwnedMaterials??0)+(lt?.inspect().perchOwnedMaterials??0),drawCallsLastRender:s?.info.render.calls??0,trianglesLastRender:s?.info.render.triangles??0,renderSubmissions:f,bufferWidth:n.width,bufferHeight:n.height,pixelRatio:s?.getPixelRatio()??0,cleanupErrors:o,simulationSpeed:L.inspect().speed,simulationDroppedWallMs:L.inspect().droppedMs,simulationDroppedSimMs:L.inspect().droppedSimulationMs,simulationLastAdvanceSteps:L.inspect().lastAdvanceSteps,simulationAccumulatorMs:L.inspect().accumulatorMs,simulationTick:L.inspect().tick,simulationGameTimeMs:L.inspect().gameTimeMs,simulationPaused:L.inspect().paused,simulationDisposed:L.inspect().disposed,simulationSubscribers:L.inspect().subscribers,simulationEvents:te,simulationStartTick:fe,onboardingStep:["habitat","path","claim","done","blocked"].indexOf(le().stage),onboardingRemaining:le().remaining,onboardingAffordable:le().affordable,missionCompleted:L.missionView().completed,missionRewardCoins:L.missionView().rewards,missionQ01Ready:L.missionView().rows[0].status==="ready",missionQ02Ready:L.missionView().rows[1].status==="ready",missionQ03Ready:L.missionView().rows[2].status==="ready",missionPaidVisitors:L.missionView().visit.admissions,missionViewedVisitors:L.missionView().visit.viewings,missionVisitorBadge:L.missionView().visit.badged,missionPinnedGuests:L.snapshot().missions.objectives.admittedVisitorIds.length+L.snapshot().missions.objectives.viewedVisitorIds.length,missionCareTicks:L.missionView().care.comfortableTicks,missionBirdsFed:L.missionView().care.fed,missionBirdsWatered:L.missionView().care.watered,missionCareUnlocked:L.missionView().care.unlocked,...R?.inspect(),...N?.inspect(),missionQ04Ready:L.missionView().rows[3].status==="ready",missionThrivingTicks:L.missionView().thriving.ticks,missionThrivingRevenue:L.missionView().thriving.revenue,missionThrivingAdmissions:L.missionView().thriving.admissions,missionThrivingUnlocked:L.missionView().thriving.unlocked,habitatCount:L.inspect().habitatCount,occupiedTiles:L.inspect().occupiedTiles,currency:L.inspect().currency,maintenancePeriod:L.inspect().maintenancePeriod,maintenanceDue:L.inspect().maintenanceDue,economyGrants:L.inspect().economyGrants,economySpent:L.inspect().economySpent,economyRefunds:L.inspect().economyRefunds,ledgerEntries:L.inspect().ledgerEntries,journalRetained:L.inspect().journalRetained,journalArchived:L.inspect().journalArchived,journalCompactions:L.inspect().journalCompactions,commandRevision:L.inspect().commandRevision,retiredVisitorThrough:L.inspect().retiredVisitorThrough,retiredOpenCount:L.inspect().retiredOpenCount,recoveryHabitatTick:L.inspect().recoveryHabitatTick,recoveryHabitatNonce:L.inspect().recoveryHabitatNonce,recoveryGrants:L.inspect().recoveryGrants,recoveryRations:L.inspect().recoveryRations,recoveryLastRation:L.inspect().recoveryLastRation,perchExists:L.perchView().exists,perchRevision:L.perchView().revision,perchResting:L.perchView().resting,perchExploring:L.perchView().exploring,perchPreview:Je,...lt?.inspect(),waterStock:L.waterView().stock,waterBowl1:L.waterView().portions[0],waterBowl2:L.waterView().portions[1],waterRevision:L.waterView().revision,waterExists:L.waterView().exists,waterPreview:ye,...ot?.inspect(),foodStock:L.foodView().stock,foodBowl1:L.foodView().portions[0],foodBowl2:L.foodView().portions[1],foodRevision:L.foodView().revision,foodExists:L.foodView().exists,foodPreview:ie,...$?.inspect(),...L.visitorInspect(),visitorCount:L.visitorView().active,visitorQueued:L.visitorView().queued,visitorWalking:L.visitorView().walking,visitorViewing:L.visitorView().viewing,visitorReturning:L.visitorView().returning,visitorViewed:L.visitorView().viewedTotal,visitorOpen:L.visitorView().open,visitorTotal:L.visitorView().total,visitorNextSerial:L.snapshot().visitorFlow.nextSerial,visitorCooldown:L.snapshot().visitorFlow.cooldownTicks,...St?.inspect(),...L.birdInspect(),placedBirds:L.birdsView().placed,..._t?.inspect(),...c?.inspect(),...z?.inspect(),...oe?.inspect(),pathTiles:L.inspect().pathTiles,reachablePathTiles:L.inspect().reachablePathTiles,connectedHabitats:L.inspect().connectedHabitats,routeCells:L.inspect().routeCells,orthographicCamera:g.isOrthographicCamera,...E?.inspect(),...v?.inspect(),...y?.inspect(),...T?.inspect()})}}export{ag as mountFoundationScene};
